if SERVER then return end

NPCPassengers = NPCPassengers or {}
NPCPassengers.Modules = NPCPassengers.Modules or {}
NPCPassengers.Modules.ui = true

local IsValid = IsValid
local math = math
local string = string
local table = table
local ipairs = ipairs
local pairs = pairs

local ADDON_DISPLAY_NAME = "Better NPC Passengers"
local ADDON_CHAT_PREFIX = "[" .. ADDON_DISPLAY_NAME .. "] "
local DEFAULT_FONT_NAME = "Tahoma"
local HUD_POSITION_NAMES = {
    [0] = "Top Left",
    [1] = "Top Right",
    [2] = "Bottom Left",
    [3] = "Bottom Right",
}

-- Better NPC Passengers UI
-- Dark theme settings panel with custom Metropolis font

-- Keybind system: Track key states to detect key presses
local keyStates = {}

local function GetConVarIntSafe(name, default)
    if NPCPassengers.GetConVarInt then
        return NPCPassengers.GetConVarInt(name, default or 0)
    end
    local cv = GetConVar(name)
    if not cv then return default or 0 end
    return cv:GetInt()
end

local function GetConVarBoolSafe(name, default)
    if NPCPassengers.GetConVarBool then
        return NPCPassengers.GetConVarBool(name, default == true)
    end
    local cv = GetConVar(name)
    if not cv then return default == true end
    return cv:GetBool()
end

local function GetConVarFloatSafe(name, default)
    if NPCPassengers.GetConVarFloat then
        return NPCPassengers.GetConVarFloat(name, default or 0)
    end
    local cv = GetConVar(name)
    if not cv then return default or 0 end
    return cv:GetFloat()
end

hook.Add("Think", "NPCPassengers_Keybinds", function()
    -- Helper function to check if a key was just pressed
    local function WasKeyJustPressed(keyCode)
        if keyCode <= 0 then return false end
        
        local isDown = input.IsKeyDown(keyCode)
        local wasDown = keyStates[keyCode] or false
        keyStates[keyCode] = isDown
        
        return isDown and not wasDown
    end
    
    -- Check each keybind
    local keyAttach = GetConVarIntSafe("nai_npc_key_attach", 0)
    if WasKeyJustPressed(keyAttach) then
        RunConsoleCommand("nai_npc_attach_nearest")
    end
    
    local keyDetachAll = GetConVarIntSafe("nai_npc_key_detach_all", 0)
    if WasKeyJustPressed(keyDetachAll) then
        RunConsoleCommand("nai_npc_detach_all")
    end
    
    local keyToggleAutoJoin = GetConVarIntSafe("nai_npc_key_toggle_autojoin", 0)
    if WasKeyJustPressed(keyToggleAutoJoin) then
        local currentVal = GetConVarBoolSafe("nai_npc_auto_join", true)
        RunConsoleCommand("nai_npc_auto_join", currentVal and "0" or "1")
        chat.AddText(Color(100, 200, 255), ADDON_CHAT_PREFIX, Color(255, 255, 255), "Auto-Join: ", currentVal and Color(255, 100, 100) or Color(100, 255, 100), currentVal and "OFF" or "ON")
    end
    
    local keyMenu = GetConVarIntSafe("nai_npc_key_menu", 0)
    if WasKeyJustPressed(keyMenu) then
        RunConsoleCommand("nai_passengers_menu")
    end
    
    local keyExitAll = GetConVarIntSafe("nai_npc_key_exit_all", 0)
    if WasKeyJustPressed(keyExitAll) then
        RunConsoleCommand("nai_npc_exit_all")
    end

    local keyToggleHUD = GetConVarIntSafe("nai_npc_key_toggle_hud", 0)
    if WasKeyJustPressed(keyToggleHUD) then
        local currentVal = GetConVarBoolSafe("nai_npc_hud_enabled", true)
        RunConsoleCommand("nai_npc_hud_enabled", currentVal and "0" or "1")
        chat.AddText(Color(100, 200, 255), ADDON_CHAT_PREFIX, Color(255, 255, 255), "Passenger HUD: ", currentVal and Color(255, 100, 100) or Color(100, 255, 100), currentVal and "OFF" or "ON")
    end

    local keyCycleHUDPosition = GetConVarIntSafe("nai_npc_key_cycle_hud_position", 0)
    if WasKeyJustPressed(keyCycleHUDPosition) then
        local currentPos = GetConVarIntSafe("nai_npc_hud_position", 1)
        local nextPos = (currentPos + 1) % 4
        RunConsoleCommand("nai_npc_hud_position", tostring(nextPos))
        chat.AddText(Color(100, 200, 255), ADDON_CHAT_PREFIX, Color(255, 255, 255), "HUD Position: ", Color(180, 220, 255), HUD_POSITION_NAMES[nextPos] or "Unknown")
    end

    local keyDebugHUD = GetConVarIntSafe("nai_npc_key_debug_hud", 0)
    if WasKeyJustPressed(keyDebugHUD) then
        local currentVal = GetConVarBoolSafe("nai_npc_hud_target_debug", false)
        RunConsoleCommand("nai_npc_hud_target_debug", currentVal and "0" or "1")
        chat.AddText(Color(100, 200, 255), ADDON_CHAT_PREFIX, Color(255, 255, 255), "Target Debug: ", currentVal and Color(255, 100, 100) or Color(100, 255, 100), currentVal and "OFF" or "ON")
    end

    -- Hold fire / Open fire keybinds
    local keyHoldFire = GetConVarIntSafe("nai_npc_key_hold_fire", 0)
    if WasKeyJustPressed(keyHoldFire) then
        RunConsoleCommand("nai_npc_turret_hold_fire", "1")
        chat.AddText(Color(100, 200, 255), ADDON_CHAT_PREFIX, Color(255, 255, 255), "Turret gunners: ", Color(255, 100, 100), "HOLDING FIRE")
    end

    local keyOpenFire = GetConVarIntSafe("nai_npc_key_open_fire", 0)
    if WasKeyJustPressed(keyOpenFire) then
        RunConsoleCommand("nai_npc_turret_hold_fire", "0")
        chat.AddText(Color(100, 200, 255), ADDON_CHAT_PREFIX, Color(255, 255, 255), "Turret gunners: ", Color(100, 255, 100), "OPEN FIRE")
    end
    
    -- Debug keybinds (only if debug mode is enabled)
    if GetConVarBoolSafe("nai_npc_debug_mode", false) then
        local keyTestGesture = GetConVarIntSafe("nai_npc_key_test_gesture", 0)
        if WasKeyJustPressed(keyTestGesture) then
            net.Start("NPCPassengers_DebugTest")
            net.WriteString("gesture")
            net.SendToServer()
        end
        
        local keyResetAll = GetConVarIntSafe("nai_npc_key_reset_all", 0)
        if WasKeyJustPressed(keyResetAll) then
            net.Start("NPCPassengers_DebugTest")
            net.WriteString("reset")
            net.SendToServer()
        end
    end
end)

local selectedNPCForVehicle = nil
local selectionExpireTime = 0

-- Client-side bone manipulation for body sway
local spineBoneCache = {}
local clientSwayState = {}
local trackedPassengerNPCs = {}
local clientVehicleSeatCache = {}
local nextPassengerRefresh = 0
local nextPassengerFullRefresh = 0
local PASSENGER_TRACK_REFRESH_INTERVAL = 0.5
local PASSENGER_TRACK_FULL_REFRESH_INTERVAL = 5

local cvBodySway = GetConVar("nai_npc_body_sway")
local cvBodySwayAmount = GetConVar("nai_npc_body_sway_amount")
local cvCrashFlinch = GetConVar("nai_npc_crash_flinch")
local cvCrashThreshold = GetConVar("nai_npc_crash_threshold")

local function GetClientRootVehicle(entity)
    if not IsValid(entity) then return nil end

    if entity:GetClass() == "prop_vehicle_prisoner_pod" then
        local parent = entity:GetParent()
        if IsValid(parent) then
            return parent
        end
    end

    return entity
end

local function GetPassengerControlVehicle(npc)
    if not IsValid(npc) then return nil end

    local parent = npc:GetParent()
    if not IsValid(parent) then return nil end

    return GetClientRootVehicle(parent)
end

local function ClearClientVehicleSeatCache(vehicle)
    if isnumber(vehicle) then
        clientVehicleSeatCache[vehicle] = nil
        return
    end

    if not IsValid(vehicle) then return end
    clientVehicleSeatCache[vehicle:EntIndex()] = nil
end

local function AddClientSeat(seats, seatLookup, seat)
    if not IsValid(seat) or seatLookup[seat] then return end

    seatLookup[seat] = true
    seats[#seats + 1] = seat
end

local function GetClientVehicleSeats(vehicle)
    if not IsValid(vehicle) then return {} end

    local vehicleId = vehicle:EntIndex()
    local class = vehicle:GetClass() or ""
    local children = vehicle:GetChildren()
    local childCount = #children
    local cached = clientVehicleSeatCache[vehicleId]

    if cached and cached.childCount == childCount and cached.className == class then
        local seats = cached.seats
        local validSeats = true

        for index = 1, #seats do
            if not IsValid(seats[index]) then
                validSeats = false
                break
            end
        end

        if validSeats then
            return seats
        end
    end

    local seats = {}
    local seatLookup = {}

    if vehicle.GetDriverSeat then
        local driverSeat = vehicle:GetDriverSeat()
        AddClientSeat(seats, seatLookup, driverSeat)
    end

    if IsValid(vehicle.DriverSeat) then
        AddClientSeat(seats, seatLookup, vehicle.DriverSeat)
    end

    if vehicle.GetPassengerSeats then
        for _, seat in pairs(vehicle:GetPassengerSeats()) do
            AddClientSeat(seats, seatLookup, seat)
        end
    end

    if vehicle.GetGunnerSeats then
        for _, seat in pairs(vehicle:GetGunnerSeats()) do
            AddClientSeat(seats, seatLookup, seat)
        end
    end

    if vehicle.pSeat then
        for _, seat in pairs(vehicle.pSeat) do
            AddClientSeat(seats, seatLookup, seat)
        end
    end

    if vehicle.GetSeats then
        for _, seat in pairs(vehicle:GetSeats()) do
            AddClientSeat(seats, seatLookup, seat)
        end
    end

    if vehicle.Seats then
        for _, seat in pairs(vehicle.Seats) do
            AddClientSeat(seats, seatLookup, seat)
        end
    end

    if vehicle.seats then
        for _, seat in ipairs(vehicle.seats) do
            AddClientSeat(seats, seatLookup, seat)
        end
    end

    for _, child in ipairs(children) do
        if IsValid(child) and child:GetClass() == "prop_vehicle_prisoner_pod" then
            AddClientSeat(seats, seatLookup, child)
        end
    end

    table.sort(seats, function(a, b)
        local posA = vehicle:WorldToLocal(a:GetPos())
        local posB = vehicle:WorldToLocal(b:GetPos())
        return posA.x > posB.x
    end)

    clientVehicleSeatCache[vehicleId] = {
        seats = seats,
        childCount = childCount,
        className = class,
    }

    return seats
end

local function IsPassengerInLocalPlayersVehicle(npc)
    local ply = LocalPlayer()
    if not IsValid(ply) or not ply:InVehicle() then return false end

    local playerVehicle = GetClientRootVehicle(ply:GetVehicle())
    local passengerVehicle = GetPassengerControlVehicle(npc)
    return IsValid(playerVehicle) and IsValid(passengerVehicle) and playerVehicle == passengerVehicle
end

local function GetClientVehicleSeatIndex(vehicle, seatEntity)
    if not IsValid(vehicle) or not IsValid(seatEntity) then return nil end

    local seats = GetClientVehicleSeats(vehicle)

    for index, seat in ipairs(seats) do
        if seat == seatEntity then
            return index
        end
    end

    return nil
end

local function GetClientVehicleSeatCount(vehicle)
    return #GetClientVehicleSeats(vehicle)
end

local function UpdateTrackedPassenger(ent)
    if not IsValid(ent) or not ent:IsNPC() or not ent:GetNWBool("IsNPCPassenger", false) then
        trackedPassengerNPCs[ent] = nil
        return
    end

    trackedPassengerNPCs[ent] = true
end

local function RefreshTrackedPassengers(forceRefresh)
    for ent in pairs(trackedPassengerNPCs) do
        UpdateTrackedPassenger(ent)
    end

    local curTime = CurTime()
    if not forceRefresh and curTime < nextPassengerFullRefresh then return end

    nextPassengerFullRefresh = curTime + PASSENGER_TRACK_FULL_REFRESH_INTERVAL

    for _, ent in ipairs(ents.GetAll()) do
        if IsValid(ent) and ent:IsNPC() then
            UpdateTrackedPassenger(ent)
        end
    end
end

local function EnsureTrackedPassengersFresh(forceRefresh)
    local curTime = CurTime()

    if forceRefresh or curTime >= nextPassengerRefresh then
        RefreshTrackedPassengers(forceRefresh)
        nextPassengerRefresh = curTime + PASSENGER_TRACK_REFRESH_INTERVAL
    end
end

local function GetTrackedPassengerEntities(forceRefresh)
    EnsureTrackedPassengersFresh(forceRefresh)

    local passengers = {}

    for ent in pairs(trackedPassengerNPCs) do
        if IsValid(ent) and ent:IsNPC() and ent:GetNWBool("IsNPCPassenger", false) then
            passengers[#passengers + 1] = ent
        else
            trackedPassengerNPCs[ent] = nil
        end
    end

    return passengers
end

-- Get spine bones for an NPC (cached)
local function GetSpineBones(npc)
    local entIdx = npc:EntIndex()
    if spineBoneCache[entIdx] then return spineBoneCache[entIdx] end
    
    local bones = {}
    local boneNames = {"ValveBiped.Bip01_Spine", "ValveBiped.Bip01_Spine1", "ValveBiped.Bip01_Spine2", "ValveBiped.Bip01_Spine4"}
    for i, name in ipairs(boneNames) do
        local boneId = npc:LookupBone(name)
        if boneId and boneId >= 0 then
            table.insert(bones, {id = boneId, mult = ({0.8, 0.6, 0.4, 0.25})[i] or 0.4})
        end
    end
    
    spineBoneCache[entIdx] = bones
    return bones
end

-- Simple lerp for smooth movement
local function LerpAngle(t, current, target)
    return current + (target - current) * math.min(1, t)
end

-- Client-side body sway - calculates from vehicle velocity directly
hook.Add("Think", "NPCPassengers_ClientBodySway", function()
    local dt = FrameTime()
    if dt <= 0 then return end

    if not cvBodySway or not cvBodySway:GetBool() then return end

    EnsureTrackedPassengersFresh()

    if next(trackedPassengerNPCs) == nil then return end

    local swayAmount = cvBodySwayAmount and cvBodySwayAmount:GetFloat() or 1
    local crashFlinchEnabled = cvCrashFlinch and cvCrashFlinch:GetBool() or true
    local crashThreshold = cvCrashThreshold and cvCrashThreshold:GetFloat() or 400

    for ent in pairs(trackedPassengerNPCs) do
        if IsValid(ent) and ent:IsNPC() and ent:GetNWBool("IsNPCPassenger", false) then
            local entIdx = ent:EntIndex()
            
            -- Get vehicle the NPC is parented to
            local vehicle = ent:GetParent()
            if not IsValid(vehicle) then continue end
            
            -- Get or find the actual vehicle entity
            if vehicle:GetClass() == "prop_vehicle_prisoner_pod" then
                vehicle = vehicle:GetParent()
            end
            if not IsValid(vehicle) then continue end
            
            -- Initialize state
            if not clientSwayState[entIdx] then
                clientSwayState[entIdx] = {
                    roll = 0, pitch = 0,
                    lastVel = Vector(0,0,0),
                    lastSpeed = 0,
                    crashLean = 0,  -- Extra forward lean from crash
                    crashRecovery = 0,
                }
            end
            local state = clientSwayState[entIdx]
            
            -- Get vehicle velocity and calculate sway
            local vel = vehicle:GetVelocity()
            local speed = vel:Length()
            local velDelta = vel - state.lastVel
            
            local vehRight = vehicle:GetRight()
            local vehForward = vehicle:GetForward()
            
            -- Detect crash: sudden forward deceleration
            local forwardDecel = -velDelta:Dot(vehForward)
            
            if crashFlinchEnabled and forwardDecel > crashThreshold and state.lastSpeed > 300 then
                -- Crash detected! Lean forward hard based on impact intensity
                local crashIntensity = math.Clamp((forwardDecel - crashThreshold) / 800, 0.3, 1)
                state.crashLean = math.max(state.crashLean, crashIntensity * 35)  -- Up to 35 degree forward lean
                state.crashRecovery = CurTime() + 0.8 + crashIntensity * 0.5  -- Recovery time based on intensity
            end
            
            -- Fade out crash lean (slow recovery, like whiplash)
            if state.crashLean > 0 then
                if CurTime() > state.crashRecovery then
                    -- Slow recovery after initial impact
                    state.crashLean = LerpAngle(dt * 2, state.crashLean, 0)
                end
            end
            
            state.lastVel = vel
            state.lastSpeed = speed
            
            -- Calculate lateral and forward sway from acceleration
            local lateralAccel = velDelta:Dot(vehRight) * 0.3 * swayAmount
            local forwardAccel = velDelta:Dot(vehForward) * 0.15 * swayAmount
            
            -- Add turn sway from angular velocity
            local turnSway = 0
            local phys = vehicle:GetPhysicsObject()
            if IsValid(phys) then
                turnSway = phys:GetAngleVelocity().y * 0.06 * swayAmount
            end
            
            local targetRoll = math.Clamp(lateralAccel + turnSway, -20, 20)
            local targetPitch = math.Clamp(-forwardAccel, -12, 12)
            
            -- Add crash lean to pitch
            targetPitch = targetPitch + state.crashLean
            
            -- Smooth interpolation (faster for crash, slower for normal)
            local lerpSpeed = state.crashLean > 5 and 12 or 6
            state.roll = LerpAngle(dt * lerpSpeed, state.roll, targetRoll)
            state.pitch = LerpAngle(dt * lerpSpeed, state.pitch, targetPitch)
            
            -- Apply bone manipulation if there's movement
            -- Note: For spine bones, roll = forward/back lean, pitch = side lean
            local bones = GetSpineBones(ent)
            if #bones > 0 and (math.abs(state.roll) > 0.5 or math.abs(state.pitch) > 0.5) then
                for _, bone in ipairs(bones) do
                    ent:ManipulateBoneAngles(bone.id, Angle(state.roll * bone.mult, 0, state.pitch * bone.mult))
                end
            end
        end
    end
end)

hook.Add("EntityNetworkedVarChanged", "NPCPassengers_TrackNetworkedPassenger", function(ent, name, _, newValue)
    if name ~= "IsNPCPassenger" or not IsValid(ent) or not ent:IsNPC() then return end

    if newValue then
        trackedPassengerNPCs[ent] = true
    else
        trackedPassengerNPCs[ent] = nil
    end
end)

hook.Add("NetworkEntityCreated", "NPCPassengers_TrackCreatedPassenger", function(ent)
    timer.Simple(0, function()
        if IsValid(ent) and ent:IsNPC() then
            UpdateTrackedPassenger(ent)
        end
    end)
end)

-- Clean up when NPCs are removed
hook.Add("EntityRemoved", "NPCPassengers_CleanBoneCache", function(ent)
    if ent:IsNPC() then
        local entIdx = ent:EntIndex()
        spineBoneCache[entIdx] = nil
        clientSwayState[entIdx] = nil
        trackedPassengerNPCs[ent] = nil
    end

    ClearClientVehicleSeatCache(ent)

    local parent = ent:GetParent()
    if IsValid(parent) then
        ClearClientVehicleSeatCache(parent)
    end
end)

-- Theme colors - Modern gradient design
local Theme = {
    bg = Color(22, 22, 28),
    bgLight = Color(32, 32, 40),
    bgLighter = Color(42, 42, 52),
    bgDark = Color(15, 15, 20),
    accent = Color(88, 166, 255),
    accentHover = Color(110, 180, 255),
    accentActive = Color(70, 140, 220),
    accentDark = Color(50, 110, 180),
    text = Color(230, 230, 240),
    textDim = Color(160, 160, 180),
    textBright = Color(255, 255, 255),
    success = Color(90, 200, 120),
    warning = Color(240, 180, 70),
    error = Color(220, 90, 90),
    border = Color(55, 55, 70),
    borderLight = Color(70, 70, 90),
    scrollbar = Color(70, 70, 85),
    scrollbarGrip = Color(100, 100, 125),
    shadow = Color(0, 0, 0, 120),
    glow = Color(88, 166, 255, 30),
}

-- Custom fonts (requires metropolis.ttf in resource/fonts/)
local fontName = "Metropolis"

local function GetUIFontName()
    local useDefaultFont = GetConVar("nai_npc_ui_use_default_font")
    if useDefaultFont and useDefaultFont:GetBool() then
        return DEFAULT_FONT_NAME
    end

    local customFont = GetConVar("nai_npc_ui_custom_font")
    if customFont then
        local fontName = customFont:GetString()
        if fontName and fontName ~= "" then
            return fontName
        end
    end

    return fontName
end

-- Function to copy fonts from addon folder to global resource/fonts/
local fontsInstalled = false
local function InstallAddonFonts()
    if fontsInstalled then return end
    fontsInstalled = true

    local addonFontFiles = file.Find("addons/betternpcpassengers-gmod/resource/fonts/*.ttf", "GAME")

    if addonFontFiles then
        for _, filename in ipairs(addonFontFiles) do
            local sourcePath = "addons/betternpcpassengers-gmod/resource/fonts/" .. filename
            local destPath = "resource/fonts/" .. filename

            -- Only copy if file doesn't already exist in global folder
            if not file.Exists(destPath, "GAME") then
                file.Copy(sourcePath, destPath, "GAME")
            end
        end
    end
end

-- Function to get available fonts (using actual font names, not filenames)
local cachedAvailableFonts = nil
local function GetAvailableFonts()
    if cachedAvailableFonts then return cachedAvailableFonts end

    -- List of known fonts with their actual font names
    local knownFonts = {
        {file = "metropolis.ttf", name = "Metropolis"},
        {file = "bebasneue.ttf", name = "Bebas Neue"},
        {file = "sharetech.ttf", name = "Share Tech"},
    }

    local fonts = {"Metropolis"} -- Default font

    -- Check which known fonts are actually present
    for _, fontInfo in ipairs(knownFonts) do
        local addonPath = "addons/betternpcpassengers-gmod/resource/fonts/" .. fontInfo.file
        local globalPath = "resource/fonts/" .. fontInfo.file

        if file.Exists(addonPath, "GAME") or file.Exists(globalPath, "GAME") then
            table.insert(fonts, fontInfo.name)
        end
    end

    cachedAvailableFonts = fonts
    return fonts
end


local function CreateNaiFonts()
    local activeFontName = GetUIFontName()

    surface.CreateFont("NaiFont_Small", {
        font = activeFontName,
        size = 14,
        weight = 400,
        antialias = true,
    })

    surface.CreateFont("NaiFont_Normal", {
        font = activeFontName,
        size = 16,
        weight = 400,
        antialias = true,
    })

    surface.CreateFont("NaiFont_Medium", {
        font = activeFontName,
        size = 18,
        weight = 500,
        antialias = true,
    })

    surface.CreateFont("NaiFont_Large", {
        font = activeFontName,
        size = 22,
        weight = 600,
        antialias = true,
    })

    surface.CreateFont("NaiFont_Title", {
        font = activeFontName,
        size = 26,
        weight = 700,
        antialias = true,
    })

    surface.CreateFont("NaiFont_Bold", {
        font = activeFontName,
        size = 16,
        weight = 700,
        antialias = true,
    })
end

-- Create fonts inside Initialize so the renderer is fully ready
hook.Add("Initialize", "NPCPassengers_CreateFonts", function()
    InstallAddonFonts()
    CreateNaiFonts()
end)
-- Also create them immediately in case Initialize already fired (e.g. Lua file refresh)
InstallAddonFonts()
CreateNaiFonts()

local function Lerp(t, a, b)
    return a + (b - a) * t
end

local function LerpColor(t, col1, col2)
    return Color(
        Lerp(t, col1.r, col2.r),
        Lerp(t, col1.g, col2.g),
        Lerp(t, col1.b, col2.b),
        Lerp(t, col1.a or 255, col2.a or 255)
    )
end

local TransparentColor = Color(0, 0, 0, 0)

local function AnimateButtonVisualState(button, hoverInSpeed, hoverOutSpeed, pressInSpeed, pressOutSpeed)
    local hovered = button:IsHovered()
    local pressed = button:IsDown()

    -- Bouncy hover animation using easing
    local hoverTarget = hovered and 1 or 0
    local hoverSpeed = hovered and (hoverInSpeed or 12) or (hoverOutSpeed or 8)
    button.hoverAnim = math.Approach(button.hoverAnim or 0, hoverTarget, FrameTime() * hoverSpeed)

    button.pressAnim = math.Approach(button.pressAnim or 0, pressed and 1 or 0, FrameTime() * (pressed and (pressInSpeed or 18) or (pressOutSpeed or 12)))

    return button.hoverAnim, button.pressAnim
end

local function HandleButtonHoverSound(button)
    if button:IsHovered() then
        if not button.hasPlayedHoverSound then
            if GetConVar("nai_npc_ui_sounds_enabled"):GetBool() and GetConVar("nai_npc_ui_hover_enabled"):GetBool() then
                surface.PlaySound("nai_passengers/ui_hover.wav")
            end
            button.hasPlayedHoverSound = true
        end
    else
        button.hasPlayedHoverSound = false
    end
end

local function GetButtonPushOffset(button, distance)
    return math.floor((button.pressAnim or 0) * (distance or 2) + 0.5)
end

local function DrawRoundedSurface(x, y, w, h, radius, fillColor, borderColor)
    if borderColor then
        draw.RoundedBox(radius, x, y, w, h, borderColor)
        draw.RoundedBox(math.max(radius - 1, 0), x + 1, y + 1, math.max(w - 2, 0), math.max(h - 2, 0), fillColor)
        return
    end

    draw.RoundedBox(radius, x, y, w, h, fillColor)
end

local function RotatePoint(x, y, angleRadians)
    local angleCos = math.cos(angleRadians)
    local angleSin = math.sin(angleRadians)
    return x * angleCos - y * angleSin, x * angleSin + y * angleCos
end

local function DrawRotatedQuad(cx, cy, halfWidth, halfHeight, angleDegrees, color)
    local angleRadians = math.rad(angleDegrees)
    local x1, y1 = RotatePoint(-halfWidth, -halfHeight, angleRadians)
    local x2, y2 = RotatePoint(halfWidth, -halfHeight, angleRadians)
    local x3, y3 = RotatePoint(halfWidth, halfHeight, angleRadians)
    local x4, y4 = RotatePoint(-halfWidth, halfHeight, angleRadians)

    surface.SetDrawColor(color)
    draw.NoTexture()
    surface.DrawPoly({
        { x = cx + x1, y = cy + y1 },
        { x = cx + x2, y = cy + y2 },
        { x = cx + x3, y = cy + y3 },
        { x = cx + x4, y = cy + y4 },
    })
end

local function DrawRotatingCross(cx, cy, size, angleDegrees, color)
    local angleRadians = math.rad(angleDegrees)
    local x1, y1 = RotatePoint(-size, -size, angleRadians)
    local x2, y2 = RotatePoint(size, size, angleRadians)
    local x3, y3 = RotatePoint(size, -size, angleRadians)
    local x4, y4 = RotatePoint(-size, size, angleRadians)

    surface.SetDrawColor(color)
    surface.DrawLine(cx + x1, cy + y1, cx + x2, cy + y2)
    surface.DrawLine(cx + x3, cy + y3, cx + x4, cy + y4)
end

local function DrawMarqueeText(panel, text, font, x, y, color, maxWidth, alignY, padding, speed)
    if not IsValid(panel) or not text or maxWidth <= 0 then
        return
    end

    surface.SetFont(font)
    local textWidth = surface.GetTextSize(text)
    if textWidth <= maxWidth then
        draw.SimpleText(text, font, x, y, color, TEXT_ALIGN_LEFT, alignY or TEXT_ALIGN_CENTER)
        return
    end

    local clipX, clipY = panel:LocalToScreen(x, y - panel:GetTall())
    local clipTop = select(2, panel:LocalToScreen(0, 0))
    local clipBottom = select(2, panel:LocalToScreen(0, panel:GetTall()))
    local screenX = select(1, panel:LocalToScreen(x, 0))
    local offsetRange = textWidth - maxWidth
    local cycle = math.max((padding or 24) + offsetRange, 1)
    local time = CurTime() * (speed or 22)
    local normalized = (math.sin(time / cycle) + 1) * 0.5
    local textOffset = math.floor(normalized * offsetRange + 0.5)

    render.SetScissorRect(screenX, clipTop, screenX + maxWidth, clipBottom, true)
    draw.SimpleText(text, font, x - textOffset, y, color, TEXT_ALIGN_LEFT, alignY or TEXT_ALIGN_CENTER)
    render.SetScissorRect(0, 0, 0, 0, false)
end

-- UI Components
local function CreateLabel(parent, text, font, color)
    local label = vgui.Create("DLabel", parent)
    label:SetText(text)
    label:SetFont(font or "DermaDefault")
    label:SetTextColor(color or Theme.text)
    label:SizeToContents()
    return label
end

local function CreateSectionHeader(parent, text)
    local header = vgui.Create("DPanel", parent)
    header.SearchSectionTitle = text
    header:SetTall(38)
    header:Dock(TOP)
    header:DockMargin(0, 15, 0, 8)

    header.Paint = function(self, w, h)
        local accentColor = Theme.accent

        -- Gradient background
        local gradientMat = Material("vgui/gradient-d")
        surface.SetDrawColor(accentColor.r, accentColor.g, accentColor.b, 80)
        surface.SetMaterial(gradientMat)
        surface.DrawTexturedRect(0, 0, w, h)

        -- Accent line at bottom
        surface.SetDrawColor(accentColor)
        surface.DrawRect(0, h - 3, w, 3)

        -- Glow effect
        draw.RoundedBox(0, 0, h - 3, w, 3, Color(accentColor.r, accentColor.g, accentColor.b, Theme.glow.a or 30))

        -- Icon
        surface.SetDrawColor(accentColor)
        surface.SetMaterial(Material("icon16/star.png"))
        surface.DrawTexturedRect(12, (h - 16) / 2, 16, 16)

        -- Text
        local textCol = Theme.textBright
        draw.SimpleText(text, "NaiFont_Medium", 36, h / 2, textCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end
    return header
end

local function CreateSubHeader(parent, text)
    local header = vgui.Create("DPanel", parent)
    header.SearchSectionTitle = text
    header:SetTall(28)
    header:Dock(TOP)
    header:DockMargin(5, 12, 5, 6)
    header.Paint = function(self, w, h)
        local accentColor = Theme.accent

        -- Left accent bar
        draw.RoundedBox(2, 0, 0, 4, h, accentColor)

        -- Bottom gradient line
        local gradientMat = Material("vgui/gradient-r")
        surface.SetDrawColor(accentColor.r, accentColor.g, accentColor.b, 60)
        surface.SetMaterial(gradientMat)
        surface.DrawTexturedRect(0, h - 2, w, 2)

        DrawMarqueeText(self, text, "NaiFont_Bold", 12, h/2 - 2, accentColor, math.max(w - 18, 0), TEXT_ALIGN_CENTER, 28, 18)
    end
    return header
end

local function CreateHelpText(parent, text)
    local help = vgui.Create("DLabel", parent)
    help.SearchHelpText = text
    help:SetText(text)
    help:SetFont("NaiFont_Small")
    help:SetTextColor(Theme.textDim)
    help:SetWrap(true)
    help:SetAutoStretchVertical(true)
    help:Dock(TOP)
    help:DockMargin(5, 0, 5, 6)
    return help
end

-- Ensure a safe draw.Circle implementation exists (some environments don't provide it)
if not draw.Circle then
    function draw.Circle(cx, cy, radius, segs)
        segs = segs or 32
        local verts = {}
        for i = 0, segs do
            local a = math.rad((i / segs) * 360)
            verts[#verts + 1] = {
                x = cx + math.cos(a) * radius,
                y = cy + math.sin(a) * radius,
                u = (math.cos(a) + 1) * 0.5,
                v = (math.sin(a) + 1) * 0.5
            }
        end
        draw.NoTexture()
        surface.DrawPoly(verts)
    end
end

local function CreateCheckbox(parent, label, convar)
    local container = vgui.Create("DPanel", parent)
    container.SearchLabel = label
    container.SearchConVar = convar
    container:SetTall(32)
    container:Dock(TOP)
    container:DockMargin(5, 3, 5, 3)
    container.hoverAnim = 0
    container.hasPlayedHoverSound = false
    container.Paint = function(self, w, h)
        -- Hover animation
        local animationsEnabled = GetConVar("nai_npc_ui_animations"):GetBool()
        local hovered = self:IsHovered()
        local hoverTarget = hovered and 1 or 0
        if animationsEnabled then
            self.hoverAnim = math.Approach(self.hoverAnim or 0, hoverTarget, FrameTime() * (hovered and 8 or 6))
        else
            self.hoverAnim = hoverTarget
        end

        if self.hoverAnim > 0 then
            draw.RoundedBox(6, 0, 0, w, h, Theme.bgLight)
            if not self.hasPlayedHoverSound then
                if GetConVar("nai_npc_ui_sounds_enabled"):GetBool() and GetConVar("nai_npc_ui_hover_enabled"):GetBool() then
                    surface.PlaySound("nai_passengers/ui_hover.wav")
                end
                self.hasPlayedHoverSound = true
            end
        else
            self.hasPlayedHoverSound = false
        end
    end
    
    local checkbox = vgui.Create("DCheckBox", container)
    checkbox:SetPos(8, 6)
    checkbox:SetSize(20, 20)
    checkbox:SetConVar(convar)

    -- Animation state for checkbox tick pop effect
    checkbox.animScale = 1
    checkbox.popTimer = 0
    checkbox.hoverAnim = 0
    checkbox.checkedAnim = 0  -- Animation for enabled/disabled state transition

    -- Override background to remove square
    checkbox.Paint = function(self, w, h)
        -- Don't draw default background
    end

    -- Custom animated rendering
    checkbox.Think = function(self)
        local animationsEnabled = GetConVar("nai_npc_ui_animations"):GetBool()

        -- Hover animation for checkbox circle
        local hovered = self:IsHovered()
        local hoverTarget = hovered and 1 or 0
        if animationsEnabled then
            self.hoverAnim = math.Approach(self.hoverAnim or 0, hoverTarget, FrameTime() * (hovered and 8 or 6))
        else
            self.hoverAnim = hoverTarget
        end

        -- Enabled/disabled state animation
        local cv = GetConVar(convar)
        local isChecked = cv and cv:GetBool() or false
        local checkedTarget = isChecked and 1 or 0
        if animationsEnabled then
            self.checkedAnim = math.Approach(self.checkedAnim or 0, checkedTarget, FrameTime() * (isChecked and 12 or 8))
        else
            self.checkedAnim = checkedTarget
        end

        -- Popup animation on toggle (dot only)
        if animationsEnabled and self.popTimer > 0 then
            self.popTimer = self.popTimer - FrameTime()
            -- Bouncy popup for dot
            if self.popTimer > 0.12 then
                self.animScale = Lerp(FrameTime() * 12, self.animScale, 1.2)
            elseif self.popTimer > 0.06 then
                self.animScale = Lerp(FrameTime() * 15, self.animScale, 0.9)
            else
                self.animScale = Lerp(FrameTime() * 10, self.animScale, 1)
            end
        else
            self.animScale = Lerp(FrameTime() * 8, self.animScale, 1)
        end
    end

    -- Trigger pop animation on state change
    checkbox.OnChange = function(self, val)
        local animationsEnabled = GetConVar("nai_npc_ui_animations"):GetBool()
        if animationsEnabled then
            self.popTimer = 0.18  -- 180ms pop animation
            if val then
                -- Checking: start dot from 0, animate with bounce
                self.animScale = 0
            else
                -- Unchecking: no scale animation, just color fade
                self.animScale = 1
            end
        end
        
        if IsValid(LocalPlayer()) and GetConVar("nai_npc_ui_sounds_enabled"):GetBool() and GetConVar("nai_npc_ui_click_enabled"):GetBool() then
            LocalPlayer():EmitSound("nai_passengers/ui_click.wav", 75, val and 100 or 80)
        end
    end

    checkbox.PaintOver = function(self, w, h)
        -- Get checked state directly from convar for reliability
        local cv = GetConVar(convar)
        local isChecked = cv and cv:GetBool() or false
        
        local centerX, centerY = w / 2, h / 2
        local baseRadius = math.min(w, h) / 2 - 1
        
        -- Apply hover scale animation (10% scale increase on hover) - only for circle
        local hoverScale = 1 + (self.hoverAnim or 0) * 0.1
        
        -- Main circle radius with hover scale only (no popup)
        local radius = baseRadius * hoverScale
        
        -- Apply popup animation to checked dot only
        local dotPopScale = self.animScale or 1
        
        -- Interpolate colors based on checked animation state
        local checkedAnim = self.checkedAnim or 0
        local borderCol = LerpColor(checkedAnim, Theme.border, Theme.accentHover)
        local fillCol = LerpColor(checkedAnim, Theme.bgLighter, Theme.accent)

        -- Outer glow with animation
        if checkedAnim > 0 then
            draw.NoTexture()
            surface.SetDrawColor(Theme.glow.r, Theme.glow.g, Theme.glow.b, Theme.glow.a * checkedAnim)
            draw.Circle(centerX, centerY, radius + 3, 32)
        end

        -- Main circle
        draw.NoTexture()
        surface.SetDrawColor(fillCol)
        draw.Circle(centerX, centerY, radius, 32)

        -- Border
        surface.SetDrawColor(borderCol)
        draw.Circle(centerX, centerY, radius, 32)

        -- Checked dot with popup animation
        if checkedAnim > 0.01 then
            surface.SetDrawColor(Theme.textBright)
            draw.Circle(centerX, centerY, (radius * 0.5) * dotPopScale, 32)
        end
    end
    
    local lbl = CreateLabel(container, label, "NaiFont_Normal", Theme.text)
    lbl:SetPos(36, 6)
    lbl:SetMouseInputEnabled(true)
    lbl:SetCursor("hand")
    lbl.DoClick = function()
        checkbox:Toggle()
    end
    
    container.OnMousePressed = function()
        checkbox:Toggle()
    end
    
    return container, checkbox
end

-- Global table to track all slider knobs for panel transparency logic
-- When any slider in this table is being dragged, the panel becomes 70% transparent
local uiSliders = {}

local function CreateSlider(parent, label, convar, min, max, decimals)
    local container = vgui.Create("DPanel", parent)
    container.SearchLabel = label
    container.SearchConVar = convar
    container:SetTall(52)
    container:Dock(TOP)
    container:DockMargin(5, 3, 5, 3)
    container.Paint = function() end

    local lbl = CreateLabel(container, label, "NaiFont_Normal", Theme.text)
    lbl:Dock(TOP)
    lbl:SetTall(20)

    local sliderContainer = vgui.Create("DPanel", container)
    sliderContainer:Dock(TOP)
    sliderContainer:SetTall(28)
    sliderContainer:DockMargin(0, 2, 0, 0)
    sliderContainer.Paint = function() end

    local slider = vgui.Create("DNumSlider", sliderContainer)
    slider:Dock(FILL)
    slider:SetMin(min)
    slider:SetMax(max)
    slider:SetDecimals(decimals or 0)
    slider:SetConVar(convar)
    slider.Label:SetVisible(false)

    -- Force sync with ConVar value on creation (delayed to ensure ConVar is ready)
    timer.Simple(0, function()
        if IsValid(slider) then
            local cv = GetConVar(convar)
            if cv then
                slider:SetValue(cv:GetFloat())
            end
        end
    end)

    slider.Slider.Paint = function(self, w, h)
        local trackY = h / 2
        draw.RoundedBox(3, 0, trackY - 3, w, 6, Theme.bgLighter)

        local frac = math.Clamp((slider:GetValue() - min) / (max - min), 0, 1)
        local filledW = w * frac
        draw.RoundedBox(3, 0, trackY - 3, filledW, 6, Theme.accent)
    end

    slider.Slider.Knob:SetSize(14, 14)
    slider.Slider.Knob.isDragging = false  -- Track if this slider knob is being dragged

    -- Wrap the original OnMousePressed to set dragging state
    local originalOnMousePressed = slider.Slider.Knob.OnMousePressed
    slider.Slider.Knob.OnMousePressed = function(self, mcode)
        self.isDragging = true  -- Mark as dragging when mouse is pressed on knob
        if originalOnMousePressed then
            return originalOnMousePressed(self, mcode)  -- Call original handler
        end
    end

    -- Wrap the original OnMouseReleased to clear dragging state
    local originalOnMouseReleased = slider.Slider.Knob.OnMouseReleased
    slider.Slider.Knob.OnMouseReleased = function(self, mcode)
        self.isDragging = false  -- Clear dragging state when mouse is released
        if originalOnMouseReleased then
            return originalOnMouseReleased(self, mcode)  -- Call original handler
        end
    end

    slider.Slider.Knob.Paint = function(self, w, h)
        draw.RoundedBox(7, 0, 0, w, h, Theme.accent)
        if self:IsHovered() then
            draw.RoundedBox(7, 0, 0, w, h, Theme.accentHover)
        end
    end

    -- Add this slider knob to the global tracking table for panel fade logic
    table.insert(uiSliders, slider.Slider.Knob)

    slider.TextArea:SetWide(60)
    slider.TextArea:SetTextColor(Theme.text)
    slider.TextArea.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Theme.bgLighter)
        self:DrawTextEntryText(Theme.text, Theme.accent, Theme.text)
    end

    return container, slider
end

local function CreateComboBox(parent, label, convar, options)
    local container = vgui.Create("DPanel", parent)
    container.SearchLabel = label
    container.SearchConVar = convar
    container:SetTall(54)
    container:Dock(TOP)
    container:DockMargin(5, 3, 5, 3)
    container.Paint = function() end
    
    local lbl = CreateLabel(container, label, "NaiFont_Normal", Theme.text)
    lbl:SetPos(0, 0)
    
    local combo = vgui.Create("DComboBox", container)
    combo:SetPos(0, 22)
    combo:SetSize(300, 26)
    combo:SetTextColor(Theme.text)
    combo:SetFont("NaiFont_Normal")
    combo:SetSortItems(false)
    
    combo.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Theme.bgLighter)
        surface.SetDrawColor(Theme.border)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        draw.SimpleText("v", "NaiFont_Small", w - 15, h/2, Theme.textDim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    
    for _, opt in ipairs(options) do
        combo:AddChoice(opt.label, opt.value)
    end
    
    local currentVal = GetConVar(convar):GetInt()
    for _, opt in ipairs(options) do
        if opt.value == currentVal then
            combo:SetValue(opt.label)
            break
        end
    end
    
    combo.OnSelect = function(self, index, value, data)
        RunConsoleCommand(convar, tostring(data))
    end
    
    return container, combo
end

local function CreateButton(parent, text, callback)
    local btn = vgui.Create("DButton", parent)
    btn.SearchLabel = text
    btn:SetText(text)
    btn:SetFont("NaiFont_Medium")
    btn:SetTall(40)
    btn:Dock(TOP)
    btn:DockMargin(8, 6, 8, 6)
    btn:SetTextColor(TransparentColor)
    btn.hoverAnim = 0
    btn.pressAnim = 0
    btn.hasPlayedHoverSound = false
    
    btn.Paint = function(self, w, h)
        AnimateButtonVisualState(self, 6, 8, 18, 12)
        HandleButtonHoverSound(self)

        local pushOffset = GetButtonPushOffset(self, 2)
        local bgColor = LerpColor(self.hoverAnim, Theme.accent, Theme.accentHover)
        bgColor = LerpColor(self.pressAnim, bgColor, Theme.accentActive)

        if self.hoverAnim > 0 then
            local glowAlpha = 50 * self.hoverAnim
            draw.RoundedBox(8, -2, -2 + pushOffset, w + 4, h + 4, ColorAlpha(Theme.accent, glowAlpha))
        end

        draw.RoundedBox(8, 2, 2 - self.pressAnim, w, h, Theme.shadow)
        draw.RoundedBox(7, 0, pushOffset, w, h, bgColor)

        local gradientMat = Material("vgui/gradient-d")
        surface.SetDrawColor(255, 255, 255, 15)
        surface.SetMaterial(gradientMat)
        surface.DrawTexturedRect(0, pushOffset, w, h / 2)

        surface.SetDrawColor(Theme.accentHover.r, Theme.accentHover.g, Theme.accentHover.b, 60)
        surface.DrawOutlinedRect(0, pushOffset, w, h, 1)
        draw.SimpleText(self:GetText(), "NaiFont_Medium", w / 2, (h / 2) + pushOffset, Theme.textBright, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    
    btn.DoClick = function()
        if GetConVar("nai_npc_ui_sounds_enabled"):GetBool() and GetConVar("nai_npc_ui_click_enabled"):GetBool() then
            surface.PlaySound("nai_passengers/ui_click.wav")
        end
        if callback then callback() end
    end
    
    return btn
end

local function CreateSpacer(parent, height)
    local spacer = vgui.Create("DPanel", parent)
    spacer:SetTall(height or 10)
    spacer:Dock(TOP)
    spacer.Paint = function() end
    return spacer
end

-- Track all scrollbars for live smoothness updates
local sidebarScrollbars = {}

local function StyleScrollbar(sbar)
    sbar:SetWide(8)
    sbar:SetHideButtons(true)

    -- Track this scrollbar for live updates
    table.insert(sidebarScrollbars, sbar)

    -- Smooth scrolling
    if not sbar.smoothScroll then
        sbar.smoothScroll = 0
        sbar.scrollTarget = 0
        -- Get smoothness from convar (0.01-1, lower = smoother but slower)
        local smoothness = GetConVar("nai_npc_ui_scroll_smoothness")
        sbar.smoothScrollSpeed = smoothness and math.Clamp(smoothness:GetFloat(), 0.01, 1) or 0.15
    end

    -- Auto-hide state: scrollbar fades out when not in use
    sbar.activeAlpha = 0      -- 0 = hidden, 1 = visible
    sbar.lastScrollAt = 0     -- last time the scrollbar's value changed

    sbar.Think = function(self)
        if self.smoothScroll ~= self.scrollTarget then
            self.smoothScroll = Lerp(self.smoothScrollSpeed, self.smoothScroll, self.scrollTarget)
            self:SetScroll(self.smoothScroll)
            self.lastScrollAt = CurTime()
        end

        -- Determine if the scrollbar should be visible
        local autohide = GetConVar("nai_npc_ui_scrollbar_autohide")
        local autohideOn = autohide and autohide:GetBool()

        local shouldShow
        if not autohideOn then
            shouldShow = true
        else
            -- Show while hovered, while the grip is hovered,
            -- or for ~1 second after the last scroll update
            local hovered = self:IsHovered()
                or (IsValid(self.btnGrip) and self.btnGrip:IsHovered())
            local recentlyScrolled = (CurTime() - (self.lastScrollAt or 0)) < 1.0
            shouldShow = hovered or recentlyScrolled
        end

        local target = shouldShow and 1 or 0
        self.activeAlpha = math.Approach(self.activeAlpha or 0, target, FrameTime() * (shouldShow and 8 or 4))
    end

    sbar.OnMouseWheeled = function(self, delta)
        local parent = self:GetParent()
        local canvas = parent and parent.GetCanvas and parent:GetCanvas()
        local canvasHeight = canvas and canvas:GetTall() or 0
        local scrollMax = math.max(0, canvasHeight - self:GetTall())
        self.scrollTarget = self.scrollTarget - delta * 50
        self.scrollTarget = math.Clamp(self.scrollTarget, 0, scrollMax)
        self.lastScrollAt = CurTime()
        return true
    end

    sbar.Paint = function(self, w, h)
        local a = self.activeAlpha or 1
        if a <= 0.01 then return end
        local trackCol = Theme.bgDark
        draw.RoundedBox(4, 0, 0, w, h, Color(trackCol.r, trackCol.g, trackCol.b, (trackCol.a or 255) * a))
    end
    sbar.btnUp.Paint = function() end
    sbar.btnDown.Paint = function() end
    sbar.btnGrip.Paint = function(self, w, h)
        local parentBar = self:GetParent()
        local a = (parentBar and parentBar.activeAlpha) or 1
        if a <= 0.01 then return end
        local baseCol = self:IsHovered() and Theme.accentHover or Theme.scrollbarGrip
        draw.RoundedBox(4, 0, 0, w, h, Color(baseCol.r, baseCol.g, baseCol.b, (baseCol.a or 255) * a))
    end
end

-- Main Settings Panel
local settingsFrame = nil

local function AreUIAnimationsEnabled()
    local cvar = GetConVar("nai_npc_ui_animations")
    return cvar and cvar:GetBool()
end

local function AnimateSettingsFrameIn(frame, targetX, targetY)
    if not IsValid(frame) then
        return
    end

    if not AreUIAnimationsEnabled() then
        frame:SetPos(targetX, targetY)
        frame:SetAlpha(255)
        return
    end

    frame:Stop()
    frame:SetAlpha(0)
    frame:SetPos(targetX, ScrH() + 50)

    -- Smooth entrance
    frame:AlphaTo(255, 0.3, 0)
    frame:MoveTo(targetX, targetY, 0.35, 0, -1)
end

-- Module-level variables for Passengers tab (reduces local variable count in OpenSettingsPanel)
local passengerControlList
local passengerFilterQuery = ""
local passengerSortMode = "vehicle"
local passengersCurrentVehicleOnly = false
local passengerAutoRefreshEnabled = false
local nextPassengerAutoRefresh = 0
local passengerOverviewPanel
local currentVehicleOnlyBtn
local passengerAutoRefreshBtn

local function OpenSettingsPanel()
    if IsValid(settingsFrame) then
        settingsFrame:Remove()
    end

    -- Clear the slider tracking table to avoid tracking sliders from previous panel instances
    -- This prevents stale references when the panel is reopened
    if uiSliders then
        for i = #uiSliders, 1, -1 do
            uiSliders[i] = nil
        end
    else
        uiSliders = {}
    end
    
    local panelWidth = GetConVar("nai_npc_ui_panel_width"):GetInt()
    local panelHeight = GetConVar("nai_npc_ui_panel_height"):GetInt()
    
    settingsFrame = vgui.Create("DFrame")
    settingsFrame:SetSize(panelWidth, panelHeight)
    settingsFrame:Center()
    local targetX, targetY = settingsFrame:GetPos()
    settingsFrame:SetTitle("")
    settingsFrame:SetDeleteOnClose(true)
    settingsFrame.isClosingAnimated = false

    local defaultClose = settingsFrame.Close
    settingsFrame.Close = function(self)
        if not IsValid(self) then
            return
        end

        if self.isClosingAnimated then
            return
        end

        if not AreUIAnimationsEnabled() then
            defaultClose(self)
            return
        end

        self.isClosingAnimated = true
        self:SetMouseInputEnabled(false)
        self:SetKeyboardInputEnabled(false)
        self:Stop()
        local closeX = self:GetX()

        -- Smooth close animation
        self:AlphaTo(0, 0.2, 0)
        self:MoveTo(closeX, ScrH() + 50, 0.25, 0, -1, function()
            if IsValid(self) then
                defaultClose(self)
            end
        end)
    end
    settingsFrame:MakePopup()
    AnimateSettingsFrameIn(settingsFrame, targetX, targetY)

    -- PANEL TRANSPARENCY LOGIC
    -- Panel becomes 70% transparent ONLY when dragging a SLIDER knob
    -- No idle fade when mouse is not over panel (that feature was causing issues)
    settingsFrame.Think = function(self)
        -- Check if any SLIDER knob is being dragged
        local anySliderDragging = false
        for _, knob in ipairs(uiSliders or {}) do
            if IsValid(knob) and knob.isDragging then
                anySliderDragging = true
                break
            end
        end

        if anySliderDragging then
            -- SLIDER DRAGGING: Set panel to 70% transparent (30% opaque = 76.5 alpha)
            self:SetAlpha(76.5)
        else
            -- NOT DRAGGING: Keep panel fully opaque
            if self:GetAlpha() ~= 255 then
                self:SetAlpha(255)
            end
        end

        -- Passenger auto-refresh logic
        if not passengerAutoRefreshEnabled then
            return
        end

        if currentPanel ~= passengersPanel then
            return
        end

        if CurTime() < nextPassengerAutoRefresh then
            return
        end

        nextPassengerAutoRefresh = CurTime() + 0.75
        RefreshPassengersControlList()
    end

    settingsFrame.Paint = function(self, w, h)
        local isMinimized = self.isMinimized or false

        -- Subtle shadow/glow effect
        draw.RoundedBox(12, 0, 0, w, h, Color(0, 0, 0, 80))

        -- Main background with subtle gradient
        draw.RoundedBox(11, 1, 1, w - 2, h - 2, Theme.bg)

        -- Subtle inner border
        draw.RoundedBox(10, 2, 2, w - 4, h - 4, Color(255, 255, 255, 3))

        -- Header with enhanced gradient
        local gradientMat = Material("vgui/gradient-d")
        if isMinimized then
            -- Minimized state - full gradient
            surface.SetDrawColor(Theme.accentDark.r, Theme.accentDark.g, Theme.accentDark.b, 80)
            surface.SetMaterial(gradientMat)
            draw.RoundedBox(12, 0, 0, w, h, Theme.bgDark)
            draw.RoundedBox(12, 0, 0, w, h, Color(Theme.accentDark.r, Theme.accentDark.g, Theme.accentDark.b, 30))
        else
            -- Normal state - header only
            surface.SetDrawColor(Theme.accentDark.r, Theme.accentDark.g, Theme.accentDark.b, 100)
            surface.SetMaterial(gradientMat)
            draw.RoundedBoxEx(12, 0, 0, w, 50, Theme.bgDark, true, true, false, false)

            -- Add subtle glow to header
            draw.RoundedBoxEx(12, 0, 0, w, 50, Color(Theme.accent.r, Theme.accent.g, Theme.accent.b, 15), true, true, false, false)

            -- Accent line under header with glow
            surface.SetDrawColor(Theme.accent)
            surface.DrawRect(0, 50, w, 2)
            surface.SetDrawColor(Theme.accent.r, Theme.accent.g, Theme.accent.b, 50)
            surface.DrawRect(0, 52, w, 1)
        end

        -- Title text with enhanced shadow
        draw.SimpleText(ADDON_DISPLAY_NAME .. " Settings", "NaiFont_Title", 22, 27, Color(0, 0, 0, 150), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText(ADDON_DISPLAY_NAME .. " Settings", "NaiFont_Title", 20, 25, Theme.textBright, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    settingsFrame.btnClose:SetVisible(false)
    settingsFrame.btnMaxim:SetVisible(false)
    settingsFrame.btnMinim:SetVisible(false)

    settingsFrame.isMinimized = false
    settingsFrame.originalHeight = settingsFrame:GetTall()

    local minimizeBtn = vgui.Create("DButton", settingsFrame)
    minimizeBtn:SetPos(settingsFrame:GetWide() - 70, 12)
    minimizeBtn:SetSize(28, 28)
    minimizeBtn:SetText("")
    minimizeBtn.hoverAnim = 0
    minimizeBtn.scaleAnim = 0
    minimizeBtn.Paint = function(self, w, h)
        AnimateButtonVisualState(self, 8, 10, 18, 12)

        -- Scale animation on hover
        local scale = 1 + (self.hoverAnim or 0) * 0.1
        local scaledW = w * scale
        local scaledH = h * scale
        local offsetX = (w - scaledW) / 2
        local offsetY = (h - scaledH) / 2

        local pushOffset = GetButtonPushOffset(self, 2)
        local baseColor = Theme.bgLight
        local hoverColor = Theme.accent
        local col = LerpColor(self.hoverAnim, baseColor, hoverColor)

        -- Button background with subtle border and scale
        draw.RoundedBox(6, offsetX, offsetY + pushOffset, scaledW, scaledH, col)
        draw.RoundedBox(5, offsetX + 1, offsetY + 1 + pushOffset, scaledW - 2, scaledH - 2, Color(255, 255, 255, 10))

        local iconColor = Theme.textBright
        surface.SetDrawColor(iconColor)

        -- Scale icon position
        local iconOffsetX = (w - scaledW) / 2
        local iconOffsetY = (h - scaledH) / 2

        if settingsFrame.isMinimized then
            -- Plus icon
            surface.DrawLine(8 + iconOffsetX, h/2 + iconOffsetY + pushOffset, w - 8 + iconOffsetX, h/2 + iconOffsetY + pushOffset)
            surface.DrawLine(w/2 + iconOffsetX, 8 + iconOffsetY + pushOffset, w/2 + iconOffsetX, h - 8 + iconOffsetY + pushOffset)
        else
            -- Minus icon
            surface.DrawLine(8 + iconOffsetX, h/2 + iconOffsetY + pushOffset, w - 8 + iconOffsetX, h/2 + iconOffsetY + pushOffset)
        end
    end
    minimizeBtn.DoClick = function()
        if not IsValid(settingsFrame) then return end
        settingsFrame.isMinimized = not settingsFrame.isMinimized

        if AreUIAnimationsEnabled() then
            if settingsFrame.isMinimized then
                settingsFrame.originalHeight = settingsFrame:GetTall()
                -- Smooth collapse animation
                settingsFrame:SizeTo(settingsFrame:GetWide(), 50, 0.25, 0, -1)
            else
                -- Smooth expand animation
                settingsFrame:SizeTo(settingsFrame:GetWide(), settingsFrame.originalHeight, 0.3, 0, -1)
            end
        else
            if settingsFrame.isMinimized then
                settingsFrame.originalHeight = settingsFrame:GetTall()
                settingsFrame:SetTall(50)
            else
                settingsFrame:SetTall(settingsFrame.originalHeight)
            end
        end

        minimizeBtn:SetTooltip(settingsFrame.isMinimized and "Expand panel" or "Minimize panel")
    end
    minimizeBtn:SetTooltip("Minimize panel")

    local closeBtn = vgui.Create("DButton", settingsFrame)
    closeBtn:SetPos(settingsFrame:GetWide() - 38, 12)
    closeBtn:SetSize(28, 28)
    closeBtn:SetText("")
    closeBtn.hoverAnim = 0
    closeBtn.pressAnim = 0
    closeBtn.Paint = function(self, w, h)
        AnimateButtonVisualState(self, 8, 10, 18, 12)

        -- Scale animation on hover
        local scale = 1 + (self.hoverAnim or 0) * 0.1
        local scaledW = w * scale
        local scaledH = h * scale
        local offsetX = (w - scaledW) / 2
        local offsetY = (h - scaledH) / 2

        local pushOffset = GetButtonPushOffset(self, 2)
        local baseColor = Theme.bgLight
        local hoverColor = Theme.error
        local col = LerpColor(self.hoverAnim, baseColor, hoverColor)
        local pressedColor = Color(180, 60, 60)
        col = LerpColor(self.pressAnim, col, pressedColor)

        -- Button background with subtle border and scale
        draw.RoundedBox(6, offsetX, offsetY + pushOffset, scaledW, scaledH, col)
        draw.RoundedBox(5, offsetX + 1, offsetY + 1 + pushOffset, scaledW - 2, scaledH - 2, Color(255, 255, 255, 10))

        local iconColor = Theme.textBright
        surface.SetDrawColor(iconColor)

        -- Scale icon position
        local iconOffsetX = (w - scaledW) / 2
        local iconOffsetY = (h - scaledH) / 2

        surface.DrawLine(8 + iconOffsetX, 8 + iconOffsetY + pushOffset, w - 8 + iconOffsetX, h - 8 + iconOffsetY + pushOffset)
        surface.DrawLine(w - 8 + iconOffsetX, 8 + iconOffsetY + pushOffset, 8 + iconOffsetX, h - 8 + iconOffsetY + pushOffset)
    end
    closeBtn.DoClick = function()
        if IsValid(settingsFrame) then
            settingsFrame:Close()
        end
    end

    -- Version badge button
    local versionBtn = vgui.Create("DButton", settingsFrame)
    local titleText = ADDON_DISPLAY_NAME .. " Settings"
    surface.SetFont("NaiFont_Title")
    local titleWidth = surface.GetTextSize(titleText)
    local versionW = 55
    local versionH = 20
    local versionX = 20 + titleWidth + 10
    local versionY = 15
    versionBtn:SetPos(versionX, versionY)
    versionBtn:SetSize(versionW, versionH)
    versionBtn:SetText("")
    versionBtn.hoverAnim = 0
    versionBtn.Paint = function(self, w, h)
        AnimateButtonVisualState(self, 8, 10, 18, 12)

        local pushOffset = GetButtonPushOffset(self, 1)
        local baseColor = Theme.accentDark
        local hoverColor = Theme.accent
        local col = LerpColor(self.hoverAnim, baseColor, hoverColor)
        draw.RoundedBox(10, 0, pushOffset, w, h, col)
        draw.SimpleText("v" .. NPCPassengers.Version, "NaiFont_Small", w/2, h/2 + pushOffset, Theme.textBright, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    versionBtn.DoClick = function()
        if IsValid(settingsFrame) then
            settingsFrame:Close()
        end
        timer.Simple(0.1, function() ShowWelcomePanel(true) end)
    end
    versionBtn:SetTooltip("Show welcome screen")

    local navContainer, sidebar, contentArea, searchBox, searchEntry, searchSuggestions, searchMatches, searchStatus, searchClearBtn
    local ClearSearchSuggestions

    local function FocusSearchEntry()
        if not IsValid(searchEntry) then
            return
        end

        searchEntry:RequestFocus()
        searchEntry:SetCaretPos(string.len(searchEntry:GetValue() or ""))
    end

    local function ClearSearchQuery(keepFocus)
        if not IsValid(searchEntry) then
            return
        end

        searchEntry:SetText("")
        ClearSearchSuggestions()

        if IsValid(searchStatus) then
            searchStatus:SetText("Ctrl+F to focus search")
            searchStatus:SetTextColor(Theme.textDim)
            searchStatus:SizeToContents()
        end

        if IsValid(searchClearBtn) then
            searchClearBtn:SetVisible(false)
        end

        if keepFocus then
            FocusSearchEntry()
        end
    end

    local function UpdateSearchSuggestionsLayout()
        if not IsValid(searchSuggestions) or not IsValid(sidebar) then
            return
        end

        local suggestionX = 8
        local suggestionY = 56
        local suggestionW = math.max(sidebar:GetWide() - 24, 120)

        if IsValid(searchBox) then
            suggestionY = searchBox:GetY() + searchBox:GetTall() + 4
        end

        searchSuggestions:SetPos(suggestionX, suggestionY)
        searchSuggestions:SetWide(suggestionW)
        searchSuggestions:MoveToFront()
    end

    -- Live resize: reflow all major child panels when the frame dimensions change
    settingsFrame.PerformLayout = function(self, w, h)
        if IsValid(navContainer) then
            navContainer:SetSize(w - 20, h - 68)
        end
        if IsValid(sidebar) then
            sidebar:SetSize(270, h - 68)
        end
        if IsValid(contentArea) then
            contentArea:SetSize(w - 298, h - 64)
        end
        if IsValid(closeBtn) then
            closeBtn:SetPos(w - 38, 12)
        end

        UpdateSearchSuggestionsLayout()
    end

    -- Side panel navigation system
    navContainer = vgui.Create("DPanel", settingsFrame)
    navContainer:SetPos(10, 58)
    navContainer:SetSize(panelWidth - 20, panelHeight - 68)
    navContainer.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Theme.bgLight)
    end

    -- Left sidebar for navigation
    sidebar = vgui.Create("DScrollPanel", navContainer)
    sidebar:SetPos(0, 0)
    sidebar:SetSize(270, panelHeight - 68)
    sidebar.Paint = function(self, w, h)
        draw.RoundedBoxEx(8, 0, 0, w, h, Theme.bgDark, true, false, true, false)

        -- Right border with glow
        local accentColor = Color(Theme.accent.r, Theme.accent.g, Theme.accent.b, 80)
        surface.SetDrawColor(accentColor)
        surface.DrawRect(w - 2, 0, 2, h)
    end
    StyleScrollbar(sidebar:GetVBar())
    
    -- Right content area
    contentArea = vgui.Create("DPanel", navContainer)
    contentArea:SetPos(278, 0)
    contentArea:SetSize(panelWidth - 298, panelHeight - 64)
    contentArea.Paint = function() end
    
    local currentPanel = nil
    local navButtons = {}
    searchMatches = {}
    
    -- Function to create nav button
    local function CreateNavButton(label, icon)
        local btn = vgui.Create("DButton", sidebar)
        btn:SetText("")
        btn:Dock(TOP)
        btn:DockMargin(8, 4, 8, 4)
        btn:SetTall(46)
        btn.isActive = false
        btn.hoverAnim = 0
        btn.pressAnim = 0
        btn.activeAnim = 0
        btn.iconPath = icon
        btn.hasPlayedHoverSound = false

        btn.Paint = function(self, w, h)
            if self.isActive then
                self.activeAnim = math.Approach(self.activeAnim, 1, FrameTime() * 10)
            else
                self.activeAnim = math.Approach(self.activeAnim, 0, FrameTime() * 10)
            end

            AnimateButtonVisualState(self, 8, 10, 18, 12)
            HandleButtonHoverSound(self)

            local pushOffset = GetButtonPushOffset(self, 2)
            local bgCol = Theme.bgLight
            local accentColor = Theme.accent
            local accentHoverColor = Theme.accentHover
            if self.activeAnim > 0 then
                bgCol = LerpColor(self.activeAnim, Theme.bgLight, accentColor)
            elseif self.hoverAnim > 0 then
                bgCol = LerpColor(self.hoverAnim, Theme.bgLight, Theme.bgLighter)
            end
            bgCol = LerpColor(self.pressAnim, bgCol, Theme.accentActive)

            draw.RoundedBox(6, 0, pushOffset, w, h, bgCol)

            if self.activeAnim > 0 then
                local lineW = 4
                draw.RoundedBox(2, 0, pushOffset, lineW, h, accentHoverColor)
                surface.SetDrawColor(accentColor.r, accentColor.g, accentColor.b, 60 * self.activeAnim)
                surface.DrawRect(-2, pushOffset, w + 4, h)
            end

            if self.hoverAnim > 0 and not self.isActive then
                surface.SetDrawColor(accentColor.r, accentColor.g, accentColor.b, 40 * self.hoverAnim)
                surface.DrawRect(0, h - 2 + pushOffset, w, 2)
            end

            local iconCol = self.isActive and Theme.textBright or (self:IsHovered() and Theme.text or Theme.textDim)
            surface.SetDrawColor(iconCol)
            surface.SetMaterial(Material(icon))
            surface.DrawTexturedRect(12, ((h - 18) / 2) + pushOffset, 18, 18)

            local textCol = self.isActive and Theme.textBright or (self:IsHovered() and Theme.text or Theme.textDim)
            local baseY = (h / 2) + pushOffset

            draw.SimpleText(label, "NaiFont_Normal", 38, baseY, textCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end

        table.insert(navButtons, btn)
        return btn
    end
    
    -- Function to switch panels
    local function SwitchToPanel(panel, activeBtn, suppressSound)
        if not suppressSound and GetConVar("nai_npc_ui_sounds_enabled"):GetBool() and GetConVar("nai_npc_ui_click_enabled"):GetBool() then
            surface.PlaySound("nai_passengers/ui_click.wav")
        end

        if IsValid(currentPanel) then
            currentPanel:SetVisible(false)
        end
        currentPanel = panel
        panel:SetVisible(true)

        for _, btn in ipairs(navButtons) do
            btn.isActive = false
        end

        if IsValid(activeBtn) then
            activeBtn.isActive = true
        end
        
        -- QoL: Auto-focus search bar when switching panels
        timer.Simple(0.05, function()
            if IsValid(searchEntry) then
                searchEntry:RequestFocus()
            end
        end)
    end
    
    -- Helper to create content panel
    local function CreateContentPanel()
        local panel = vgui.Create("DScrollPanel", contentArea)
        panel:Dock(FILL)
        panel:SetVisible(false)
        panel.Paint = function() end
        StyleScrollbar(panel:GetVBar())
        return panel
    end

    local SEARCH_SUGGESTION_LIMIT = 4

    local function NormalizeSearchText(text)
        local normalized = string.lower(tostring(text or ""))
        normalized = string.gsub(normalized, "[_%-%./]", " ")
        normalized = string.gsub(normalized, "%s+", " ")
        return string.Trim(normalized)
    end

    local function BuildSearchKeywords(entry)
        return NormalizeSearchText(table.concat({
            entry.panelName or "",
            entry.section or "",
            entry.title or "",
            entry.description or "",
            entry.convar or ""
        }, " "))
    end

    local function ScrollToSearchTarget(panel, target)
        if not IsValid(panel) or not IsValid(target) then
            return
        end

        panel:InvalidateLayout(true)

        local canvas = panel:GetCanvas()
        local y = 0
        local current = target

        while IsValid(current) and current ~= canvas do
            y = y + current:GetY()
            current = current:GetParent()
        end

        local maxScroll = math.max(canvas:GetTall() - panel:GetTall(), 0)
        panel:GetVBar():AnimateTo(math.Clamp(y - 20, 0, maxScroll), 0.2, 0, 0.2)
    end

    local function CollectSearchEntries()
        local entries = {}

        for _, panel in ipairs(contentArea:GetChildren()) do
            if panel.SearchPanelName and panel.GetCanvas then
                local currentSection = panel.SearchPanelName
                local lastEntry = nil

                for _, child in ipairs(panel:GetCanvas():GetChildren()) do
                    if child.SearchSectionTitle then
                        currentSection = child.SearchSectionTitle
                        lastEntry = nil
                    elseif child.SearchLabel then
                        local entry = {
                            panel = panel,
                            button = panel.SearchNavButton,
                            target = child,
                            panelName = panel.SearchPanelName,
                            section = currentSection,
                            title = child.SearchLabel,
                            description = child.SearchDescription or "",
                            convar = child.SearchConVar or ""
                        }

                        entry.keywords = BuildSearchKeywords(entry)
                        table.insert(entries, entry)
                        lastEntry = entry
                    elseif child.SearchHelpText and lastEntry then
                        if lastEntry.description == "" then
                            lastEntry.description = child.SearchHelpText
                        else
                            lastEntry.description = lastEntry.description .. " " .. child.SearchHelpText
                        end

                        lastEntry.keywords = BuildSearchKeywords(lastEntry)
                    end
                end
            end
        end

        return entries
    end

    local function ScoreSearchEntry(entry, query)
        local title = NormalizeSearchText(entry.title)
        local section = NormalizeSearchText(entry.section)
        local panelName = NormalizeSearchText(entry.panelName)
        local description = NormalizeSearchText(entry.description)
        local score = 0

        if title == query then
            score = score + 120
        end
        if string.sub(title, 1, #query) == query then
            score = score + 60
        end
        if string.find(title, query, 1, true) then
            score = score + 40
        end
        if string.find(section, query, 1, true) then
            score = score + 20
        end
        if string.find(panelName, query, 1, true) then
            score = score + 15
        end
        if string.find(description, query, 1, true) then
            score = score + 10
        end

        return score
    end

    local function GetSearchMatches(rawQuery, limit)
        local query = NormalizeSearchText(rawQuery)

        if query == "" then
            return {}
        end

        local matches = {}
        for _, entry in ipairs(CollectSearchEntries()) do
            if string.find(entry.keywords, query, 1, true) then
                entry.score = ScoreSearchEntry(entry, query)
                table.insert(matches, entry)
            end
        end

        table.sort(matches, function(a, b)
            if a.score == b.score then
                return a.title < b.title
            end

            return a.score > b.score
        end)

        if limit and #matches > limit then
            for index = #matches, limit + 1, -1 do
                matches[index] = nil
            end
        end

        return matches
    end

    ClearSearchSuggestions = function()
        searchMatches = {}

        if not IsValid(searchSuggestions) then
            return
        end

        for _, child in ipairs(searchSuggestions:GetChildren()) do
            child:Remove()
        end

        searchSuggestions:SetVisible(false)
        searchSuggestions.targetHeight = 0
        searchSuggestions.animHeight = 0
    end

    local function OpenSearchMatch(entry)
        if not entry then
            return
        end

        ClearSearchSuggestions()

        if IsValid(searchEntry) then
            ClearSearchQuery(false)
        end

        SwitchToPanel(entry.panel, entry.button)

        timer.Simple(0, function()
            ScrollToSearchTarget(entry.panel, entry.target)
        end)
    end

    local function AddSearchSuggestion(parent, entry, rank)
        local result = vgui.Create("DButton", parent)
        result:SetText("")
        result:SetTall(52)
        result:Dock(TOP)
        result:DockMargin(0, rank == 1 and 0 or 4, 0, 0)
        result.hoverAnim = 0
        result.pressAnim = 0

        result.Paint = function(self, w, h)
            AnimateButtonVisualState(self, 10, 12, 18, 12)

            local pushOffset = GetButtonPushOffset(self, 2)
            local bgCol = LerpColor(self.hoverAnim, Theme.bgDark, Theme.bgLighter)
            bgCol = LerpColor(self.pressAnim, bgCol, Theme.bg)
            DrawRoundedSurface(0, pushOffset, w, h, 8, bgCol, self:IsHovered() and Theme.accentHover or Theme.border)

            draw.SimpleText(tostring(rank), "NaiFont_Small", 14, (h / 2) + pushOffset, Theme.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            DrawMarqueeText(self, entry.title, "NaiFont_Normal", 34, 17 + pushOffset, Theme.textBright, math.max(w - 46, 0), TEXT_ALIGN_TOP, 28, 18)
            DrawMarqueeText(self, entry.panelName .. " / " .. entry.section, "NaiFont_Small", 34, 34 + pushOffset, Theme.textDim, math.max(w - 46, 0), TEXT_ALIGN_TOP, 28, 18)
        end

        result.DoClick = function()
            OpenSearchMatch(entry)
        end

        return result
    end

    local function UpdateSearchSuggestions(rawQuery)
        if not IsValid(searchSuggestions) then
            return
        end

        ClearSearchSuggestions()

        local allMatches = GetSearchMatches(rawQuery)
        local totalMatches = #allMatches

        if IsValid(searchStatus) then
            if NormalizeSearchText(rawQuery) == "" then
                searchStatus:SetText("Ctrl+F to focus search")
                searchStatus:SetTextColor(Theme.textDim)
            elseif totalMatches == 0 then
                searchStatus:SetText("No matching settings")
                searchStatus:SetTextColor(Theme.textDim)
            else
                searchStatus:SetText(string.format("Showing top %d of %d matches", math.min(totalMatches, SEARCH_SUGGESTION_LIMIT), totalMatches))
                searchStatus:SetTextColor(Theme.textDim)
            end
            searchStatus:SizeToContents()
        end

        if IsValid(searchClearBtn) then
            searchClearBtn:SetVisible(NormalizeSearchText(rawQuery) ~= "")
        end

        searchMatches = allMatches
        if #searchMatches > SEARCH_SUGGESTION_LIMIT then
            for index = #searchMatches, SEARCH_SUGGESTION_LIMIT + 1, -1 do
                searchMatches[index] = nil
            end
        end

        if #searchMatches == 0 then
            if NormalizeSearchText(rawQuery) == "" then
                return
            end

            local emptyState = vgui.Create("DPanel", searchSuggestions)
            emptyState:SetTall(34)
            emptyState:Dock(TOP)
            emptyState.Paint = function(self, w, h)
                DrawRoundedSurface(0, 0, w, h, 8, Theme.bgDark, Theme.border)
                draw.SimpleText("No matching settings", "NaiFont_Small", 12, h / 2, Theme.textDim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            end

            searchSuggestions:SetVisible(true)
            searchSuggestions.targetHeight = 34
            UpdateSearchSuggestionsLayout()
            return
        end

        local totalHeight = 0
        for index, entry in ipairs(searchMatches) do
            AddSearchSuggestion(searchSuggestions, entry, index)
            totalHeight = totalHeight + 52 + (index == 1 and 0 or 4)
        end

        searchSuggestions:SetVisible(true)
        searchSuggestions.targetHeight = totalHeight
        UpdateSearchSuggestionsLayout()
    end

    searchBox = vgui.Create("DPanel", sidebar)
    searchBox:Dock(TOP)
    searchBox:DockMargin(8, 10, 8, 12)
    searchBox:SetTall(42)
    searchBox.Paint = function(self, w, h)
        local borderColor = self:IsHovered() and Theme.accentHover or Theme.border
        DrawRoundedSurface(0, 0, w, h, 10, Theme.bgLight, borderColor)
    end
    searchBox.PaintOver = function(self, w, h)
        surface.SetDrawColor(Theme.textDim)
        surface.SetMaterial(Material("icon16/magnifier.png"))
        surface.DrawTexturedRect(12, (h - 16) / 2, 16, 16)
    end

    searchEntry = vgui.Create("DTextEntry", searchBox)
    searchEntry:Dock(FILL)
    searchEntry:DockMargin(36, 6, 34, 6)
    searchEntry:SetFont("NaiFont_Normal")
    searchEntry:SetTextColor(Theme.text)
    searchEntry:SetDrawBackground(false)
    searchEntry:SetUpdateOnType(true)
    searchEntry.Paint = function(self, w, h)
        self:DrawTextEntryText(Theme.text, Theme.accent, Theme.text)

        if self:GetValue() == "" and not self:HasFocus() then
            draw.SimpleText("Search settings...", "NaiFont_Normal", 0, h / 2, Theme.textDim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
    end
    searchEntry.OnKeyCodeTyped = function(self, key)
        if key == KEY_ESCAPE and self:GetValue() ~= "" then
            ClearSearchQuery(true)
            return true
        end
    end

    searchClearBtn = vgui.Create("DButton", searchBox)
    searchClearBtn:SetText("")
    searchClearBtn:SetSize(18, 18)
    searchClearBtn:SetVisible(false)
    searchClearBtn.Paint = function(self, w, h)
        local color = self:IsHovered() and Theme.textBright or Theme.textDim
        draw.SimpleText("x", "NaiFont_Bold", w / 2, h / 2 - 1, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    searchClearBtn.DoClick = function()
        ClearSearchQuery(true)
    end

    searchBox.PerformLayout = function(self, w, h)
        if IsValid(searchClearBtn) then
            searchClearBtn:SetPos(w - 24, math.floor((h - searchClearBtn:GetTall()) / 2))
        end
    end

    searchStatus = vgui.Create("DLabel", sidebar)
    searchStatus:SetText("Ctrl+F to focus search")
    searchStatus:SetFont("NaiFont_Small")
    searchStatus:SetTextColor(Theme.textDim)
    searchStatus:Dock(TOP)
    searchStatus:DockMargin(12, -6, 12, 10)
    searchStatus:SizeToContents()

    searchSuggestions = vgui.Create("DPanel", navContainer)
    searchSuggestions:SetTall(0)
    searchSuggestions:SetWide(0)
    searchSuggestions:SetVisible(false)
    searchSuggestions:DockPadding(6, 6, 6, 6)
    searchSuggestions.Paint = function(self, w, h)
        DrawRoundedSurface(0, 0, w, h, 10, Theme.bgLight, Theme.border)
    end
    
    -- QoL: Smooth enter/exit animation for search dropdown
    searchSuggestions.animHeight = 0
    searchSuggestions.targetHeight = 0
    searchSuggestions.Think = function(self)
        if self.animHeight ~= self.targetHeight then
            self.animHeight = Lerp(0.25, self.animHeight, self.targetHeight)
            self:SetTall(self.animHeight)
            if math.abs(self.animHeight - self.targetHeight) < 0.5 then
                self.animHeight = self.targetHeight
                self:SetTall(self.targetHeight)
            end
        end
    end
    
    UpdateSearchSuggestionsLayout()

    searchEntry.OnChange = function(self)
        UpdateSearchSuggestions(self:GetValue())
    end
    searchEntry.OnEnter = function(self)
        if searchMatches[1] then
            OpenSearchMatch(searchMatches[1])
        end
    end
    settingsFrame.OnKeyCodePressed = function(self, key)
        if key == KEY_F and (input.IsKeyDown(KEY_LCONTROL) or input.IsKeyDown(KEY_RCONTROL)) then
            FocusSearchEntry()
            return
        end

        if key == KEY_ESCAPE and IsValid(searchEntry) and searchEntry:GetValue() ~= "" then
            ClearSearchQuery(false)
        end
    end

    -- General Tab
    local generalPanel = CreateContentPanel()
    generalPanel.SearchPanelName = "General"
    local generalBtn = CreateNavButton("General", "icon16/cog.png")
    generalPanel.SearchNavButton = generalBtn
    generalBtn.DoClick = function() SwitchToPanel(generalPanel, generalBtn) end

    CreateSectionHeader(generalPanel, "General Settings")

    CreateCheckbox(generalPanel, "Allow Multiple Passengers", "nai_npc_allow_multiple")
    CreateHelpText(generalPanel, "Let multiple NPCs ride in the same vehicle.")

    CreateSpacer(generalPanel, 5)

    CreateComboBox(generalPanel, "Exit Behavior", "nai_npc_exit_mode", {
        { label = "Leave when player exits", value = 0 },
        { label = "Leave when vehicle is attacked", value = 1 },
        { label = "Never leave automatically", value = 2 },
    })
    CreateHelpText(generalPanel, "When should NPC passengers exit the vehicle?")

    CreateSpacer(generalPanel, 10)
    CreateSectionHeader(generalPanel, "Timing")

    CreateSlider(generalPanel, "Max Attach Distance", "nai_npc_max_attach_dist", 100, 2000, 0)
    CreateHelpText(generalPanel, "Maximum distance (units) to attach NPC to vehicle.")

    CreateSlider(generalPanel, "Detach Delay", "nai_npc_detach_delay", 0, 10, 1)
    CreateHelpText(generalPanel, "Seconds to wait before detaching after player leaves.")

    CreateSlider(generalPanel, "AI Restore Delay", "nai_npc_ai_delay", 0, 10, 1)
    CreateHelpText(generalPanel, "Seconds to wait before restoring NPC AI after detaching.")

    CreateSlider(generalPanel, "Cooldown Time", "nai_npc_cooldown", 0, 10, 1)
    CreateHelpText(generalPanel, "Cooldown between attaching NPCs to same vehicle.")

    CreateSlider(generalPanel, "Passenger Limit", "nai_npc_passenger_limit", 1, 20, 0)
    CreateHelpText(generalPanel, "Max NPCs allowed in vehicle.")

    -- Auto-Join Tab
    local autoJoinPanel = CreateContentPanel()
    autoJoinPanel.SearchPanelName = "Auto-Join"
    local autoJoinBtn = CreateNavButton("Auto-Join", "icon16/group.png")
    autoJoinPanel.SearchNavButton = autoJoinBtn
    autoJoinBtn.DoClick = function() SwitchToPanel(autoJoinPanel, autoJoinBtn) end
    
    CreateSectionHeader(autoJoinPanel, "Auto-Join (Squad Behavior)")
    CreateHelpText(autoJoinPanel, "Friendly NPCs will automatically board your vehicle when you enter it - just like squad mechanics in Half-Life 2!")
    
    CreateSpacer(autoJoinPanel, 5)
    
    CreateCheckbox(autoJoinPanel, "Enable Auto-Join", "nai_npc_auto_join")
    CreateHelpText(autoJoinPanel, "Nearby friendly NPCs will automatically join when you enter a vehicle.")
    
    CreateSlider(autoJoinPanel, "Auto-Join Range", "nai_npc_auto_join_range", 100, 2000, 0)
    CreateHelpText(autoJoinPanel, "Maximum distance to find NPCs for auto-joining.")
    
    CreateSlider(autoJoinPanel, "Max Auto-Join NPCs", "nai_npc_auto_join_max", 1, 10, 0)
    CreateHelpText(autoJoinPanel, "Maximum number of NPCs that can auto-join at once.")
    
    CreateCheckbox(autoJoinPanel, "Squad Members Only", "nai_npc_auto_join_squad_only")
    CreateHelpText(autoJoinPanel, "Only NPCs with a squad name will auto-join (for HL2-style squads).")

    -- Passengers Tab
    local passengersPanel = CreateContentPanel()
    passengersPanel.SearchPanelName = "Passengers"
    local passengersBtn = CreateNavButton("Passengers", "icon16/group_gear.png")
    passengersPanel.SearchNavButton = passengersBtn

    passengerControlList = nil
    passengersCurrentVehicleOnly = false
    currentVehicleOnlyBtn = nil
    passengerAutoRefreshBtn = nil
    passengerOverviewPanel = nil
    passengerFilterEntry = nil
    local passengerVisiblePassengers = {}
    passengerFilterQuery = ""
    passengerAutoRefreshEnabled = false
    nextPassengerAutoRefresh = 0
    passengerSortMode = "vehicle"
    local passengerCardIcons = {}
    local passengerCardIconsLoaded = false

    local passengerStatusColors = {
        calm = Color(105, 208, 140),
        alert = Color(255, 191, 84),
        scared = Color(255, 110, 110),
        drowsy = Color(124, 177, 255),
        dead = Color(112, 118, 130),
        default = Color(180, 180, 180),
    }

    local passengerStatusLabels = {
        calm = "Calm",
        alert = "Alert",
        scared = "Scared",
        drowsy = "Drowsy",
        dead = "Dead",
        default = "Unknown",
    }

    local function LoadPassengerCardIcons()
        if passengerCardIconsLoaded then
            return
        end

        passengerCardIconsLoaded = true
        for _, iconName in ipairs({"passenger", "calm", "alert", "scared", "drowsy", "dead"}) do
            local material = Material("nai_passengers/icon_" .. iconName .. ".png", "smooth mips")
            if not material:IsError() then
                passengerCardIcons[iconName] = material
            end
        end
    end

    local function GetPassengerCardStatus(npc)
        if not IsValid(npc) then
            return "default", 0
        end

        local alertThreshold = GetConVar("nai_npc_hud_alert_threshold")
        local fearThreshold = GetConVar("nai_npc_hud_fear_threshold")
        local drowsyThreshold = GetConVar("nai_npc_hud_drowsy_threshold")
        local drowsyTime = GetConVar("nai_npc_drowsy_time")

        local alertLevel = npc:GetNWFloat("NPCPassengerAlertLevel", 0)
        local fearLevel = npc:GetNWFloat("NPCPassengerFearLevel", 0)
        local isDrowsy = npc:GetNWBool("NPCPassengerIsDrowsy", false)
        local calmTime = npc:GetNWFloat("NPCPassengerCalmTime", 0)

        local at = alertThreshold and alertThreshold:GetFloat() or 0.3
        local ft = fearThreshold and fearThreshold:GetFloat() or 0.5
        local dt = drowsyThreshold and drowsyThreshold:GetFloat() or 0.7
        local drowsyTimeVal = drowsyTime and drowsyTime:GetFloat() or 60

        if npc:Health() <= 0 or not npc:Alive() then
            return "dead", 1
        elseif fearLevel >= ft then
            return "scared", fearLevel
        elseif alertLevel >= at then
            return "alert", alertLevel
        elseif isDrowsy or (drowsyTimeVal > 0 and calmTime / drowsyTimeVal >= dt) then
            return "drowsy", calmTime / math.max(1, drowsyTimeVal)
        else
            return "calm", 0
        end
    end

    local function GetPassengerCardDisplayName(npc)
        if not IsValid(npc) then return "Unknown" end

        local targetName = npc:GetNWString("targetname", "")
        if targetName == "" and npc.GetInternalVariable then
            targetName = npc:GetInternalVariable("m_iName") or ""
        end
        if targetName and targetName ~= "" then return targetName end

        local classNames = {
            ["npc_citizen"] = "Citizen",
            ["npc_alyx"] = "Alyx",
            ["npc_barney"] = "Barney",
            ["npc_monk"] = "Father Grigori",
            ["npc_eli"] = "Eli",
            ["npc_kleiner"] = "Dr. Kleiner",
            ["npc_mossman"] = "Dr. Mossman",
            ["npc_breen"] = "Dr. Breen",
            ["npc_vortigaunt"] = "Vortigaunt",
            ["npc_dog"] = "Dog",
        }

        return classNames[npc:GetClass() or ""] or string.upper(string.Replace(npc:GetClass() or "unknown", "npc_", ""))
    end

    local function DrawInfoPill(x, y, w, h, text, fillColor, textColor)
        draw.RoundedBox(6, x, y, w, h, fillColor)
        draw.SimpleText(text, "NaiFont_Small", x + w / 2, y + h / 2, textColor or Theme.textBright, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local passengerSortLabels = {
        vehicle = "Vehicle",
        name = "Name",
        seat = "Seat",
        health = "Health",
        status = "Status",
    }

    local passengerStatusOrder = {
        scared = 1,
        alert = 2,
        drowsy = 3,
        calm = 4,
        dead = 5,
        default = 6,
    }

    local function CopyPassengerText(text, successMessage)
        if not text or text == "" then
            chat.AddText(Color(255, 180, 120), ADDON_CHAT_PREFIX, Theme.text, "Nothing to copy.")
            return
        end

        if not SetClipboardText then
            chat.AddText(Color(255, 180, 120), ADDON_CHAT_PREFIX, Theme.text, "Clipboard access is not available in this build.")
            return
        end

        SetClipboardText(text)
        chat.AddText(Theme.success, ADDON_CHAT_PREFIX, Theme.text, successMessage or "Copied to clipboard.")
    end

    local function BuildPassengerSummaryLine(npc, passengerVehicle, status, intensity, currentSeat)
        local passengerName = GetPassengerCardDisplayName(npc)
        local vehicleClass = IsValid(passengerVehicle) and (passengerVehicle:GetClass() or "unknown") or "unknown"
        local statusLabel = passengerStatusLabels[status] or passengerStatusLabels.default
        local healthValue = math.max(IsValid(npc) and npc:Health() or 0, 0)
        local maxHealth = math.max(IsValid(npc) and npc:GetMaxHealth() or 1, 1)

        return string.format(
            "%s | class=%s | ent=%d | status=%s (%d%%) | health=%d/%d | seat=%d | vehicle=%s",
            passengerName,
            IsValid(npc) and (npc:GetClass() or "npc") or "npc",
            IsValid(npc) and npc:EntIndex() or -1,
            statusLabel,
            math.floor(math.Clamp(intensity or 0, 0, 1) * 100 + 0.5),
            healthValue,
            maxHealth,
            currentSeat or 1,
            vehicleClass
        )
    end

    local function BuildPassengerDebugLine(npc, passengerVehicle, currentSeat)
        local seatEntity = IsValid(npc) and npc:GetParent() or nil
        return string.format(
            "npc=%s[%d] | vehicle=%s[%d] | seat_entity=%s[%d] | seat_index=%d | hidden=%s",
            IsValid(npc) and (npc:GetClass() or "npc") or "npc",
            IsValid(npc) and npc:EntIndex() or -1,
            IsValid(passengerVehicle) and (passengerVehicle:GetClass() or "unknown") or "unknown",
            IsValid(passengerVehicle) and passengerVehicle:EntIndex() or -1,
            IsValid(seatEntity) and (seatEntity:GetClass() or "seat") or "none",
            IsValid(seatEntity) and seatEntity:EntIndex() or -1,
            currentSeat or 1,
            tostring(IsValid(npc) and npc:GetNWBool("NPCPassengerHidden", false) or false)
        )
    end

    local function PassengerMatchesFilter(npc, passengerVehicle, status, currentSeat)
        if passengerFilterQuery == "" then
            return true
        end

        local searchText = NormalizeSearchText(table.concat({
            GetPassengerCardDisplayName(npc),
            IsValid(npc) and (npc:GetClass() or "") or "",
            passengerStatusLabels[status] or status or "",
            IsValid(passengerVehicle) and (passengerVehicle:GetClass() or "") or "",
            IsValid(passengerVehicle) and (passengerVehicle:GetModel() or "") or "",
            "seat " .. tostring(currentSeat or 1),
            tostring(IsValid(npc) and npc:EntIndex() or -1),
            IsValid(npc) and (npc:GetNWBool("NPCPassengerHidden", false) and "hidden" or "visible") or "",
        }, " "))

        return string.find(searchText, passengerFilterQuery, 1, true) ~= nil
    end

    local function ComparePassengers(a, b, currentVehicle)
        local vehicleA = GetPassengerControlVehicle(a)
        local vehicleB = GetPassengerControlVehicle(b)
        local aInCurrent = IsValid(currentVehicle) and vehicleA == currentVehicle
        local bInCurrent = IsValid(currentVehicle) and vehicleB == currentVehicle

        if aInCurrent ~= bInCurrent then
            return aInCurrent
        end

        if passengerSortMode == "name" then
            local nameA = NormalizeSearchText(GetPassengerCardDisplayName(a))
            local nameB = NormalizeSearchText(GetPassengerCardDisplayName(b))
            if nameA ~= nameB then
                return nameA < nameB
            end
        elseif passengerSortMode == "seat" then
            local seatA = GetClientVehicleSeatIndex(vehicleA, a:GetParent()) or math.huge
            local seatB = GetClientVehicleSeatIndex(vehicleB, b:GetParent()) or math.huge
            if seatA ~= seatB then
                return seatA < seatB
            end
        elseif passengerSortMode == "health" then
            local healthA = math.max(a:Health(), 0)
            local healthB = math.max(b:Health(), 0)
            if healthA ~= healthB then
                return healthA > healthB
            end
        elseif passengerSortMode == "status" then
            local statusA = passengerStatusOrder[select(1, GetPassengerCardStatus(a))] or passengerStatusOrder.default
            local statusB = passengerStatusOrder[select(1, GetPassengerCardStatus(b))] or passengerStatusOrder.default
            if statusA ~= statusB then
                return statusA < statusB
            end
        end

        local classA = a:GetClass() or ""
        local classB = b:GetClass() or ""
        if classA == classB then
            return a:EntIndex() < b:EntIndex()
        end

        return classA < classB
    end

    local function UpdatePassengerOverview(passengers, currentVehicle, totalPassengerCount)
        if not IsValid(passengerOverviewPanel) then
            return
        end

        passengerOverviewPanel.totalPassengers = totalPassengerCount or #passengers
        passengerOverviewPanel.visiblePassengers = #passengers
        passengerOverviewPanel.currentVehiclePassengers = 0
        passengerOverviewPanel.scaredPassengers = 0
        passengerOverviewPanel.drowsyPassengers = 0
        passengerOverviewPanel.deadPassengers = 0
        passengerOverviewPanel.hiddenPassengers = 0
        passengerOverviewPanel.filterSummary = passengerFilterQuery ~= "" and passengerFilterQuery or (passengersCurrentVehicleOnly and "Current vehicle only" or "All passengers")
        passengerOverviewPanel.sortSummary = passengerSortLabels[passengerSortMode] or passengerSortLabels.vehicle
        passengerOverviewPanel.autoRefreshEnabled = passengerAutoRefreshEnabled

        for _, npc in ipairs(passengers) do
            local status = GetPassengerCardStatus(npc)
            if currentVehicle and GetPassengerControlVehicle(npc) == currentVehicle then
                passengerOverviewPanel.currentVehiclePassengers = passengerOverviewPanel.currentVehiclePassengers + 1
            end
            if status == "scared" then
                passengerOverviewPanel.scaredPassengers = passengerOverviewPanel.scaredPassengers + 1
            elseif status == "drowsy" then
                passengerOverviewPanel.drowsyPassengers = passengerOverviewPanel.drowsyPassengers + 1
            elseif status == "dead" then
                passengerOverviewPanel.deadPassengers = passengerOverviewPanel.deadPassengers + 1
            end

            if npc:GetNWBool("NPCPassengerHidden", false) then
                passengerOverviewPanel.hiddenPassengers = passengerOverviewPanel.hiddenPassengers + 1
            end
        end

        passengerOverviewPanel:InvalidateLayout(true)
    end

    local function RefreshPassengersControlList(forceRefresh)
        if not IsValid(passengerControlList) then
            return
        end

        LoadPassengerCardIcons()
        passengerControlList:Clear()

        local passengers = {}
        local allPassengers = {}
        local ply = LocalPlayer()
        local currentVehicle = IsValid(ply) and ply:InVehicle() and GetClientRootVehicle(ply:GetVehicle()) or nil

        passengerFilterQuery = NormalizeSearchText(IsValid(passengerFilterEntry) and passengerFilterEntry:GetValue() or passengerFilterQuery)

        for _, ent in ipairs(GetTrackedPassengerEntities(forceRefresh)) do
            allPassengers[#allPassengers + 1] = ent
            local passengerVehicle = GetPassengerControlVehicle(ent)
            local status = select(1, GetPassengerCardStatus(ent))
            local currentSeat = GetClientVehicleSeatIndex(passengerVehicle, ent:GetParent()) or 1

            if (not passengersCurrentVehicleOnly or (IsValid(currentVehicle) and passengerVehicle == currentVehicle))
                and PassengerMatchesFilter(ent, passengerVehicle, status, currentSeat) then
                passengers[#passengers + 1] = ent
            end
        end

        table.sort(passengers, function(a, b)
            return ComparePassengers(a, b, currentVehicle)
        end)

        passengerVisiblePassengers = passengers

        UpdatePassengerOverview(passengers, currentVehicle, #allPassengers)

        if #passengers == 0 then
            local noPassengers = vgui.Create("DLabel", passengerControlList)
            noPassengers:SetFont("NaiFont_Normal")
            noPassengers:SetTextColor(Theme.textDim)
            noPassengers:Dock(TOP)
            noPassengers:DockMargin(10, 10, 10, 10)
            noPassengers:SetWrap(true)
            noPassengers:SetAutoStretchVertical(true)

            if passengersCurrentVehicleOnly and not IsValid(currentVehicle) then
                noPassengers:SetText("No current vehicle detected. Sit in a vehicle or disable the current-vehicle filter.")
            elseif passengerFilterQuery ~= "" then
                noPassengers:SetText("No passengers matched your filter. Try a name, class, seat number, status, or vehicle class.")
            elseif passengersCurrentVehicleOnly then
                noPassengers:SetText("No passengers found in your current vehicle.")
            else
                noPassengers:SetText("No passengers found. NPCs need to be riding in a vehicle before they can be managed here.")
            end

            return
        end

        for _, npc in ipairs(passengers) do
            local passengerVehicle = GetPassengerControlVehicle(npc)
            local matchingVehicle = IsPassengerInLocalPlayersVehicle(npc)
            local status, intensity = GetPassengerCardStatus(npc)
            local statusColor = passengerStatusColors[status] or passengerStatusColors.default
            local statusLabel = passengerStatusLabels[status] or passengerStatusLabels.default
            local currentSeat = GetClientVehicleSeatIndex(passengerVehicle, npc:GetParent()) or 1
            local maxHealth = math.max(npc:GetMaxHealth(), 1)
            local healthValue = math.max(npc:Health(), 0)
            local healthFrac = math.Clamp(healthValue / maxHealth, 0, 1)
            local seatChoices = math.max(GetClientVehicleSeatCount(passengerVehicle), currentSeat, 1)

            local npcPanel = vgui.Create("DPanel", passengerControlList)
            npcPanel:Dock(TOP)
            npcPanel:SetTall(176)
            npcPanel:DockMargin(8, 6, 8, 6)
            npcPanel.Paint = function(self, w, h)
                if not IsValid(npc) then return end

                draw.RoundedBox(10, 0, 0, w, h, Theme.bgLighter)
                draw.RoundedBox(10, 0, 0, 10, h, statusColor)

                local gradientMat = Material("vgui/gradient-r")
                surface.SetDrawColor(statusColor.r, statusColor.g, statusColor.b, 35)
                surface.SetMaterial(gradientMat)
                surface.DrawTexturedRect(0, 0, w, h)

                local passengerName = GetPassengerCardDisplayName(npc)
                draw.SimpleText(passengerName, "NaiFont_Bold", 76, 18, Theme.textBright)

                if passengerCardIcons[status] then
                    surface.SetFont("NaiFont_Bold")
                    local nameWidth = surface.GetTextSize(passengerName)
                    surface.SetDrawColor(255, 255, 255, 255)
                    surface.SetMaterial(passengerCardIcons[status])
                    surface.DrawTexturedRect(76 + nameWidth + 8, 11, 22, 22)
                end

                draw.SimpleText((npc:GetClass() or "npc") .. "  |  #" .. npc:EntIndex(), "NaiFont_Small", 76, 38, Theme.textDim)
                draw.SimpleText(IsValid(passengerVehicle) and ("Vehicle: " .. passengerVehicle:GetClass()) or "Vehicle: Unknown", "NaiFont_Small", 76, 58, Theme.text)

                DrawInfoPill(76, 82, 92, 22, "Seat " .. currentSeat, Color(30, 36, 44, 240), Theme.textBright)
                DrawInfoPill(176, 82, 96, 22, statusLabel, Color(statusColor.r, statusColor.g, statusColor.b, 220), Theme.bgDark)
                DrawInfoPill(280, 82, 118, 22, matchingVehicle and "Same Vehicle" or "Other Vehicle", matchingVehicle and Color(46, 78, 62, 230) or Color(54, 58, 68, 230), matchingVehicle and Theme.success or Theme.textDim)
                DrawInfoPill(406, 82, 86, 22, npc:GetNWBool("NPCPassengerHidden", false) and "Hidden" or "Visible", Color(30, 36, 44, 230), Theme.textBright)

                local healthBarX = 76
                local healthBarY = 114
                local healthBarW = w - 100
                draw.RoundedBox(6, healthBarX, healthBarY, healthBarW, 14, Theme.bgDark)
                draw.RoundedBox(6, healthBarX, healthBarY, math.max(healthBarW * healthFrac, 10), 14, Color(112, 214, 136))
                draw.SimpleText(string.format("Health %d / %d", healthValue, maxHealth), "NaiFont_Small", healthBarX + 10, healthBarY + 7, Theme.bgDark, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                local intensityBarX = 76
                local intensityBarY = 138
                local intensityBarW = w - 100
                draw.RoundedBox(6, intensityBarX, intensityBarY, intensityBarW, 10, Theme.bgDark)
                draw.RoundedBox(6, intensityBarX, intensityBarY, math.max(intensityBarW * math.Clamp(intensity, 0.05, 1), 8), 10, Color(statusColor.r, statusColor.g, statusColor.b, 225))
                draw.SimpleText(string.format("Status intensity %.0f%%", math.Clamp(intensity, 0, 1) * 100), "NaiFont_Small", intensityBarX + intensityBarW, intensityBarY - 8, Theme.textDim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
            end

            local seatCombo = vgui.Create("DComboBox", npcPanel)
            seatCombo:SetFont("NaiFont_Small")
            seatCombo:SetSortItems(false)
            for seatNumber = 1, seatChoices do
                seatCombo:AddChoice("Seat " .. seatNumber, seatNumber)
            end
            seatCombo:ChooseOptionID(currentSeat)
            seatCombo:SetValue("Seat " .. currentSeat)

            local assignBtn = vgui.Create("DButton", npcPanel)
            assignBtn:SetFont("NaiFont_Normal")
            assignBtn:SetTextColor(TransparentColor)
            assignBtn:SetText("Assign Seat")
            assignBtn.hoverAnim = 0
            assignBtn.pressAnim = 0
            assignBtn.Paint = function(self, w, h)
                local enabled = IsValid(npc) and IsPassengerInLocalPlayersVehicle(npc)
                AnimateButtonVisualState(self, 8, 10, 18, 12)

                local pushOffset = GetButtonPushOffset(self, enabled and 2 or 0)
                local baseColor = enabled and Theme.accent or Theme.bgDark
                local hoverColor = enabled and Theme.accentHover or Theme.bgDark
                local color = LerpColor(self.hoverAnim, baseColor, hoverColor)
                if enabled then
                    color = LerpColor(self.pressAnim, color, Theme.accentActive)
                end
                draw.RoundedBox(4, 0, pushOffset, w, h, color)
                draw.SimpleText(self:GetText(), "NaiFont_Normal", w / 2, (h / 2) + pushOffset, Theme.textBright, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            assignBtn.DoClick = function()
                if not IsValid(npc) then return end
                if not IsPassengerInLocalPlayersVehicle(npc) then
                    chat.AddText(Color(255, 180, 120), ADDON_CHAT_PREFIX, Theme.text, "Sit in the same vehicle to reassign this passenger.")
                    return
                end

                local _, seatNumber = seatCombo:GetSelected()
                seatNumber = seatNumber or 1

                net.Start("NPCPassengers_AssignSeat")
                    net.WriteEntity(npc)
                    net.WriteUInt(seatNumber, 8)
                net.SendToServer()

                timer.Simple(0.15, function()
                    if IsValid(passengerControlList) then
                        RefreshPassengersControlList()
                    end
                end)
            end

            local detachBtn = vgui.Create("DButton", npcPanel)
            detachBtn:SetFont("NaiFont_Normal")
            detachBtn:SetTextColor(TransparentColor)
            detachBtn:SetText("Detach")
            detachBtn.hoverAnim = 0
            detachBtn.pressAnim = 0
            detachBtn.Paint = function(self, w, h)
                AnimateButtonVisualState(self, 8, 10, 18, 12)

                local pushOffset = GetButtonPushOffset(self, 2)
                local color = LerpColor(self.hoverAnim, Theme.bgDark, Theme.error)
                color = LerpColor(self.pressAnim, color, Color(140, 60, 60))
                draw.RoundedBox(4, 0, pushOffset, w, h, color)
                draw.SimpleText(self:GetText(), "NaiFont_Normal", w / 2, (h / 2) + pushOffset, Theme.textBright, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            detachBtn.DoClick = function()
                if not IsValid(npc) then return end

                net.Start("NPCPassengers_RemovePassenger")
                    net.WriteEntity(npc)
                net.SendToServer()

                timer.Simple(0.15, function()
                    if IsValid(passengerControlList) then
                        RefreshPassengersControlList()
                    end
                end)
            end

            local summaryBtn = vgui.Create("DButton", npcPanel)
            summaryBtn:SetFont("NaiFont_Normal")
            summaryBtn:SetTextColor(TransparentColor)
            summaryBtn:SetText("Copy Summary")
            summaryBtn.hoverAnim = 0
            summaryBtn.pressAnim = 0
            summaryBtn.Paint = function(self, w, h)
                AnimateButtonVisualState(self, 8, 10, 18, 12)

                local pushOffset = GetButtonPushOffset(self, 2)
                local color = LerpColor(self.hoverAnim, Theme.bgDark, Color(56, 88, 112))
                color = LerpColor(self.pressAnim, color, Color(46, 72, 92))
                draw.RoundedBox(4, 0, pushOffset, w, h, color)
                draw.SimpleText(self:GetText(), "NaiFont_Normal", w / 2, (h / 2) + pushOffset, Theme.textBright, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            summaryBtn.DoClick = function()
                if not IsValid(npc) then return end

                local liveVehicle = GetPassengerControlVehicle(npc)
                local liveStatus, liveIntensity = GetPassengerCardStatus(npc)
                local liveSeat = GetClientVehicleSeatIndex(liveVehicle, npc:GetParent()) or currentSeat
                CopyPassengerText(BuildPassengerSummaryLine(npc, liveVehicle, liveStatus, liveIntensity, liveSeat), "Passenger summary copied.")
            end

            local debugBtn = vgui.Create("DButton", npcPanel)
            debugBtn:SetFont("NaiFont_Normal")
            debugBtn:SetTextColor(TransparentColor)
            debugBtn:SetText("Copy Debug")
            debugBtn.hoverAnim = 0
            debugBtn.pressAnim = 0
            debugBtn.Paint = function(self, w, h)
                AnimateButtonVisualState(self, 8, 10, 18, 12)

                local pushOffset = GetButtonPushOffset(self, 2)
                local color = LerpColor(self.hoverAnim, Theme.bgDark, Color(72, 74, 94))
                color = LerpColor(self.pressAnim, color, Color(58, 60, 78))
                draw.RoundedBox(4, 0, pushOffset, w, h, color)
                draw.SimpleText(self:GetText(), "NaiFont_Normal", w / 2, (h / 2) + pushOffset, Theme.textBright, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            debugBtn.DoClick = function()
                if not IsValid(npc) then return end

                local liveVehicle = GetPassengerControlVehicle(npc)
                local liveSeat = GetClientVehicleSeatIndex(liveVehicle, npc:GetParent()) or currentSeat
                CopyPassengerText(BuildPassengerDebugLine(npc, liveVehicle, liveSeat), "Passenger debug info copied.")
            end

            npcPanel.PerformLayout = function(self, w, h)
                local seatX = 76
                local seatY = 148
                local seatW = 108
                local actionX = seatX + seatW + 10
                local actionY = 146
                local spacing = 8
                local actionW = math.max(math.floor((w - actionX - 16 - (spacing * 3)) / 4), 92)

                seatCombo:SetPos(seatX, seatY)
                seatCombo:SetSize(seatW, 24)

                assignBtn:SetPos(actionX, actionY)
                assignBtn:SetSize(actionW, 28)

                detachBtn:SetPos(actionX + actionW + spacing, actionY)
                detachBtn:SetSize(actionW, 28)

                summaryBtn:SetPos(actionX + (actionW + spacing) * 2, actionY)
                summaryBtn:SetSize(actionW, 28)

                debugBtn:SetPos(actionX + (actionW + spacing) * 3, actionY)
                debugBtn:SetSize(actionW, 28)
            end
        end
    end

    passengersBtn.DoClick = function()
        SwitchToPanel(passengersPanel, passengersBtn)
        nextPassengerAutoRefresh = 0
        RefreshPassengersControlList()
    end

    CreateSectionHeader(passengersPanel, "Passenger Controls")
    CreateHelpText(passengersPanel, "Manage active passengers, filter by name/class/status, copy debug info, reassign seats, and detach riders without leaving the settings panel.")

    passengerOverviewPanel = vgui.Create("DPanel", passengersPanel)
    passengerOverviewPanel:SetTall(140)
    passengerOverviewPanel:Dock(TOP)
    passengerOverviewPanel:DockMargin(8, 6, 8, 6)
    passengerOverviewPanel.totalPassengers = 0
    passengerOverviewPanel.visiblePassengers = 0
    passengerOverviewPanel.currentVehiclePassengers = 0
    passengerOverviewPanel.scaredPassengers = 0
    passengerOverviewPanel.drowsyPassengers = 0
    passengerOverviewPanel.deadPassengers = 0
    passengerOverviewPanel.hiddenPassengers = 0
    passengerOverviewPanel.Paint = function(self, w, h)
        local filterSummary = self.filterSummary or "All passengers"
        if string.len(filterSummary) > 44 then
            filterSummary = string.sub(filterSummary, 1, 41) .. "..."
        end

        draw.RoundedBox(10, 0, 0, w, h, Theme.bgDark)

        local gradientMat = Material("vgui/gradient-r")
        surface.SetDrawColor(Theme.accent.r, Theme.accent.g, Theme.accent.b, 42)
        surface.SetMaterial(gradientMat)
        surface.DrawTexturedRect(0, 0, w, h)

        draw.SimpleText("Passenger Operations", "NaiFont_Bold", 16, 18, Theme.textBright)
        draw.SimpleText("Filter: " .. filterSummary, "NaiFont_Small", 16, 40, Theme.textDim)
        draw.SimpleText("Sort: " .. (self.sortSummary or passengerSortLabels.vehicle) .. "  |  Auto Refresh: " .. (self.autoRefreshEnabled and "ON" or "OFF"), "NaiFont_Small", 16, 58, Theme.textDim)

        DrawInfoPill(16, 86, 110, 26, "Total: " .. self.totalPassengers, Theme.bgLighter, Theme.textBright)
        DrawInfoPill(136, 86, 126, 26, "Showing: " .. self.visiblePassengers, Color(34, 52, 64, 220), Theme.textBright)
        DrawInfoPill(272, 86, 174, 26, "Current Vehicle: " .. self.currentVehiclePassengers, Color(38, 58, 72, 220), Theme.textBright)
        DrawInfoPill(456, 86, 108, 26, "Hidden: " .. self.hiddenPassengers, Color(44, 50, 64, 220), Theme.textBright)
        DrawInfoPill(16, 116, 92, 20, "Dead: " .. self.deadPassengers, Color(62, 62, 72, 220), Theme.textBright)
        DrawInfoPill(116, 116, 106, 20, "Scared: " .. self.scaredPassengers, Color(98, 40, 40, 220), Theme.textBright)
        DrawInfoPill(230, 116, 110, 20, "Drowsy: " .. self.drowsyPassengers, Color(44, 60, 92, 220), Theme.textBright)
    end

    local passengerToolbar = vgui.Create("DPanel", passengersPanel)
    passengerToolbar.SearchLabel = "Passenger Filter"
    passengerToolbar.SearchDescription = "Filter active passengers by name, class, seat, status, or vehicle."
    passengerToolbar:Dock(TOP)
    passengerToolbar:DockMargin(8, 4, 8, 4)
    passengerToolbar:SetTall(40)
    passengerToolbar.Paint = function(self, w, h)
        DrawRoundedSurface(0, 0, w, h, 8, Theme.bgDark, Theme.border)
    end

    local passengerSortCombo = vgui.Create("DComboBox", passengerToolbar)
    passengerSortCombo.SearchLabel = "Passenger Sort"
    passengerSortCombo.SearchDescription = "Sort the visible passenger list by vehicle, name, seat, health, or status."
    passengerSortCombo:SetFont("NaiFont_Small")
    passengerSortCombo:SetTextColor(Theme.text)
    passengerSortCombo:SetSortItems(false)
    passengerSortCombo.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Theme.bgLighter)
        surface.SetDrawColor(self:IsMenuOpen() and Theme.accent or Theme.border)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        draw.SimpleText("v", "NaiFont_Small", w - 14, h / 2, Theme.textDim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    passengerSortCombo:AddChoice("Vehicle First", "vehicle")
    passengerSortCombo:AddChoice("Name A-Z", "name")
    passengerSortCombo:AddChoice("Seat Number", "seat")
    passengerSortCombo:AddChoice("Highest Health", "health")
    passengerSortCombo:AddChoice("Status Priority", "status")
    passengerSortCombo:SetValue("Vehicle First")
    passengerSortCombo.OnSelect = function(self, index, value, data)
        passengerSortMode = data or "vehicle"
        RefreshPassengersControlList()
    end

    local passengerFilterClearBtn = vgui.Create("DButton", passengerToolbar)
    passengerFilterClearBtn:SetText("")
    passengerFilterClearBtn:SetSize(18, 18)
    passengerFilterClearBtn:SetVisible(false)
    passengerFilterClearBtn.Paint = function(self, w, h)
        local color = self:IsHovered() and Theme.textBright or Theme.textDim
        draw.SimpleText("x", "NaiFont_Bold", w / 2, h / 2 - 1, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    passengerFilterClearBtn.DoClick = function()
        if not IsValid(passengerFilterEntry) then
            return
        end

        passengerFilterEntry:SetText("")
        passengerFilterQuery = ""
        passengerFilterClearBtn:SetVisible(false)
        RefreshPassengersControlList()
        passengerFilterEntry:RequestFocus()
    end

    passengerFilterEntry = vgui.Create("DTextEntry", passengerToolbar)
    passengerFilterEntry:SetFont("NaiFont_Normal")
    passengerFilterEntry:SetTextColor(Theme.text)
    passengerFilterEntry:SetDrawBackground(false)
    passengerFilterEntry:SetUpdateOnType(true)
    passengerFilterEntry.Paint = function(self, w, h)
        self:DrawTextEntryText(Theme.text, Theme.accent, Theme.text)

        if self:GetValue() == "" and not self:HasFocus() then
            draw.SimpleText("Filter passengers...", "NaiFont_Normal", 0, h / 2, Theme.textDim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
    end
    passengerFilterEntry.OnChange = function(self)
        passengerFilterQuery = NormalizeSearchText(self:GetValue())
        passengerFilterClearBtn:SetVisible(passengerFilterQuery ~= "")
        RefreshPassengersControlList()
    end
    passengerFilterEntry.OnKeyCodeTyped = function(self, key)
        if key == KEY_ESCAPE and self:GetValue() ~= "" then
            passengerFilterClearBtn:DoClick()
            return true
        end
    end

    passengerToolbar.PerformLayout = function(self, w, h)
        local sortWidth = 154
        local clearWidth = 18
        local margin = 10

        passengerSortCombo:SetPos(w - sortWidth - margin, 6)
        passengerSortCombo:SetSize(sortWidth, 28)

        passengerFilterClearBtn:SetPos(w - sortWidth - clearWidth - 18, math.floor((h - clearWidth) / 2))
        passengerFilterEntry:SetPos(12, 7)
        passengerFilterEntry:SetSize(math.max(w - sortWidth - clearWidth - 44, 120), 24)
    end

    CreateButton(passengersPanel, "Refresh Passenger List", function()
        RefreshPassengersControlList(true)
    end)

    currentVehicleOnlyBtn = CreateButton(passengersPanel, "Show Current Vehicle Only: OFF", function()
        passengersCurrentVehicleOnly = not passengersCurrentVehicleOnly
        currentVehicleOnlyBtn:SetText("Show Current Vehicle Only: " .. (passengersCurrentVehicleOnly and "ON" or "OFF"))
        RefreshPassengersControlList()
    end)

    passengerAutoRefreshBtn = CreateButton(passengersPanel, "Auto Refresh Visible List: OFF", function()
        passengerAutoRefreshEnabled = not passengerAutoRefreshEnabled
        nextPassengerAutoRefresh = 0
        passengerAutoRefreshBtn:SetText("Auto Refresh Visible List: " .. (passengerAutoRefreshEnabled and "ON" or "OFF"))
        RefreshPassengersControlList()
    end)

    CreateButton(passengersPanel, "Copy Visible Passenger List", function()
        if #passengerVisiblePassengers == 0 then
            chat.AddText(Color(255, 180, 120), ADDON_CHAT_PREFIX, Theme.text, "No visible passengers to copy.")
            return
        end

        local lines = {}
        for _, npc in ipairs(passengerVisiblePassengers) do
            if IsValid(npc) then
                local liveVehicle = GetPassengerControlVehicle(npc)
                local liveStatus, liveIntensity = GetPassengerCardStatus(npc)
                local liveSeat = GetClientVehicleSeatIndex(liveVehicle, npc:GetParent()) or 1
                lines[#lines + 1] = BuildPassengerSummaryLine(npc, liveVehicle, liveStatus, liveIntensity, liveSeat)
            end
        end

        CopyPassengerText(table.concat(lines, "\n"), #lines .. " passenger summaries copied.")
    end)

    CreateButton(passengersPanel, "Make Current Vehicle Passengers Exit", function()
        if not LocalPlayer():InVehicle() then
            chat.AddText(Color(255, 180, 120), ADDON_CHAT_PREFIX, Theme.text, "You need to be in a vehicle to use this.")
            return
        end

        RunConsoleCommand("nai_npc_detach_all")
        timer.Simple(0.15, function()
            if IsValid(passengerControlList) then
                RefreshPassengersControlList()
            end
        end)
    end)

    passengerControlList = vgui.Create("DScrollPanel", passengersPanel)
    passengerControlList:SetTall(420)
    passengerControlList:Dock(TOP)
    passengerControlList:DockMargin(5, 5, 5, 5)
    StyleScrollbar(passengerControlList:GetVBar())
    passengerControlList.Paint = function(self, w, h)
        draw.RoundedBox(6, 0, 0, w, h, Theme.bgDark)
    end

    -- Position Tab
    local posPanel = CreateContentPanel()
    posPanel.SearchPanelName = "Position"
    local posBtn = CreateNavButton("Position", "icon16/arrow_out.png")
    posPanel.SearchNavButton = posBtn
    posBtn.DoClick = function() SwitchToPanel(posPanel, posBtn) end
    
    CreateSectionHeader(posPanel, "Position Offsets")
    CreateHelpText(posPanel, "Fine-tune NPC positioning in vehicles. Use these to fix floating or clipping issues.")
    
    CreateSlider(posPanel, "Height Offset", "nai_npc_height_offset", -50, 50, 0)
    CreateSlider(posPanel, "Forward Offset", "nai_npc_forward_offset", -50, 50, 0)
    CreateSlider(posPanel, "Right Offset", "nai_npc_right_offset", -50, 50, 0)
    
    CreateSpacer(posPanel, 10)
    CreateSectionHeader(posPanel, "Angle Offsets")
    CreateHelpText(posPanel, "Adjust NPC rotation in vehicles.")
    
    CreateSlider(posPanel, "Yaw (Rotation)", "nai_npc_yaw_offset", -180, 180, 0)
    CreateSlider(posPanel, "Pitch (Tilt Forward)", "nai_npc_pitch_offset", -45, 45, 0)
    CreateSlider(posPanel, "Roll (Tilt Sideways)", "nai_npc_roll_offset", -45, 45, 0)
    
    CreateSpacer(posPanel, 15)
    CreateButton(posPanel, "Reset Position & Angles", function()
        RunConsoleCommand("nai_npc_height_offset", "-3")
        RunConsoleCommand("nai_npc_forward_offset", "0")
        RunConsoleCommand("nai_npc_right_offset", "0")
        RunConsoleCommand("nai_npc_yaw_offset", "0")
        RunConsoleCommand("nai_npc_pitch_offset", "0")
        RunConsoleCommand("nai_npc_roll_offset", "0")
        settingsFrame:Close()
        timer.Simple(0.1, OpenSettingsPanel)
    end)
    
    -- Speech & Behavior Tab
    local speechPanel = CreateContentPanel()
    speechPanel.SearchPanelName = "Behaviour"
    local speechBtn = CreateNavButton("Behaviour", "icon16/sound.png")
    speechPanel.SearchNavButton = speechBtn
    speechBtn.DoClick = function() SwitchToPanel(speechPanel, speechBtn) end
    
    CreateSectionHeader(speechPanel, "NPC Speech (Advanced)")
    CreateHelpText(speechPanel, "Configure how NPCs vocalize while riding in vehicles. HL2-style citizen voices!")
    
    CreateSpacer(speechPanel, 5)
    
    CreateCheckbox(speechPanel, "Enable NPC Speech", "nai_npc_speech_enabled")
    CreateHelpText(speechPanel, "Master toggle for all NPC speech. Disable to silence passengers completely.")
    
    CreateSlider(speechPanel, "Speech Volume", "nai_npc_speech_volume", 0, 100, 0)
    CreateHelpText(speechPanel, "How loud NPC voices are (0 = silent, 100 = full volume).")
    
    CreateSlider(speechPanel, "Pitch Variation (+/-)", "nai_npc_speech_pitch_var", 0, 20, 0)
    CreateHelpText(speechPanel, "Random pitch variation for more natural voices. 0 = monotone, higher = more variety.")

    -- QoL: Quick Enable All / Disable All buttons for speech settings
    local speechBtnContainer = vgui.Create("DPanel", speechPanel)
    speechBtnContainer:SetTall(32)
    speechBtnContainer:Dock(TOP)
    speechBtnContainer:DockMargin(0, 5, 0, 10)
    speechBtnContainer.Paint = function() end
    
    local enableAllBtn = vgui.Create("DButton", speechBtnContainer)
    enableAllBtn:SetPos(0, 0)
    enableAllBtn:SetSize(140, 28)
    enableAllBtn:SetText("Enable All Speech")
    enableAllBtn:SetFont("NaiFont_Normal")
    enableAllBtn:SetTextColor(Theme.textBright)
    enableAllBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Theme.accentHover or Theme.accent
        draw.RoundedBox(4, 0, 0, w, h, col)
    end
    enableAllBtn.DoClick = function()
        RunConsoleCommand("nai_npc_speech_enabled", "1")
        RunConsoleCommand("nai_npc_speech_crash", "1")
        RunConsoleCommand("nai_npc_speech_idle", "1")
        RunConsoleCommand("nai_npc_speech_board", "1")
        RunConsoleCommand("nai_npc_ambient_sounds", "1")
        RunConsoleCommand("nai_npc_talking_gestures", "1")
        RunConsoleCommand("nai_npc_crash_flinch", "1")
        RunConsoleCommand("nai_npc_body_sway", "1")
        RunConsoleCommand("nai_npc_threat_awareness", "1")
        RunConsoleCommand("nai_npc_combat_alert", "1")
        RunConsoleCommand("nai_npc_passenger_interaction", "1")
        RunConsoleCommand("nai_npc_fear_reactions", "1")
        RunConsoleCommand("nai_npc_drowsiness", "1")
        RunConsoleCommand("nai_npc_head_look", "1")
        RunConsoleCommand("nai_npc_blink", "1")
        RunConsoleCommand("nai_npc_breathing", "1")
    end
    
    local disableAllBtn = vgui.Create("DButton", speechBtnContainer)
    disableAllBtn:SetPos(150, 0)
    disableAllBtn:SetSize(140, 28)
    disableAllBtn:SetText("Disable All Speech")
    disableAllBtn:SetFont("NaiFont_Normal")
    disableAllBtn:SetTextColor(Theme.textBright)
    disableAllBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(180, 50, 50) or Color(150, 40, 40)
        draw.RoundedBox(4, 0, 0, w, h, col)
    end
    disableAllBtn.DoClick = function()
        RunConsoleCommand("nai_npc_speech_enabled", "0")
        RunConsoleCommand("nai_npc_speech_crash", "0")
        RunConsoleCommand("nai_npc_speech_idle", "0")
        RunConsoleCommand("nai_npc_speech_board", "0")
        RunConsoleCommand("nai_npc_ambient_sounds", "0")
        RunConsoleCommand("nai_npc_talking_gestures", "0")
        RunConsoleCommand("nai_npc_crash_flinch", "0")
        RunConsoleCommand("nai_npc_body_sway", "0")
        RunConsoleCommand("nai_npc_threat_awareness", "0")
        RunConsoleCommand("nai_npc_combat_alert", "0")
        RunConsoleCommand("nai_npc_passenger_interaction", "0")
        RunConsoleCommand("nai_npc_fear_reactions", "0")
        RunConsoleCommand("nai_npc_drowsiness", "0")
        RunConsoleCommand("nai_npc_head_look", "0")
        RunConsoleCommand("nai_npc_blink", "0")
        RunConsoleCommand("nai_npc_breathing", "0")
    end

    CreateSpacer(speechPanel, 10)
    CreateSubHeader(speechPanel, "Crash Reactions")
    
    CreateCheckbox(speechPanel, "Enable Crash Sounds", "nai_npc_speech_crash")
    CreateHelpText(speechPanel, "NPCs grunt/yelp when vehicle decelerates sharply (crashes, hard braking).")
    
    CreateSlider(speechPanel, "Crash Sensitivity", "nai_npc_speech_crash_threshold", 100, 1000, 0)
    CreateHelpText(speechPanel, "Deceleration needed to trigger crash sounds. Lower = more sensitive.")
    
    CreateSlider(speechPanel, "Crash Sound Cooldown", "nai_npc_speech_crash_cooldown", 0.5, 5, 1)
    CreateHelpText(speechPanel, "Minimum seconds between crash sounds per NPC.")
    
    CreateSpacer(speechPanel, 10)
    CreateSubHeader(speechPanel, "Idle Chatter")
    
    CreateCheckbox(speechPanel, "Enable Idle Chatter", "nai_npc_speech_idle")
    CreateHelpText(speechPanel, "NPCs occasionally speak while riding - comments, questions, observations.")
    
    CreateSlider(speechPanel, "Chatter Chance", "nai_npc_speech_idle_chance", 0, 1, 2)
    CreateHelpText(speechPanel, "Probability of chatter per check. 0 = never, 1 = always tries to speak.")
    
    CreateSlider(speechPanel, "Chatter Interval", "nai_npc_speech_idle_interval", 5, 60, 0)
    CreateHelpText(speechPanel, "Minimum seconds between idle chatter attempts.")
    
    CreateSpacer(speechPanel, 10)
    CreateSubHeader(speechPanel, "Board/Exit Sounds")
    
    CreateCheckbox(speechPanel, "Enable Board/Exit Sounds", "nai_npc_speech_board")
    CreateHelpText(speechPanel, "NPCs speak when entering and exiting vehicles.")
    
    CreateSpacer(speechPanel, 10)
    CreateSubHeader(speechPanel, "Ambient Sounds")
    
    CreateCheckbox(speechPanel, "Enable Ambient Sounds", "nai_npc_ambient_sounds")
    CreateHelpText(speechPanel, "Occasional coughs, sighs, hums - background life sounds.")
    
    CreateSlider(speechPanel, "Ambient Sound Interval", "nai_npc_ambient_interval", 10, 120, 0)
    CreateHelpText(speechPanel, "Average seconds between ambient sounds.")
    
    CreateSpacer(speechPanel, 15)
    CreateSectionHeader(speechPanel, "Animation & Behavior")
    CreateHelpText(speechPanel, "Fine-tune NPC animations and head movement.")
    
    CreateSpacer(speechPanel, 5)
    
    CreateCheckbox(speechPanel, "Enable Head/Eye Looking", "nai_npc_head_look")
    CreateHelpText(speechPanel, "NPCs naturally look around, at the player, out windows, etc.")
    
    CreateSlider(speechPanel, "Head Smoothness", "nai_npc_head_smooth", 0.1, 1, 2)
    CreateHelpText(speechPanel, "How smoothly the head moves. Lower = snappier, higher = floaty.")
    
    CreateCheckbox(speechPanel, "Enable Blinking", "nai_npc_blink")
    CreateHelpText(speechPanel, "NPCs blink realistically while sitting.")
    
    CreateCheckbox(speechPanel, "Enable Breathing", "nai_npc_breathing")
    CreateHelpText(speechPanel, "Subtle breathing animation on NPC heads.")
    
    CreateSlider(speechPanel, "Walk Timeout", "nai_npc_walk_timeout", 1, 15, 0)
    CreateHelpText(speechPanel, "Seconds before NPC gives up walking to vehicle.")
    
    CreateSpacer(speechPanel, 15)
    CreateSectionHeader(speechPanel, "Advanced Realism")
    CreateHelpText(speechPanel, "Physics-based reactions and awareness systems for ultimate immersion.")
    
    CreateSpacer(speechPanel, 5)
    CreateSubHeader(speechPanel, "Gesture Animations")
    
    CreateCheckbox(speechPanel, "Enable Talking Gestures", "nai_npc_talking_gestures")
    CreateHelpText(speechPanel, "NPCs randomly play hand gestures and body animations while riding.")
    
    CreateSlider(speechPanel, "Gesture Chance (%)", "nai_npc_gesture_chance", 1, 50, 0)
    CreateHelpText(speechPanel, "Percent chance to play a gesture each interval.")
    
    CreateSlider(speechPanel, "Gesture Interval", "nai_npc_gesture_interval", 3, 30, 0)
    CreateHelpText(speechPanel, "Seconds between gesture opportunity checks.")
    
    CreateCheckbox(speechPanel, "Enable Crash Flinch", "nai_npc_crash_flinch")
    CreateHelpText(speechPanel, "NPCs flinch and lurch forward when vehicle crashes or brakes hard.")
    
    CreateSlider(speechPanel, "Crash Sensitivity", "nai_npc_crash_threshold", 200, 800, 0)
    CreateHelpText(speechPanel, "Velocity change needed to trigger flinch (lower = more sensitive).")
    
    CreateSpacer(speechPanel, 10)
    CreateSubHeader(speechPanel, "Body Physics")
    
    CreateCheckbox(speechPanel, "Enable Body Sway", "nai_npc_body_sway")
    CreateHelpText(speechPanel, "NPCs lean into turns, brace during acceleration/braking.")
    
    CreateSlider(speechPanel, "Sway Intensity", "nai_npc_body_sway_amount", 0.1, 3, 1)
    CreateHelpText(speechPanel, "How much NPCs sway with vehicle movement.")
    
    CreateSpacer(speechPanel, 10)
    CreateSubHeader(speechPanel, "Threat Awareness")
    
    CreateCheckbox(speechPanel, "Enable Threat Awareness", "nai_npc_threat_awareness")
    CreateHelpText(speechPanel, "NPCs automatically look toward nearby enemies.")
    
    CreateSlider(speechPanel, "Threat Detection Range", "nai_npc_threat_range", 500, 5000, 0)
    CreateHelpText(speechPanel, "How far NPCs can detect threats for head tracking.")
    
    CreateCheckbox(speechPanel, "Combat Alertness", "nai_npc_combat_alert")
    CreateHelpText(speechPanel, "NPCs become tense and reactive when enemies are near.")

    CreateCheckbox(speechPanel, "NPCs shoot from vehicles (Experimental)", "nai_npc_passenger_combat")
    CreateHelpText(speechPanel, "Disabled by default. Enable this to let armed passengers fire from inside vehicles.")

    CreateSlider(speechPanel, "Passenger Combat Range", "nai_npc_passenger_combat_range", 500, 5000, 0)
    CreateHelpText(speechPanel, "How far armed passengers can acquire targets.")

    CreateSlider(speechPanel, "Passenger Accuracy", "nai_npc_passenger_combat_accuracy", 0.1, 1, 2)
    CreateHelpText(speechPanel, "Higher values tighten shot spread for armed passengers.")

    CreateSlider(speechPanel, "Passenger Damage Multiplier", "nai_npc_passenger_combat_damage", 0.25, 3, 2)
    CreateHelpText(speechPanel, "Scales the damage dealt by passenger-fired shots.")
    
    CreateCheckbox(speechPanel, "Passenger Interaction", "nai_npc_passenger_interaction")
    CreateHelpText(speechPanel, "Multiple passengers look at and occasionally chat with each other.")
    
    CreateSpacer(speechPanel, 10)
    CreateSubHeader(speechPanel, "Emotional States")
    
    CreateCheckbox(speechPanel, "Enable Fear Reactions", "nai_npc_fear_reactions")
    CreateHelpText(speechPanel, "NPCs get scared by dangerous driving - wide eyes, panicked sounds.")
    
    CreateSlider(speechPanel, "Fear Speed Threshold", "nai_npc_fear_speed", 400, 2000, 0)
    CreateHelpText(speechPanel, "Speed (units/sec) at which NPCs start getting nervous.")
    
    CreateCheckbox(speechPanel, "Enable Drowsiness", "nai_npc_drowsiness")
    CreateHelpText(speechPanel, "NPCs get sleepy on long, calm rides - slow blinks, head nods.")
    
    CreateSlider(speechPanel, "Drowsy Time", "nai_npc_drowsy_time", 20, 180, 0)
    CreateHelpText(speechPanel, "Seconds of calm riding before drowsiness kicks in.")
    
    -- Tank/LVS Tab
    local tankPanel = CreateContentPanel()
    tankPanel.SearchPanelName = "Tank/LVS"
    local tankBtn = CreateNavButton("Tank/LVS", "icon16/shield.png")
    tankPanel.SearchNavButton = tankBtn
    tankBtn.DoClick = function() SwitchToPanel(tankPanel, tankBtn) end
    
    CreateSectionHeader(tankPanel, "Tank / LVS Vehicle Settings")
    CreateHelpText(tankPanel, "Settings for tanks, APCs, and LVS vehicles.")
    
    CreateSpacer(tankPanel, 5)
    
    CreateCheckbox(tankPanel, "Hide NPCs in Enclosed Vehicles", "nai_npc_hide_in_tanks")
    CreateHelpText(tankPanel, "Make NPC passengers invisible when inside tanks and APCs.")

    CreateCheckbox(tankPanel, "Auto-Eject Stuck NPCs", "nai_npc_eject_stuck_check")
    CreateHelpText(tankPanel, "Automatically push NPCs out of vehicles when they get stuck during ejection. Prevents NPCs from clipping into vehicles when exiting.")

    CreateCheckbox(tankPanel, "No-Collide With Vehicle After Detach", "nai_npc_detach_no_collide")
    CreateHelpText(tankPanel, "After detaching, NPCs temporarily pass through the vehicle so they can walk away without clipping or getting stuck.")

    CreateSlider(tankPanel, "No-Collide Duration (seconds)", "nai_npc_detach_no_collide_duration", 1, 15, 1)
    CreateHelpText(tankPanel, "How long NPCs ignore the vehicle's collision after detaching.")

    CreateCheckbox(tankPanel, "Kill Passengers When Vehicle Explodes", "nai_npc_die_with_vehicle")
    CreateHelpText(tankPanel, "NPC passengers die when their vehicle is destroyed by explosion or fire (more immersive than them walking out of a wreck unharmed).")

    CreateSpacer(tankPanel, 10)
    CreateSubHeader(tankPanel, "NPC Auto-Driver")
    
    CreateCheckbox(tankPanel, "Enable Auto-Drive", "nai_npc_driver_enabled")
    CreateHelpText(tankPanel, "Allow NPCs in driver seat to automatically drive toward enemies.")
    
    CreateSlider(tankPanel, "Detection Range", "nai_npc_driver_range", 500, 10000, 0)
    CreateHelpText(tankPanel, "Maximum range for driver to detect enemies.")
    
    CreateSlider(tankPanel, "Engage Distance", "nai_npc_driver_engage_distance", 200, 2000, 0)
    CreateHelpText(tankPanel, "Distance to maintain from enemies.")
    
    CreateSlider(tankPanel, "Drive Speed", "nai_npc_driver_speed", 0.1, 1, 2)
    CreateHelpText(tankPanel, "Throttle amount (0.1 = slow, 1 = full speed).")
    
    CreateSlider(tankPanel, "Reverse Distance", "nai_npc_driver_reverse_distance", 100, 800, 0)
    CreateHelpText(tankPanel, "Distance at which to reverse away from enemies.")
    
    CreateSpacer(tankPanel, 10)
    CreateSubHeader(tankPanel, "Turret Control (Experimental)")
    
    CreateCheckbox(tankPanel, "Enable Turret Control", "nai_npc_turret_enabled")
    CreateHelpText(tankPanel, "Allow NPCs to control turrets on LVS vehicles.")
    
    CreateSlider(tankPanel, "Target Range", "nai_npc_turret_range", 500, 10000, 0)
    CreateSlider(tankPanel, "Accuracy", "nai_npc_turret_accuracy", 0, 1, 2)
    CreateSlider(tankPanel, "Reaction Time", "nai_npc_turret_reaction_time", 0, 3, 2)
    CreateSlider(tankPanel, "Fire Delay", "nai_npc_turret_fire_delay", 0.05, 1, 2)
    CreateSlider(tankPanel, "Aim Speed", "nai_npc_turret_aim_speed", 1, 20, 1)

    CreateCheckbox(tankPanel, "Lead Targets", "nai_npc_turret_lead_targets")
    CreateCheckbox(tankPanel, "Allow Friendly Fire", "nai_npc_turret_friendly_fire")
    CreateCheckbox(tankPanel, "Hold Fire (Disable Firing)", "nai_npc_turret_hold_fire")

    -- QoL: Turret NPC Blacklist
    CreateSpacer(tankPanel, 10)
    CreateSubHeader(tankPanel, "Turret NPC Blacklist")
    
    local blacklistLabel = vgui.Create("DLabel", tankPanel)
    blacklistLabel:SetText("Blacklisted NPC Classes")
    blacklistLabel:SetFont("NaiFont_Normal")
    blacklistLabel:SetTextColor(Theme.text)
    blacklistLabel:Dock(TOP)
    blacklistLabel:SetTall(20)
    
    local blacklistEntry = vgui.Create("DTextEntry", tankPanel)
    blacklistEntry:SetFont("NaiFont_Normal")
    blacklistEntry:SetTextColor(Theme.text)
    blacklistEntry:SetTall(28)
    blacklistEntry:Dock(TOP)
    blacklistEntry:SetPlaceholderText("e.g., npc_metropolice,npc_combine_s")
    blacklistEntry:SetValue(GetConVar("nai_npc_turret_blacklist") and GetConVar("nai_npc_turret_blacklist"):GetString() or "")
    blacklistEntry.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Theme.bgLighter)
        if self:GetValue() == "" and not self:HasFocus() then
            draw.SimpleText(self:GetPlaceholderText(), "NaiFont_Normal", 8, h/2, Theme.textDim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
    end
    blacklistEntry.OnChange = function(self)
        RunConsoleCommand("nai_npc_turret_blacklist", self:GetValue())
    end
    
    local blacklistHelp = vgui.Create("DLabel", tankPanel)
    blacklistHelp:SetText("Comma-separated list of NPC classnames that cannot use turrets. Use 'getnpcblacklist' console command to see current blacklist.")
    blacklistHelp:SetFont("NaiFont_Small")
    blacklistHelp:SetTextColor(Theme.textDim)
    blacklistHelp:SetAutoStretchVertical(true)
    blacklistHelp:Dock(TOP)
    blacklistHelp:SetTall(30)
    
    -- HUD Tab
    local hudPanel = CreateContentPanel()
    hudPanel.SearchPanelName = "HUD"
    local hudBtn = CreateNavButton("HUD", "icon16/eye.png")
    hudPanel.SearchNavButton = hudBtn
    hudBtn.DoClick = function() SwitchToPanel(hudPanel, hudBtn) end
    
    CreateSectionHeader(hudPanel, "HUD Display")
    
    CreateCheckbox(hudPanel, "Enable Passenger HUD", "nai_npc_hud_enabled")
    CreateHelpText(hudPanel, "Shows passenger status (emotions, alertness) on screen while driving.")
    
    CreateCheckbox(hudPanel, "Only Show When In Vehicle", "nai_npc_hud_only_vehicle")
    CreateCheckbox(hudPanel, "Show Calm Passengers", "nai_npc_hud_show_calm")
    CreateCheckbox(hudPanel, "Show Context Hints", "nai_npc_hud_hints")
    CreateCheckbox(hudPanel, "Show Target Debug", "nai_npc_hud_target_debug")
    CreateCheckbox(hudPanel, "Play Success/Fail Cues", "nai_npc_client_cues")
    CreateHelpText(hudPanel, "When disabled, only shows passengers with non-calm status.")
    
    CreateSpacer(hudPanel, 10)
    CreateSectionHeader(hudPanel, "HUD Position & Style")
    
    -- Position dropdown
    local posLabel = vgui.Create("DLabel", hudPanel)
    posLabel:SetText("HUD Position")
    posLabel:SetFont("NaiFont_Normal")
    posLabel:SetTextColor(Theme.text)
    posLabel:Dock(TOP)
    posLabel:DockMargin(10, 8, 10, 2)
    
    local posCombo = vgui.Create("DComboBox", hudPanel)
    posCombo.SearchLabel = "HUD Position"
    posCombo.SearchConVar = "nai_npc_hud_position"
    posCombo:Dock(TOP)
    posCombo:DockMargin(10, 0, 10, 5)
    posCombo:SetTall(28)
    posCombo:SetFont("NaiFont_Normal")
    posCombo:SetTextColor(Theme.text)
    posCombo:AddChoice("Top Left", 0)
    posCombo:AddChoice("Top Right", 1)
    posCombo:AddChoice("Bottom Left", 2)
    posCombo:AddChoice("Bottom Right", 3)
    posCombo.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Theme.bgLighter)
        if self:IsMenuOpen() then
            surface.SetDrawColor(Theme.accent)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end
    end
    local currentPos = GetConVar("nai_npc_hud_position"):GetInt()
    posCombo:SetValue(HUD_POSITION_NAMES[currentPos] or "Top Right")
    posCombo.OnSelect = function(self, index, value, data)
        RunConsoleCommand("nai_npc_hud_position", tostring(data))
    end
    
    CreateSlider(hudPanel, "HUD Scale", "nai_npc_hud_scale", 0.5, 2, 2)
    CreateSlider(hudPanel, "HUD Opacity", "nai_npc_hud_opacity", 0.3, 1, 2)
    
    CreateSpacer(hudPanel, 10)
    CreateSectionHeader(hudPanel, "Emotion Thresholds")
    CreateHelpText(hudPanel, "When emotion levels exceed these thresholds, passengers show that status in the HUD.")
    
    CreateSlider(hudPanel, "Alert Threshold", "nai_npc_hud_alert_threshold", 0.1, 1, 2)
    CreateHelpText(hudPanel, "Alert level needed to show 'ALERT' status (threat detected).")
    
    CreateSlider(hudPanel, "Fear Threshold", "nai_npc_hud_fear_threshold", 0.1, 1, 2)
    CreateHelpText(hudPanel, "Fear level needed to show 'SCARED' status (dangerous driving).")
    
    CreateSlider(hudPanel, "Drowsy Threshold", "nai_npc_hud_drowsy_threshold", 0.3, 1, 2)
    CreateHelpText(hudPanel, "Calm time ratio needed to show 'DROWSY' status (long calm ride).")
    
    CreateSpacer(hudPanel, 15)
    CreateSectionHeader(hudPanel, "Emotion Actions")
    CreateHelpText(hudPanel, "Choose what action passengers take when experiencing each emotional state.")
    
    -- Action choices table
    local actionChoices = {
        {name = "Do Nothing", value = 0},
        {name = "Exit Vehicle", value = 1},
        {name = "Play Sound", value = 2},
        {name = "Duck / Crouch", value = 3},
        {name = "Look Around", value = 4},
        {name = "Cover Face", value = 5},
        {name = "Fall Asleep", value = 6}
    }
    
    -- Helper function to create action dropdown
    local function CreateActionDropdown(parent, label, convar)
        local container = vgui.Create("DPanel", parent)
        container.SearchLabel = label
        container.SearchConVar = convar
        container:Dock(TOP)
        container:DockMargin(10, 8, 10, 0)
        container:SetTall(28)
        container.Paint = function() end
        
        local lbl = vgui.Create("DLabel", container)
        lbl:SetText(label)
        lbl:SetFont("NaiFont_Normal")
        lbl:SetTextColor(Theme.text)
        lbl:Dock(LEFT)
        lbl:SetWide(150)
        
        local combo = vgui.Create("DComboBox", container)
        combo:Dock(FILL)
        combo:SetFont("NaiFont_Normal")
        combo:SetTextColor(Theme.text)
        combo.Paint = function(self, w, h)
            draw.RoundedBox(4, 0, 0, w, h, Theme.bgLighter)
            if self:IsMenuOpen() then
                surface.SetDrawColor(Theme.accent)
                surface.DrawOutlinedRect(0, 0, w, h, 1)
            end
        end
        
        for _, choice in ipairs(actionChoices) do
            combo:AddChoice(choice.name, choice.value)
        end
        
        local cv = GetConVar(convar)
        local currentVal = cv and cv:GetInt() or 0
        for _, choice in ipairs(actionChoices) do
            if choice.value == currentVal then
                combo:SetValue(choice.name)
                break
            end
        end
        
        combo.OnSelect = function(self, index, value, data)
            RunConsoleCommand(convar, tostring(data))
        end
        
        return container
    end
    
    CreateActionDropdown(hudPanel, "If Calm:", "nai_npc_action_calm")
    CreateActionDropdown(hudPanel, "If Alert:", "nai_npc_action_alert")
    CreateActionDropdown(hudPanel, "If Scared:", "nai_npc_action_scared")
    CreateActionDropdown(hudPanel, "If Drowsy:", "nai_npc_action_drowsy")
    
    CreateSpacer(hudPanel, 5)
    CreateHelpText(hudPanel, "Note: Some actions may not be visible depending on NPC model support.")
    
    -- Keybinds Tab
    local keybindsPanel = CreateContentPanel()
    keybindsPanel.SearchPanelName = "Keybinds"
    local keybindsBtn = CreateNavButton("Keybinds", "icon16/keyboard.png")
    keybindsPanel.SearchNavButton = keybindsBtn
    keybindsBtn.DoClick = function() SwitchToPanel(keybindsPanel, keybindsBtn) end
    local keybindButtons = {}
    
    -- Helper function to create keybind button
    local function CreateKeybindButton(parent, label, convar, description)
        local container = vgui.Create("DPanel", parent)
        container.SearchLabel = label
        container.SearchDescription = description
        container.SearchConVar = convar
        container:Dock(TOP)
        container:DockMargin(10, 5, 10, 0)
        container:SetTall(50)
        container.Paint = function(self, w, h)
            draw.RoundedBox(4, 0, 0, w, h, Theme.bgLighter)
        end
        
        local lbl = vgui.Create("DLabel", container)
        lbl:SetText(label)
        lbl:SetFont("NaiFont_Bold")
        lbl:SetTextColor(Theme.text)
        lbl:SetPos(10, 8)
        lbl:SizeToContents()
        
        local desc = vgui.Create("DLabel", container)
        desc:SetText(description)
        desc:SetFont("NaiFont_Small")
        desc:SetTextColor(Theme.textDim)
        desc:SetPos(10, 26)
        desc:SizeToContents()
        
        local btn = vgui.Create("DButton", container)
        btn:SetFont("NaiFont_Normal")
        btn:SetTextColor(TransparentColor)
        btn:SetSize(120, 35)
        btn.isBinding = false
        btn.hoverAnim = 0
        btn.pressAnim = 0
        
        -- Load saved keybind
        local cvar = GetConVar(convar)
        if cvar then
            local savedKey = cvar:GetInt()
            if savedKey > 0 then
                btn:SetText(input.GetKeyName(savedKey) or "Not Bound")
            else
                btn:SetText("Not Bound")
            end
        else
            btn:SetText("Not Bound")
        end
        
        btn.Paint = function(self, w, h)
            AnimateButtonVisualState(self, 8, 10, 18, 12)

            local pushOffset = GetButtonPushOffset(self, self.isBinding and 0 or 2)
            local col = Color(60, 60, 70)
            if self.isBinding then
                col = Theme.accentActive
            else
                col = LerpColor(self.hoverAnim, Color(60, 60, 70), Theme.accent)
                col = LerpColor(self.pressAnim, col, Color(50, 50, 60))
            end
            draw.RoundedBox(4, 0, pushOffset, w, h, col)
            draw.SimpleText(self:GetText(), "NaiFont_Normal", w / 2, (h / 2) + pushOffset, Theme.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        
        btn.DoClick = function()
            if btn.isBinding then return end
            btn.isBinding = true
            btn:SetText("Press a key...")
            btn:RequestFocus()
        end
        
        btn.OnKeyCodePressed = function(self, key)
            if not self.isBinding then return end
            
            -- Ignore mouse buttons and escape
            if key == KEY_ESCAPE or key == MOUSE_LEFT or key == MOUSE_RIGHT or key == MOUSE_MIDDLE then
                self.isBinding = false
                -- Restore previous binding
                local cvar = GetConVar(convar)
                if cvar then
                    local savedKey = cvar:GetInt()
                    if savedKey > 0 then
                        self:SetText(input.GetKeyName(savedKey) or "Not Bound")
                    else
                        self:SetText("Not Bound")
                    end
                else
                    self:SetText("Not Bound")
                end
                return
            end
            
            -- Save the keybind
            RunConsoleCommand(convar, tostring(key))
            self:SetText(input.GetKeyName(key) or "Key " .. key)
            self.isBinding = false
        end
        
        -- Right click to unbind
        btn.DoRightClick = function()
            RunConsoleCommand(convar, "0")
            btn:SetText("Not Bound")
        end
        
        -- Align button to right side after container is sized
        container.PerformLayout = function(self, w, h)
            btn:SetPos(w - 130, 8)
        end

        keybindButtons[convar] = btn
        
        return container
    end
    
    CreateSectionHeader(keybindsPanel, "Action Keybinds")
    CreateHelpText(keybindsPanel, "Set custom keybinds for NPC passenger actions. Click a button and press a key to bind.")
    
    local keybindConvars = {
        {name = "Attach Nearest NPC", cvar = "nai_npc_key_attach", desc = "Attach the nearest friendly NPC to your vehicle"},
        {name = "Detach All Passengers", cvar = "nai_npc_key_detach_all", desc = "Remove all NPCs from your vehicle"},
        {name = "Toggle Auto-Join", cvar = "nai_npc_key_toggle_autojoin", desc = "Enable/disable automatic NPC boarding"},
        {name = "Open Settings Menu", cvar = "nai_npc_key_menu", desc = "Open the Better NPC Passengers settings panel"},
        {name = "Quick Attach Mode", cvar = "nai_npc_key_quick_attach", desc = "Hold to quickly attach NPCs you're looking at"},
    }
    
    for _, keybind in ipairs(keybindConvars) do
        CreateKeybindButton(keybindsPanel, keybind.name, keybind.cvar, keybind.desc)
    end
    
    CreateSpacer(keybindsPanel, 10)
    CreateSectionHeader(keybindsPanel, "Vehicle Control")
    
    local vehicleKeybinds = {
        {name = "NPCs Exit Vehicle", cvar = "nai_npc_key_exit_all", desc = "Command all passengers to exit the vehicle"},
        {name = "NPCs Hold Fire", cvar = "nai_npc_key_hold_fire", desc = "Tell gunner NPCs to stop firing"},
        {name = "NPCs Open Fire", cvar = "nai_npc_key_open_fire", desc = "Tell gunner NPCs to engage targets"},
        {name = "Cycle Passenger View", cvar = "nai_npc_key_cycle_view", desc = "Cycle camera through passengers"},
    }
    
    for _, keybind in ipairs(vehicleKeybinds) do
        CreateKeybindButton(keybindsPanel, keybind.name, keybind.cvar, keybind.desc)
    end
    
    CreateSpacer(keybindsPanel, 10)
    CreateSectionHeader(keybindsPanel, "HUD Controls")
    CreateHelpText(keybindsPanel, "Quick HUD controls for showing, moving, and debugging the passenger overlay.")

    local hudKeybinds = {
        {name = "Toggle Passenger HUD", cvar = "nai_npc_key_toggle_hud", desc = "Show or hide the passenger status HUD"},
        {name = "Cycle HUD Position", cvar = "nai_npc_key_cycle_hud_position", desc = "Move the passenger HUD through all four corners"},
        {name = "Toggle Target Debug", cvar = "nai_npc_key_debug_hud", desc = "Toggle the small target debug overlay"},
    }

    for _, keybind in ipairs(hudKeybinds) do
        CreateKeybindButton(keybindsPanel, keybind.name, keybind.cvar, keybind.desc)
    end

    CreateSpacer(keybindsPanel, 10)
    CreateSectionHeader(keybindsPanel, "Debug Controls")
    CreateHelpText(keybindsPanel, "Debug keybinds only work when Debug Mode is enabled.")
    
    local debugKeybinds = {
        {name = "Test Random Gesture", cvar = "nai_npc_key_test_gesture", desc = "Play a random gesture on nearest passenger"},
        {name = "Reset All NPCs", cvar = "nai_npc_key_reset_all", desc = "Reset animation states for all passengers"},
    }
    
    for _, keybind in ipairs(debugKeybinds) do
        CreateKeybindButton(keybindsPanel, keybind.name, keybind.cvar, keybind.desc)
    end

    CreateSpacer(keybindsPanel, 8)
    CreateButton(keybindsPanel, "Apply Recommended Keybinds", function()
        local recommendedKeys = {
            nai_npc_key_attach = KEY_G,
            nai_npc_key_detach_all = KEY_J,
            nai_npc_key_toggle_autojoin = KEY_H,
            nai_npc_key_menu = KEY_F6,
            nai_npc_key_exit_all = KEY_Y,
            nai_npc_key_cycle_view = KEY_V,
            nai_npc_key_toggle_hud = KEY_F8,
            nai_npc_key_cycle_hud_position = KEY_F9,
        }

        for convar, keyCode in pairs(recommendedKeys) do
            RunConsoleCommand(convar, tostring(keyCode))
            local button = keybindButtons[convar]
            if IsValid(button) then
                button.isBinding = false
                button:SetText(input.GetKeyName(keyCode) or ("Key " .. keyCode))
            end
        end

        chat.AddText(Theme.success, ADDON_CHAT_PREFIX, Theme.text, "Recommended keybinds applied.")
    end)

    CreateSpacer(keybindsPanel, 4)
    CreateButton(keybindsPanel, "Clear All Keybinds", function()
        for convar, button in pairs(keybindButtons) do
            RunConsoleCommand(convar, "0")
            if IsValid(button) then
                button.isBinding = false
                button:SetText("Not Bound")
            end
        end

        chat.AddText(Theme.success, ADDON_CHAT_PREFIX, Theme.text, "All keybinds cleared.")
    end)
    
    CreateSpacer(keybindsPanel, 10)
    local infoLabel = vgui.Create("DLabel", keybindsPanel)
    infoLabel:SetText("Tip: Right-click a keybind to unbind it. Press ESC while binding to cancel.")
    infoLabel:SetFont("NaiFont_Small")
    infoLabel:SetTextColor(Color(150, 150, 165))
    infoLabel:Dock(TOP)
    infoLabel:DockMargin(10, 5, 10, 10)
    infoLabel:SetWrap(true)
    infoLabel:SetAutoStretchVertical(true)
    
    -- Debugging Tab
    local debugPanel = CreateContentPanel()
    debugPanel.SearchPanelName = "Debugging"
    local debugBtn = CreateNavButton("Debugging", "icon16/bug.png")
    debugPanel.SearchNavButton = debugBtn
    debugBtn.DoClick = function() SwitchToPanel(debugPanel, debugBtn) end
    
    CreateSectionHeader(debugPanel, "Debug Tools")
    CreateHelpText(debugPanel, "Advanced debugging tools for testing NPC behavior. Enable Debug Mode in settings first.")
    
    CreateSpacer(debugPanel, 5)
    
    CreateCheckbox(debugPanel, "Enable Debug Mode", "nai_npc_debug_mode")
    CreateHelpText(debugPanel, "Shows debug test buttons and enables debug commands.")
    
    CreateSpacer(debugPanel, 15)
    CreateSectionHeader(debugPanel, "Passenger Status Control")
    CreateHelpText(debugPanel, "Manually set passenger status for testing. Click 'Refresh List' to see current passengers.")
    
    local passengerListPanel = vgui.Create("DScrollPanel", debugPanel)
    passengerListPanel:Dock(TOP)
    passengerListPanel:SetTall(400)
    passengerListPanel:DockMargin(5, 5, 5, 5)
    StyleScrollbar(passengerListPanel:GetVBar())
    passengerListPanel.Paint = function(self, w, h)
        draw.RoundedBox(6, 0, 0, w, h, Theme.bgDark)
    end
    
    local function RefreshPassengerList()
        passengerListPanel:Clear()
        
        local passengers = GetTrackedPassengerEntities(true)
        
        if #passengers == 0 then
            local noPassengers = vgui.Create("DLabel", passengerListPanel)
            noPassengers:SetText("No passengers found. NPCs must be in a vehicle.")
            noPassengers:SetFont("NaiFont_Normal")
            noPassengers:SetTextColor(Theme.textDim)
            noPassengers:Dock(TOP)
            noPassengers:DockMargin(10, 10, 10, 10)
            noPassengers:SetWrap(true)
            noPassengers:SetAutoStretchVertical(true)
            return
        end
        
        for _, npc in ipairs(passengers) do
            if not IsValid(npc) then continue end
            
            local npcPanel = vgui.Create("DPanel", passengerListPanel)
            npcPanel:Dock(TOP)
            npcPanel:SetTall(90)
            npcPanel:DockMargin(8, 4, 8, 4)
            npcPanel.Paint = function(self, w, h)
                if not IsValid(npc) then return end
                
                draw.RoundedBox(4, 0, 0, w, h, Theme.bgLighter)
                
                -- NPC info
                local npcName = npc:GetClass() .. " #" .. npc:EntIndex()
                draw.SimpleText(npcName, "NaiFont_Bold", 10, 10, Theme.textBright)
                
                local vehicle = npc:GetParent()
                if IsValid(vehicle) then
                    draw.SimpleText("Vehicle: " .. vehicle:GetClass(), "NaiFont_Small", 10, 30, Theme.textDim)
                end
            end
            
            -- Status buttons
            local statusButtons = {
                {name = "Calm", status = "calm", col = Color(100, 200, 100)},
                {name = "Alert", status = "alert", col = Color(255, 200, 100)},
                {name = "Scared", status = "scared", col = Color(255, 100, 100)},
                {name = "Drowsy", status = "drowsy", col = Color(150, 150, 200)},
                {name = "Dead", status = "dead", col = Color(80, 80, 90)},
            }
            
            local xPos = 10
            for _, btnData in ipairs(statusButtons) do
                local statusBtn = vgui.Create("DButton", npcPanel)
                statusBtn:SetPos(xPos, 55)
                statusBtn:SetSize(90, 28)
                statusBtn:SetText(btnData.name)
                statusBtn:SetFont("NaiFont_Normal")
                statusBtn:SetTextColor(Theme.textBright)
                statusBtn.Paint = function(self, w, h)
                    local col = btnData.col
                    if self:IsHovered() then
                        col = Color(math.min(col.r + 30, 255), math.min(col.g + 30, 255), math.min(col.b + 30, 255))
                    end
                    if self:IsDown() then
                        col = Color(math.max(col.r - 30, 0), math.max(col.g - 30, 0), math.max(col.b - 30, 0))
                    if not IsValid(npc) then return end
                    
                    end
                    draw.RoundedBox(4, 0, 0, w, h, col)
                end
                statusBtn.DoClick = function()
                    net.Start("NPCPassengers_SetStatus")
                    net.WriteInt(npc:EntIndex(), 32)
                    net.WriteString(btnData.status)
                    net.SendToServer()
                end
                
                xPos = xPos + 95
            end
        end
    end
    
    local refreshBtn = CreateButton(debugPanel, "Refresh Passenger List", RefreshPassengerList)
    
    CreateSpacer(debugPanel, 15)
    CreateSectionHeader(debugPanel, "Quick Test Buttons")
    
    CreateButton(debugPanel, "Test Flinch Gesture", function()
        net.Start("NPCPassengers_DebugTest")
        net.WriteString("flinch")
        net.SendToServer()
    end)
    
    CreateButton(debugPanel, "Test Random Gesture", function()
        net.Start("NPCPassengers_DebugTest")
        net.WriteString("gesture")
        net.SendToServer()
    end)
    
    CreateButton(debugPanel, "Reset All States", function()
        net.Start("NPCPassengers_DebugTest")
        net.WriteString("reset")
        net.SendToServer()
    end)
    
    -- NPC Driver Tab
    local driverPanel = CreateContentPanel()
    driverPanel.SearchPanelName = "NPC Driver"
    local driverBtn = CreateNavButton("NPC Driver", "icon16/car.png")
    driverPanel.SearchNavButton = driverBtn
    driverBtn.DoClick = function() SwitchToPanel(driverPanel, driverBtn) end
    
    CreateSectionHeader(driverPanel, "NPC Driver System")
    
    -- Work In Progress Panel
    local wipPanel = vgui.Create("DPanel", driverPanel)
    wipPanel:SetTall(200)
    wipPanel:Dock(TOP)
    wipPanel:DockMargin(10, 10, 10, 10)
    wipPanel.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Theme.bgDark)
        
        -- Rotating Icon
        local angle = (CurTime() * 60) % 360
        surface.SetDrawColor(Theme.accent)
        surface.SetMaterial(Material("icon16/hourglass.png"))
        surface.DrawTexturedRectRotated(w / 2, 62, 64, 64, angle)
        
        draw.SimpleText("Work In Progress", "NaiFont_Title", w/2, 110, Theme.textBright, TEXT_ALIGN_CENTER)
        draw.SimpleText("This feature is currently under development", "NaiFont_Normal", w/2, 140, Theme.textDim, TEXT_ALIGN_CENTER)
        draw.SimpleText("Check back in a future update!", "NaiFont_Normal", w/2, 165, Theme.textDim, TEXT_ALIGN_CENTER)
    end
    
    -- Interface Tab
    local interfacePanel = CreateContentPanel()
    interfacePanel.SearchPanelName = "Interface"
    local interfaceBtn = CreateNavButton("Interface", "icon16/application_view_tile.png")
    interfacePanel.SearchNavButton = interfaceBtn
    interfaceBtn.DoClick = function() SwitchToPanel(interfacePanel, interfaceBtn) end
    
    CreateSectionHeader(interfacePanel, "UI Sound Settings")
    CreateHelpText(interfacePanel, "Configure sound effects for buttons, checkboxes, and other UI elements")
    
    CreateCheckbox(interfacePanel, "Enable UI Sounds", "nai_npc_ui_sounds_enabled")
    CreateHelpText(interfacePanel, "Master switch for all UI sound effects")
    
    CreateSlider(interfacePanel, "UI Sounds Volume", "nai_npc_ui_sounds_volume", 0, 2, 1)
    CreateHelpText(interfacePanel, "Volume multiplier for UI sounds (1.0 = normal, 2.0 = double)")
    
    CreateCheckbox(interfacePanel, "Button Hover Sounds", "nai_npc_ui_hover_enabled")
    CreateHelpText(interfacePanel, "Play sound when hovering over buttons")
    
    CreateCheckbox(interfacePanel, "Button Click Sounds", "nai_npc_ui_click_enabled")
    CreateHelpText(interfacePanel, "Play sound when clicking buttons and checkboxes")
    
    CreateSpacer(interfacePanel, 10)
    CreateSectionHeader(interfacePanel, "Context Menu Options")
    CreateHelpText(interfacePanel, "Choose which options appear when right-clicking NPCs")
    
    CreateCheckbox(interfacePanel, "Show 'Make Passenger'", "nai_npc_context_make_passenger")
    CreateHelpText(interfacePanel, "Add NPC as passenger to your current vehicle")
    
    CreateCheckbox(interfacePanel, "Show 'Make Passenger For Vehicle'", "nai_npc_context_make_passenger_vehicle")
    CreateHelpText(interfacePanel, "Add NPC to a specific vehicle (click NPC, then vehicle)")
    
    CreateCheckbox(interfacePanel, "Show 'Detach Passenger'", "nai_npc_context_detach")
    CreateHelpText(interfacePanel, "Remove NPC from vehicle")

    CreateButton(interfacePanel, "Enable All Context Menu Options", function()
        RunConsoleCommand("nai_npc_context_make_passenger", "1")
        RunConsoleCommand("nai_npc_context_make_passenger_vehicle", "1")
        RunConsoleCommand("nai_npc_context_detach", "1")
        chat.AddText(Theme.success, ADDON_CHAT_PREFIX, Theme.text, "All context menu options enabled.")
    end)

    CreateButton(interfacePanel, "Hide All Context Menu Options", function()
        RunConsoleCommand("nai_npc_context_make_passenger", "0")
        RunConsoleCommand("nai_npc_context_make_passenger_vehicle", "0")
        RunConsoleCommand("nai_npc_context_detach", "0")
        chat.AddText(Theme.success, ADDON_CHAT_PREFIX, Theme.text, "All context menu options hidden.")
    end)
    
    CreateSpacer(interfacePanel, 10)
    CreateSectionHeader(interfacePanel, "Settings Panel Preferences")
    
    CreateCheckbox(interfacePanel, "Show Welcome Screen on Updates", "nai_npc_ui_show_welcome")
    CreateHelpText(interfacePanel, "Display welcome panel when addon is updated to a new version")

    local _, defaultFontCheckbox = CreateCheckbox(interfacePanel, "Use Default Font Instead of Metropolis", "nai_npc_ui_use_default_font")
    CreateHelpText(interfacePanel, "Switch the UI to Garry's Mod default fonts if you prefer cleaner fallback rendering.")

    -- Custom font dropdown and text entry will be created below
    -- We'll set up the OnChange handler after they're created

    -- Custom font dropdown
    local availableFonts = GetAvailableFonts()
    local fontLabel = vgui.Create("DLabel", interfacePanel)
    fontLabel:SetText("Custom Font")
    fontLabel:SetFont("NaiFont_Normal")
    fontLabel:SetTextColor(Theme.text)
    fontLabel:Dock(TOP)
    fontLabel:DockMargin(10, 8, 10, 2)

    local fontCombo = vgui.Create("DComboBox", interfacePanel)
    fontCombo.SearchLabel = "Custom Font"
    fontCombo.SearchConVar = "nai_npc_ui_custom_font"
    fontCombo:Dock(TOP)
    fontCombo:DockMargin(10, 0, 10, 5)
    fontCombo:SetTall(28)
    fontCombo:SetFont("NaiFont_Normal")
    fontCombo:SetTextColor(Theme.text)
    
    for _, font in ipairs(availableFonts) do
        fontCombo:AddChoice(font, font)
    end
    
    local currentFont = GetConVar("nai_npc_ui_custom_font") and GetConVar("nai_npc_ui_custom_font"):GetString() or "Metropolis"
    fontCombo:SetValue(currentFont)
    
    fontCombo.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Theme.bgLighter)
        if self:IsMenuOpen() then
            surface.SetDrawColor(Theme.accent)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end
    end
    
    fontCombo.OnSelect = function(self, index, value, data)
        RunConsoleCommand("nai_npc_ui_custom_font", data)
        if IsValid(customFontText) then
            customFontText:SetText(data)
        end
        InstallAddonFonts()
        CreateNaiFonts()

        if IsValid(settingsFrame) then
            settingsFrame:InvalidateLayout(true)
        end
    end

    CreateHelpText(interfacePanel, "Select a custom font. Add .ttf files to resource/fonts/ and use the actual font name (e.g., 'Roboto', 'Arial'). Changes apply immediately.")

    -- Custom font name text entry
    local customFontLabel = vgui.Create("DLabel", interfacePanel)
    customFontLabel:SetText("Or Enter Custom Font Name")
    customFontLabel:SetFont("NaiFont_Normal")
    customFontLabel:SetTextColor(Theme.text)
    customFontLabel:Dock(TOP)
    customFontLabel:DockMargin(10, 8, 10, 2)

    local customFontText = vgui.Create("DTextEntry", interfacePanel)
    customFontText:Dock(TOP)
    customFontText:DockMargin(10, 0, 10, 5)
    customFontText:SetTall(28)
    customFontText:SetFont("NaiFont_Normal")
    customFontText:SetTextColor(Theme.text)
    customFontText:SetPlaceholderText("e.g., Roboto, Arial, etc.")

    local currentCustomFont = GetConVar("nai_npc_ui_custom_font") and GetConVar("nai_npc_ui_custom_font"):GetString() or ""
    customFontText:SetText(currentCustomFont)

    customFontText.OnEnter = function(self)
        local text = self:GetText()
        RunConsoleCommand("nai_npc_ui_custom_font", text)
        InstallAddonFonts()
        CreateNaiFonts()

        if IsValid(settingsFrame) then
            settingsFrame:InvalidateLayout(true)
        end
    end

    -- Set up the default font checkbox OnChange handler now that controls exist
    local defaultFontOnChange = defaultFontCheckbox.OnChange
    defaultFontCheckbox.OnChange = function(self, val)
        if defaultFontOnChange then
            defaultFontOnChange(self, val)
        end

        InstallAddonFonts()
        CreateNaiFonts()

        if IsValid(settingsFrame) then
            settingsFrame:InvalidateLayout(true)
        end

        -- Hide/show custom font controls based on default font setting
        if IsValid(fontCombo) then
            fontCombo:SetVisible(not val)
        end
        if IsValid(fontLabel) then
            fontLabel:SetVisible(not val)
        end
        if IsValid(customFontLabel) then
            customFontLabel:SetVisible(not val)
        end
        if IsValid(customFontText) then
            customFontText:SetVisible(not val)
        end
    end

    -- Initially hide custom font controls if default font is enabled
    local useDefaultFont = GetConVarBoolSafe("nai_npc_ui_use_default_font", false)
    if useDefaultFont then
        fontCombo:SetVisible(false)
        fontLabel:SetVisible(false)
        customFontLabel:SetVisible(false)
        customFontText:SetVisible(false)
    end


    local _, widthSlider = CreateSlider(interfacePanel, "Panel Width", "nai_npc_ui_panel_width", 800, 1400, 0)
    CreateHelpText(interfacePanel, "Width of the settings panel")
    widthSlider.OnValueChanged = function(_, val)
        if IsValid(settingsFrame) then
            settingsFrame:SetSize(math.floor(val), settingsFrame:GetTall())
            settingsFrame:InvalidateLayout(true)
        end
    end

    local _, heightSlider = CreateSlider(interfacePanel, "Panel Height", "nai_npc_ui_panel_height", 600, 900, 0)
    CreateHelpText(interfacePanel, "Height of the settings panel")
    heightSlider.OnValueChanged = function(_, val)
        if IsValid(settingsFrame) then
            settingsFrame:SetSize(settingsFrame:GetWide(), math.floor(val))
            settingsFrame:InvalidateLayout(true)
        end
    end

    local function ApplyPanelSizePreset(width, height)
        RunConsoleCommand("nai_npc_ui_panel_width", tostring(width))
        RunConsoleCommand("nai_npc_ui_panel_height", tostring(height))

        if IsValid(widthSlider) then
            widthSlider:SetValue(width)
        end

        if IsValid(heightSlider) then
            heightSlider:SetValue(height)
        end

        if IsValid(settingsFrame) then
            settingsFrame:SetSize(width, height)
            settingsFrame:Center()
            settingsFrame:InvalidateLayout(true)
        end
    end

    CreateButton(interfacePanel, "Set Compact Panel Size", function()
        ApplyPanelSizePreset(900, 650)
        chat.AddText(Theme.success, ADDON_CHAT_PREFIX, Theme.text, "Panel size set to compact.")
    end)

    CreateButton(interfacePanel, "Set Default Panel Size", function()
        ApplyPanelSizePreset(950, 700)
        chat.AddText(Theme.success, ADDON_CHAT_PREFIX, Theme.text, "Panel size set to default.")
    end)

    CreateButton(interfacePanel, "Set Large Panel Size", function()
        ApplyPanelSizePreset(1200, 800)
        chat.AddText(Theme.success, ADDON_CHAT_PREFIX, Theme.text, "Panel size set to large.")
    end)

    CreateButton(interfacePanel, "Center Panel Now", function()
        if IsValid(settingsFrame) then
            settingsFrame:Center()
            settingsFrame:InvalidateLayout(true)
            chat.AddText(Theme.success, ADDON_CHAT_PREFIX, Theme.text, "Panel centered.")
        end
    end)
    
    CreateCheckbox(interfacePanel, "Enable UI Animations", "nai_npc_ui_animations")
    CreateHelpText(interfacePanel, "Smooth transitions and hover effects (may impact performance)")
    
    CreateCheckbox(interfacePanel, "Show Tooltips", "nai_npc_ui_tooltips")
    CreateHelpText(interfacePanel, "Display helpful tooltips when hovering over settings")

    CreateCheckbox(interfacePanel, "Auto-Hide Scrollbar", "nai_npc_ui_scrollbar_autohide")
    CreateHelpText(interfacePanel, "Only show the scrollbar while you're scrolling or hovering it.")

    CreateHelpText(interfacePanel, "Note: Panel becomes 70% transparent when dragging any slider to see content in background.")

    local _, scrollSmoothSlider = CreateSlider(interfacePanel, "Sidebar Scroll Smoothness", "nai_npc_ui_scroll_smoothness", 0.01, 1, 2)
    CreateHelpText(interfacePanel, "Lower values = smoother but slower scrolling (0.01-1)")
    
    -- Apply scroll smoothness immediately when changed
    if scrollSmoothSlider and scrollSmoothSlider.OnValueChanged then
        local originalOnValueChanged = scrollSmoothSlider.OnValueChanged
        scrollSmoothSlider.OnValueChanged = function(self, val)
            if originalOnValueChanged then
                originalOnValueChanged(self, val)
            end
            -- Update all existing scrollbars
            for _, sbar in ipairs(sidebarScrollbars or {}) do
                if IsValid(sbar) then
                    sbar.smoothScrollSpeed = math.Clamp(val, 0.01, 1)
                end
            end
        end
    end

    CreateSpacer(interfacePanel, 10)
    CreateSectionHeader(interfacePanel, "Performance & Technical")
    
    CreateButton(interfacePanel, "Reset All UI Settings to Default", function()
        RunConsoleCommand("nai_npc_ui_sounds_enabled", "1")
        RunConsoleCommand("nai_npc_ui_sounds_volume", "1")
        RunConsoleCommand("nai_npc_ui_hover_enabled", "1")
        RunConsoleCommand("nai_npc_ui_click_enabled", "1")
        RunConsoleCommand("nai_npc_context_make_passenger", "1")
        RunConsoleCommand("nai_npc_context_make_passenger_vehicle", "1")
        RunConsoleCommand("nai_npc_context_detach", "1")
        RunConsoleCommand("nai_npc_ui_show_welcome", "1")
        RunConsoleCommand("nai_npc_ui_panel_width", "950")
        RunConsoleCommand("nai_npc_ui_panel_height", "700")
        RunConsoleCommand("nai_npc_ui_use_default_font", "0")
        RunConsoleCommand("nai_npc_ui_animations", "1")
        RunConsoleCommand("nai_npc_ui_tooltips", "1")
        RunConsoleCommand("nai_npc_ui_scrollbar_autohide", "1")
        RunConsoleCommand("nai_npc_ui_scroll_smoothness", "0.15")

        if IsValid(widthSlider) then
            widthSlider:SetValue(950)
        end

        if IsValid(heightSlider) then
            heightSlider:SetValue(700)
        end

        if IsValid(settingsFrame) then
            settingsFrame:SetSize(950, 700)
            settingsFrame:Center()
            settingsFrame:InvalidateLayout(true)
        end

        CreateNaiFonts()
        chat.AddText(Theme.success, ADDON_CHAT_PREFIX, Theme.text, "All UI settings reset to defaults!")
    end)
    
    CreateSpacer(interfacePanel, 10)
    
    local infoPanel = vgui.Create("DPanel", interfacePanel)
    infoPanel:SetTall(100)
    infoPanel:Dock(TOP)
    infoPanel:DockMargin(5, 0, 5, 5)
    infoPanel.Paint = function(self, w, h)
        draw.RoundedBox(6, 0, 0, w, h, Theme.bgDark)
        
        surface.SetDrawColor(Theme.accent)
        surface.SetMaterial(Material("icon16/information.png"))
        surface.DrawTexturedRect(15, 15, 16, 16)
        
        draw.SimpleText("Interface Settings Info", "NaiFont_Bold", 38, 18, Theme.accent)
        
        local infoLines = {
            "These settings control the addon's user interface behavior",
            "Changes to panel size require closing and reopening the menu",
            "Disabling sounds or animations can improve performance on low-end systems"
        }
        
        local y = 45
        for _, line in ipairs(infoLines) do
            draw.SimpleText("- " .. line, "NaiFont_Small", 20, y, Theme.textDim)
            y = y + 16
        end
    end
    
    -- Simulate Tab
    local simulatePanel = CreateContentPanel()
    simulatePanel.SearchPanelName = "Simulate"
    local simulateBtn = CreateNavButton("Simulate", "icon16/wand.png")
    simulatePanel.SearchNavButton = simulateBtn
    simulateBtn.DoClick = function() SwitchToPanel(simulatePanel, simulateBtn) end
    
    CreateSectionHeader(simulatePanel, "Simulation System")
    
    -- Work In Progress Panel
    local wipPanel2 = vgui.Create("DPanel", simulatePanel)
    wipPanel2:SetTall(200)
    wipPanel2:Dock(TOP)
    wipPanel2:DockMargin(10, 10, 10, 10)
    wipPanel2.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Theme.bgDark)
        
        -- Rotating Icon
        local angle = (CurTime() * 60) % 360
        surface.SetDrawColor(Theme.accent)
        surface.SetMaterial(Material("icon16/hourglass.png"))
        surface.DrawTexturedRectRotated(w / 2, 62, 64, 64, angle)
        
        draw.SimpleText("Work In Progress", "NaiFont_Title", w/2, 110, Theme.textBright, TEXT_ALIGN_CENTER)
        draw.SimpleText("This feature is currently under development", "NaiFont_Normal", w/2, 140, Theme.textDim, TEXT_ALIGN_CENTER)
        draw.SimpleText("Check back in a future update!", "NaiFont_Normal", w/2, 165, Theme.textDim, TEXT_ALIGN_CENTER)
    end
    
    -- Modules Tab
    local modulesPanel = CreateContentPanel()
    modulesPanel.SearchPanelName = "Modules"
    local modulesBtn = CreateNavButton("Modules", "icon16/plugin.png")
    modulesPanel.SearchNavButton = modulesBtn
    modulesBtn.DoClick = function() SwitchToPanel(modulesPanel, modulesBtn) end
    
    CreateSectionHeader(modulesPanel, "Modules System")
    
    -- Work In Progress Panel
    local wipPanel3 = vgui.Create("DPanel", modulesPanel)
    wipPanel3:SetTall(200)
    wipPanel3:Dock(TOP)
    wipPanel3:DockMargin(10, 10, 10, 10)
    wipPanel3.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Theme.bgDark)
        
        -- Rotating Icon
        local angle = (CurTime() * 60) % 360
        surface.SetDrawColor(Theme.accent)
        surface.SetMaterial(Material("icon16/hourglass.png"))
        surface.DrawTexturedRectRotated(w / 2, 62, 64, 64, angle)
        
        draw.SimpleText("Work In Progress", "NaiFont_Title", w/2, 110, Theme.textBright, TEXT_ALIGN_CENTER)
        draw.SimpleText("This feature is currently under development", "NaiFont_Normal", w/2, 140, Theme.textDim, TEXT_ALIGN_CENTER)
        draw.SimpleText("Check back in a future update!", "NaiFont_Normal", w/2, 165, Theme.textDim, TEXT_ALIGN_CENTER)
    end
    
    -- Help Tab
    local helpPanel = CreateContentPanel()
    helpPanel.SearchPanelName = "Help"
    local helpBtn = CreateNavButton("Help", "icon16/help.png")
    helpPanel.SearchNavButton = helpBtn
    helpBtn.DoClick = function() SwitchToPanel(helpPanel, helpBtn) end
    
    CreateSectionHeader(helpPanel, "Frequently Asked Questions")
    CreateHelpText(helpPanel, "Quick answers to common questions and troubleshooting.")
    
    CreateSpacer(helpPanel, 5)
    
    -- Helper function to create expandable FAQ item
    local function CreateFAQ(parent, iconPath, question, answer)
        local isExpanded = false
        
        local container = vgui.Create("DPanel", parent)
        container:Dock(TOP)
        container:DockMargin(8, 3, 8, 0)
        container.Paint = function() end
        
        -- Header button
        local header = vgui.Create("DButton", container)
        header:Dock(TOP)
        header:SetTall(35)
        header:SetText("")
        header.Paint = function(self, w, h)
            local col = self:IsHovered() and Theme.bgLighter or Theme.bgDark
            draw.RoundedBox(6, 0, 0, w, h, col)
            
            -- Icon
            surface.SetDrawColor(Theme.accent.r, Theme.accent.g, Theme.accent.b, 255)
            surface.SetMaterial(Material(iconPath))
            surface.DrawTexturedRect(12, (h - 16) / 2, 16, 16)
            
            -- Question text
            draw.SimpleText(question, "NaiFont_Bold", 40, h/2, Theme.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            
            -- Arrow indicator
            local arrow = isExpanded and "v" or ">" 
            draw.SimpleText(arrow, "NaiFont_Normal", w - 15, h/2, Theme.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        
        -- Answer panel
        local answerPanel = vgui.Create("DPanel", container)
        answerPanel:Dock(TOP)
        answerPanel:DockMargin(0, 2, 0, 0)
        answerPanel:SetVisible(false)
        answerPanel.Paint = function(self, w, h)
            draw.RoundedBox(6, 0, 0, w, h, Theme.bgLighter)
        end
        
        local answerLabel = vgui.Create("DLabel", answerPanel)
        answerLabel:SetText(answer)
        answerLabel:SetFont("NaiFont_Normal")
        answerLabel:SetTextColor(Theme.textDim)
        answerLabel:SetWrap(true)
        answerLabel:SetAutoStretchVertical(true)
        answerLabel:Dock(FILL)
        answerLabel:DockMargin(15, 10, 15, 10)
        
        -- Toggle function
        header.DoClick = function()
            isExpanded = not isExpanded
            answerPanel:SetVisible(isExpanded)
            
            if isExpanded then
                -- Delay height calculation to next frame for proper wrapping
                timer.Simple(0, function()
                    if not IsValid(answerLabel) then return end
                    answerLabel:SetWide(answerPanel:GetWide() - 30) -- Account for margins
                    answerLabel:SizeToContentsY()
                    local labelHeight = answerLabel:GetTall()
                    answerPanel:SetTall(labelHeight + 20)
                    container:SetTall(37 + labelHeight + 20)
                    parent:InvalidateLayout(true)
                end)
            else
                answerPanel:SetTall(0)
                container:SetTall(35)
                parent:InvalidateLayout(true)
            end
        end
        
        container:SetTall(35)
        
        return container
    end
    
    -- FAQ Items
    CreateFAQ(helpPanel, "icon16/car.png", "How do I add NPCs to my vehicle?",
        "Right-click on a friendly NPC while near your vehicle. They'll automatically walk over and board. You can also enable Auto-Join in the settings to have NPCs automatically board when you enter a vehicle.")
    
    CreateFAQ(helpPanel, "icon16/cross.png", "How do I remove passengers from my vehicle?",
        "Right-click them again while they're in the vehicle, or use the 'Detach All' keybind (set in Keybinds tab). Dead passengers can be removed by holding R near them.")
    
    CreateFAQ(helpPanel, "icon16/error.png", "My NPCs are floating or clipping through the vehicle!",
        "Go to the Position tab and adjust the Height/Forward/Right offsets. Each vehicle model is different, so you may need to fine-tune these values. Use the debugging panel to test positions in real-time.")
    
    CreateFAQ(helpPanel, "icon16/sound_mute.png", "NPCs aren't making any sounds!",
        "Check the Behaviour tab and make sure 'Enable NPC Speech' is turned on. Also verify that Speech Volume is above 0. Some NPC models may not have voice lines available.")
    
    CreateFAQ(helpPanel, "icon16/group.png", "Can I have multiple NPCs in one vehicle?",
        "Yes! Set the 'Passenger Limit' in General settings. The addon will distribute NPCs around the vehicle automatically. For specific seat positions, adjust offsets in the Position tab.")
    
    CreateFAQ(helpPanel, "icon16/user_go.png", "How does Auto-Join work?",
        "When enabled in the Auto-Join tab, nearby friendly NPCs will automatically board your vehicle when you enter it - just like squad mechanics in Half-Life 2. You can set the detection range and limit how many NPCs can auto-join.")
    
    CreateFAQ(helpPanel, "icon16/user_delete.png", "What happens when passengers die?",
        "Dead passengers will show a red glow effect and display a skull icon on the HUD. Get close to your vehicle and hold R to remove their bodies. The bodies will be ejected with physics.")
    
    CreateFAQ(helpPanel, "icon16/emoticon_smile.png", "What do the passenger statuses mean?",
        "CALM: Relaxed, no threats nearby\nALERT: Enemy detected, NPC is tracking threats\nSCARED: Dangerous driving (high speed, crashes)\nDROWSY: Long calm ride, NPC is getting sleepy\nDEAD: Health reached zero")
    
    CreateFAQ(helpPanel, "icon16/keyboard.png", "My keybinds aren't working!",
        "Go to the Keybinds tab and make sure you've actually set the keybinds (they're unbound by default). Click the button next to each action and press your desired key. Right-click to unbind.")
    
    CreateFAQ(helpPanel, "icon16/bug.png", "The addon isn't working at all / I'm getting errors!",
        "1. Make sure you're using friendly NPCs (Combine NPCs won't work)\n2. Check console for errors (press ~)\n3. Try resetting all settings with 'nai_npc_reset' in console\n4. Verify the addon is enabled in the Addons menu\n5. Make sure your vehicle has physics and isn't frozen")
    
    CreateFAQ(helpPanel, "icon16/lightbulb.png", "Can NPCs shoot from the vehicle?",
        "Not currently. NPCs will track enemies and react to threats, but won't fire weapons while seated. This feature may be added in future updates.")
    
    CreateFAQ(helpPanel, "icon16/stop.png", "How do I stop NPCs from auto-joining?",
        "Disable 'Enable Auto-Join' in the Auto-Join settings tab. You can also toggle it with a keybind (set in Keybinds tab).")
    
    CreateFAQ(helpPanel, "icon16/cog.png", "Where are the settings saved?",
        "All settings are saved as ConVars in your GMod config. They persist between sessions and are specific to your client.")
    
    CreateFAQ(helpPanel, "icon16/drive.png", "Does this work with all vehicles?",
        "It works with most vehicles that have physics. Tanks, APCs, cars, boats, etc. Some modded vehicles may require position adjustments.")
    
    CreateFAQ(helpPanel, "icon16/weather_lightning.png", "NPCs are acting weird after crashes!",
        "This is normal - they react with fear to dangerous driving. Lower the Fear Threshold in HUD settings if you want them less reactive.")
    
    CreateFAQ(helpPanel, "icon16/arrow_rotate_clockwise.png", "How do I reset just one setting?",
        "Use the console command for that specific setting. All commands start with 'nai_npc_'. Type 'find nai_npc' in console to see all available commands.")
    
    CreateFAQ(helpPanel, "icon16/server.png", "Does this work in multiplayer?",
        "Yes! The addon works on both singleplayer and multiplayer servers. Each player controls their own passengers.")
    
    CreateSpacer(helpPanel, 10)
    CreateSectionHeader(helpPanel, "Still Need Help?")
    
    local helpBox = vgui.Create("DPanel", helpPanel)
    helpBox:Dock(TOP)
    helpBox:DockMargin(8, 5, 8, 5)
    helpBox:SetTall(80)
    helpBox.Paint = function(self, w, h)
        draw.RoundedBox(6, 0, 0, w, h, Theme.bgDark)
        
        surface.SetDrawColor(Theme.accent.r, Theme.accent.g, Theme.accent.b, 255)
        surface.SetMaterial(Material("icon16/comment.png"))
        surface.DrawTexturedRect(15, 15, 16, 16)
        
        draw.SimpleText("Console Commands for Debugging:", "NaiFont_Bold", 40, 18, Theme.text)
        
        local y = 45
        draw.SimpleText("nai_npc_debug_mode 1", "NaiFont_Normal", 40, y, Theme.textDim)
        draw.SimpleText("- Enable debug mode to see detailed info", "NaiFont_Small", 220, y, Color(120, 120, 135))
    end
    
    -- About Tab
    local aboutPanel = CreateContentPanel()
    aboutPanel.SearchPanelName = "About"
    local aboutBtn = CreateNavButton("About", "icon16/information.png")
    aboutPanel.SearchNavButton = aboutBtn
    aboutBtn.DoClick = function() SwitchToPanel(aboutPanel, aboutBtn) end
    
    CreateSectionHeader(aboutPanel, "About " .. ADDON_DISPLAY_NAME .. " v" .. NPCPassengers.Version)
    
    local aboutText = vgui.Create("DPanel", aboutPanel)
    aboutText:SetTall(160)
    aboutText:Dock(TOP)
    aboutText:DockMargin(5, 5, 5, 5)
    aboutText.Paint = function(self, w, h)
        -- Gradient background
        draw.RoundedBox(8, 0, 0, w, h, Theme.bgDark)
        local gradientMat = Material("vgui/gradient-d")
        surface.SetDrawColor(Theme.accentDark.r, Theme.accentDark.g, Theme.accentDark.b, 40)
        surface.SetMaterial(gradientMat)
        surface.DrawTexturedRect(0, 0, w, h)
        
        -- Border
        surface.SetDrawColor(Theme.borderLight)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        
        local y = 20
        draw.SimpleText(ADDON_DISPLAY_NAME, "NaiFont_Title", w/2, y, Theme.accent, TEXT_ALIGN_CENTER)
        y = y + 32
        draw.SimpleText("Advanced passenger system with emotional AI and realistic physics", "NaiFont_Normal", w/2, y, Theme.text, TEXT_ALIGN_CENTER)
        y = y + 30
        
        -- Feature highlights
        local features = {
            "Status System: CALM / ALERT / SCARED / DROWSY / DEAD",
            "Performance: seat caching, throttled timers, optimized client hooks",
            "Vehicle filtering, boarding retry cooldown, squad-only auto-join"
        }
        
        for _, feature in ipairs(features) do
            draw.SimpleText(feature, "NaiFont_Small", w/2, y, Theme.textDim, TEXT_ALIGN_CENTER)
            y = y + 20
        end
    end
    
    CreateSpacer(aboutPanel, 10)
    CreateSectionHeader(aboutPanel, "Actions")
    
    CreateButton(aboutPanel, "Show Welcome Screen", function()
        settingsFrame:Close()
        timer.Simple(0.1, function() ShowWelcomePanel(true) end)
    end)

    CreateButton(aboutPanel, "Open GitHub Page", function()
        gui.OpenURL("https://github.com/Nai64/BetterNPCPassengers")
    end)
    
    CreateButton(aboutPanel, "Reset ALL Settings to Defaults", function()
        RunConsoleCommand("nai_npc_reset")
        settingsFrame:Close()
        timer.Simple(0.1, OpenSettingsPanel)
    end)
    
    -- Start with General panel active
    SwitchToPanel(generalPanel, generalBtn)
    timer.Simple(0, function()
        if IsValid(searchEntry) then
            FocusSearchEntry()
        end
    end)
end

concommand.Add("nai_passengers_menu", OpenSettingsPanel)

concommand.Add("nai_npc_reset", function()
    -- Delegate all ConVar resets to the server-side handler so that
    -- replicated ConVars are actually changed (clients cannot change them directly)
    RunConsoleCommand("nai_npc_server_reset")
end)

-- Spawn menu entry
hook.Add("PopulateToolMenu", "NPCPassengerOptions", function()
        spawnmenu.AddToolMenuOption("Utilities", ADDON_DISPLAY_NAME, "NPCPassengers", ADDON_DISPLAY_NAME, "", "", function(panel)
        panel:ClearControls()
        
        panel:Help(ADDON_DISPLAY_NAME .. " lets friendly NPCs ride in your vehicles!")
        panel:Help("")
        
        local openBtn = panel:Button("Open Settings Panel")
        openBtn.DoClick = function()
            OpenSettingsPanel()
        end
        
        panel:Help("")
        panel:Help("Or use console command: nai_passengers_menu")
    end)
end)

-- Q menu bar dropdown
hook.Add("PopulateMenuBar", "NPCPassengersMenuBar", function(menubar)
    local m = menubar:AddOrGetMenu(ADDON_DISPLAY_NAME)

    m:AddOption("Open Settings", function()
        OpenSettingsPanel()
    end):SetIcon("icon16/cog.png")

    m:AddSpacer()

    m:AddOption("Reset All Settings", function()
        RunConsoleCommand("nai_npc_reset")
    end):SetIcon("icon16/arrow_refresh.png")
end)

-- Right-click context menu options
properties.Add("nai_make_passenger", {
    MenuLabel = "Make Passenger",
    Order = 1500,
    MenuIcon = "icon16/car.png",

    Filter = function(self, ent, ply)
        if not GetConVar("nai_npc_context_make_passenger"):GetBool() then return false end
        if not IsValid(ent) then return false end
        if not ent:IsNPC() then return false end
        return true
    end,

    Action = function(self, ent)
        net.Start("NPCPassengers_MakePassenger")
            net.WriteEntity(ent)
        net.SendToServer()
    end
})

--[[ NPC DRIVER CONTEXT MENU (DISABLED)
properties.Add("nai_make_driver", {
    MenuLabel = "Make NPC Driver for This Vehicle",
    Order = 1501,
    MenuIcon = "icon16/car_go.png",

    Filter = function(self, ent, ply)
        if not IsValid(ent) then return false end
        if not ent:IsNPC() then return false end
        if not GetConVar("nai_npc_driver_enabled"):GetBool() then return false end
        return true
    end,

    Action = function(self, ent)
        net.Start("NPCPassengers_MakeDriver")
            net.WriteEntity(ent)
        net.SendToServer()
    end
})
--]]

properties.Add("nai_select_for_vehicle", {
    MenuLabel = "Make Passenger For Vehicle...",
    Order = 1502,
    MenuIcon = "icon16/car_add.png",

    Filter = function(self, ent, ply)
        if not GetConVar("nai_npc_context_make_passenger_vehicle"):GetBool() then return false end
        if not IsValid(ent) then return false end
        if not ent:IsNPC() then return false end
        return true
    end,

    Action = function(self, ent)
        selectedNPCForVehicle = ent
        selectionExpireTime = CurTime() + 30
        chat.AddText(Color(100, 200, 100), ADDON_CHAT_PREFIX, Color(255, 255, 255), "NPC selected! Now right-click on a vehicle and select 'Add Selected NPC'")
    end
})

properties.Add("nai_add_selected_to_vehicle", {
    MenuLabel = "Add Selected NPC Here",
    Order = 1503,
    MenuIcon = "icon16/user_add.png",

    Filter = function(self, ent, ply)
        if not IsValid(ent) then return false end
        if not IsValid(selectedNPCForVehicle) then return false end
        if CurTime() > selectionExpireTime then
            selectedNPCForVehicle = nil
            return false
        end
        if ent:IsVehicle() then return true end
        if ent.LVS or ent.IsLVS then return true end
        if ent.IsSimfphyscar then return true end
        if ent.IsGlideVehicle then return true end
        if ent.IsSligWolf or ent.sligwolf or ent.SligWolf then return true end
        local class = ent:GetClass() or ""
        if string.find(class, "lvs_") then return true end
        if string.find(class, "gmod_sent_vehicle") then return true end
        if string.find(class, "sligwolf_") then return true end
        if string.find(class, "sw_") then return true end
        return false
    end,

    Action = function(self, ent)
        if IsValid(selectedNPCForVehicle) then
            net.Start("NPCPassengers_MakePassengerForVehicle")
                net.WriteEntity(selectedNPCForVehicle)
                net.WriteEntity(ent)
            net.SendToServer()
            chat.AddText(Color(100, 200, 100), ADDON_CHAT_PREFIX, Color(255, 255, 255), "Adding NPC to vehicle...")
            selectedNPCForVehicle = nil
        end
    end
})

properties.Add("nai_cancel_selection", {
    MenuLabel = "Cancel NPC Selection",
    Order = 1503,
    MenuIcon = "icon16/cancel.png",

    Filter = function(self, ent, ply)
        if not IsValid(selectedNPCForVehicle) then return false end
        if CurTime() > selectionExpireTime then
            selectedNPCForVehicle = nil
            return false
        end
        return true
    end,

    Action = function(self, ent)
        selectedNPCForVehicle = nil
        chat.AddText(Color(255, 200, 100), ADDON_CHAT_PREFIX, Color(255, 255, 255), "NPC selection cancelled")
    end
})

properties.Add("nai_remove_passenger", {
    MenuLabel = "Remove Passenger",
    Order = 1504,
    MenuIcon = "icon16/car_delete.png",

    Filter = function(self, ent, ply)
        if not GetConVar("nai_npc_context_detach"):GetBool() then return false end
        if not IsValid(ent) then return false end
        if not ent:IsNPC() then return false end
        return true
    end,

    Action = function(self, ent)
        net.Start("NPCPassengers_RemovePassenger")
            net.WriteEntity(ent)
        net.SendToServer()
    end
})

properties.Add("nai_blacklist_passenger", {
    MenuLabel = "Blacklist Passenger",
    Order = 1505,
    MenuIcon = "icon16/user_go.png",

    Filter = function(self, ent, ply)
        if not IsValid(ent) then return false end
        if not ent:IsNPC() then return false end
        return true
    end,

    Action = function(self, ent)
        local npcClass = ent:GetClass()
        if npcClass then
            RunConsoleCommand("nai_npc_add_turret_blacklist", npcClass)
        end
    end
})

properties.Add("nai_whitelist_passenger", {
    MenuLabel = "Whitelist Passenger",
    Order = 1506,
    MenuIcon = "icon16/user_add.png",

    Filter = function(self, ent, ply)
        if not IsValid(ent) then return false end
        if not ent:IsNPC() then return false end
        return true
    end,

    Action = function(self, ent)
        local npcClass = ent:GetClass()
        if npcClass then
            RunConsoleCommand("nai_npc_add_vehicle_whitelist", npcClass)
        end
    end
})

-- F7 hotkey
hook.Add("PlayerButtonDown", "NPCPassengersQuickMenu", function(ply, button)
    if button == KEY_F7 and IsFirstTimePredicted() then
        OpenSettingsPanel()
    end
end)

-- C menu icon (top left corner)
list.Set("DesktopWindows", "NPCPassengersDesktop", {
    title = ADDON_DISPLAY_NAME,
    icon = "icon64/npc_passengers.png",
    init = function(icon, window)
        window:Remove() -- Close the default window
        OpenSettingsPanel()
    end
})
-- Startup welcome panel
local WELCOME_VERSION = NPCPassengers.Version or "2.5.61"

function ShowWelcomePanel(forceShow)
    local dontShow = cookie.GetString("nai_passengers_hide_welcome", "0")

    if not forceShow and dontShow == "1" then return end
    
    local frame = vgui.Create("DFrame")
    frame:SetSize(620, 560)
    frame:Center()
    frame:SetTitle("")
    frame:MakePopup()
    frame:SetDeleteOnClose(true)

    -- Fluid entrance animation for welcome panel
    if AreUIAnimationsEnabled() then
        frame:SetAlpha(0)
        local targetX, targetY = frame:GetPos()
        frame:SetPos(targetX, targetY - 50)
        frame:AlphaTo(255, 0.3, 0)
        frame:MoveTo(targetX, targetY, 0.35, 0, -1)
    end
    
    frame.Paint = function(self, w, h)
        -- Shadow/glow effect
        draw.RoundedBox(12, 4, 4, w, h, Color(0, 0, 0, 100))

        -- Main background
        draw.RoundedBox(10, 0, 0, w, h, Theme.bg)

        -- Subtle inner border
        draw.RoundedBox(9, 1, 1, w - 2, h - 2, Color(255, 255, 255, 3))

        -- Header with gradient
        local gradientMat = Material("vgui/gradient-d")
        surface.SetDrawColor(Theme.accentDark.r, Theme.accentDark.g, Theme.accentDark.b, 100)
        surface.SetMaterial(gradientMat)
        draw.RoundedBoxEx(10, 0, 0, w, 44, Theme.bgDark, true, true, false, false)

        -- Subtle glow on header
        draw.RoundedBoxEx(10, 0, 0, w, 44, Color(Theme.accent.r, Theme.accent.g, Theme.accent.b, 15), true, true, false, false)

        -- Accent line under header
        surface.SetDrawColor(Theme.accent)
        surface.DrawRect(0, 44, w, 2)
        surface.SetDrawColor(Theme.accent.r, Theme.accent.g, Theme.accent.b, 50)
        surface.DrawRect(0, 46, w, 1)

        -- Title text with shadow
        draw.SimpleText(ADDON_DISPLAY_NAME, "NaiFont_Title", 16, 23, Color(0, 0, 0, 120), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText(ADDON_DISPLAY_NAME, "NaiFont_Title", 15, 22, Theme.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText("v" .. WELCOME_VERSION, "NaiFont_Small", w - 50, 23, Color(0, 0, 0, 80), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
        draw.SimpleText("v" .. WELCOME_VERSION, "NaiFont_Small", w - 50, 22, Theme.textDim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
    end
    
    frame.btnClose:SetVisible(false)
    frame.btnMaxim:SetVisible(false)
    frame.btnMinim:SetVisible(false)
    
    local closeBtn = vgui.Create("DButton", frame)
    closeBtn:SetPos(frame:GetWide() - 40, 10)
    closeBtn:SetSize(26, 26)
    closeBtn:SetText("")
    closeBtn.hoverAnim = 0
    closeBtn.Paint = function(self, w, h)
        local baseColor = Theme.bgLight
        local hoverColor = Theme.error
        local col = baseColor
        if self:IsHovered() then
            closeBtn.hoverAnim = math.min(closeBtn.hoverAnim + 0.2, 1)
        else
            closeBtn.hoverAnim = math.max(closeBtn.hoverAnim - 0.2, 0)
        end
        col = LerpColor(closeBtn.hoverAnim, baseColor, hoverColor)

        -- Scale animation on hover
        local scale = 1 + closeBtn.hoverAnim * 0.1
        local scaledW = w * scale
        local scaledH = h * scale
        local offsetX = (w - scaledW) / 2
        local offsetY = (h - scaledH) / 2

        -- Button background with subtle border and scale
        draw.RoundedBox(5, offsetX, offsetY, scaledW, scaledH, col)
        draw.RoundedBox(4, offsetX + 1, offsetY + 1, scaledW - 2, scaledH - 2, Color(255, 255, 255, 10))

        local iconColor = Theme.textBright
        surface.SetDrawColor(iconColor)

        -- Scale icon position
        local iconOffsetX = (w - scaledW) / 2
        local iconOffsetY = (h - scaledH) / 2

        surface.DrawLine(7 + iconOffsetX, 7 + iconOffsetY, w - 7 + iconOffsetX, h - 7 + iconOffsetY)
        surface.DrawLine(w - 7 + iconOffsetX, 7 + iconOffsetY, 7 + iconOffsetX, h - 7 + iconOffsetY)
    end
    closeBtn.DoClick = function()
        frame:Close()
    end
    
    local content = vgui.Create("DScrollPanel", frame)
    content:SetPos(15, 54)
    content:SetSize(590, 440)
    content.Paint = function() end
    
    local sbar = content:GetVBar()
    sbar:SetWide(6)
    sbar.Paint = function(s, w, h) draw.RoundedBox(3, 0, 0, w, h, Theme.bgDark) end
    sbar.btnUp.Paint = function() end
    sbar.btnDown.Paint = function() end
    sbar.btnGrip.Paint = function(s, w, h) draw.RoundedBox(3, 0, 0, w, h, Theme.scrollbarGrip) end
    
    -- Hey there header
    local heyHeader = vgui.Create("DLabel", content)
    heyHeader:SetFont("NaiFont_Large")
    heyHeader:SetTextColor(Theme.textBright)
    heyHeader:SetText("Hey there!")
    heyHeader:Dock(TOP)
    heyHeader:DockMargin(0, 5, 0, 8)
    heyHeader:SizeToContents()
    
    local msg1 = vgui.Create("DLabel", content)
    msg1:SetFont("NaiFont_Normal")
    msg1:SetTextColor(Theme.text)
    msg1:SetText("Before complaining about the passenger sitting on top of vehicle,\nplease open the settings. You can do it, I believe in you.")
    msg1:SetWrap(true)
    msg1:SetAutoStretchVertical(true)
    msg1:Dock(TOP)
    msg1:DockMargin(0, 0, 0, 12)
    
    -- Settings button
    local settingsBtn = vgui.Create("DButton", content)
    settingsBtn:SetText("Open Settings")
    settingsBtn:SetFont("NaiFont_Medium")
    settingsBtn:SetTall(38)
    settingsBtn:Dock(TOP)
    settingsBtn:DockMargin(0, 0, 0, 15)
    settingsBtn:SetTextColor(TransparentColor)
    settingsBtn.hoverAnim = 0
    settingsBtn.pressAnim = 0
    settingsBtn.Paint = function(self, w, h)
        AnimateButtonVisualState(self, 5, 5, 18, 12)

        local pushOffset = GetButtonPushOffset(self, 2)
        local bgColor = LerpColor(self.hoverAnim, Theme.accent, Theme.accentHover)
        bgColor = LerpColor(self.pressAnim, bgColor, Theme.accentActive)
        draw.RoundedBox(6, 0, pushOffset, w, h, bgColor)
        draw.SimpleText(self:GetText(), "NaiFont_Medium", w / 2, (h / 2) + pushOffset, Theme.textBright, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    settingsBtn.DoClick = function()
        frame:Close()
        OpenSettingsPanel()
    end
    
    -- Divider
    local div1 = vgui.Create("DPanel", content)
    div1:SetTall(1)
    div1:Dock(TOP)
    div1:DockMargin(0, 5, 0, 15)
    div1.Paint = function(s, w, h)
        surface.SetDrawColor(Theme.border)
        surface.DrawRect(0, 0, w, h)
    end
    
    local msg2 = vgui.Create("DLabel", content)
    msg2:SetFont("NaiFont_Normal")
    msg2:SetTextColor(Theme.textDim)
    msg2:SetText("This addon is still far from being PERFECT, please do not hesitate to\nreport bugs and suggest new features. I read all of your comments!")
    msg2:SetWrap(true)
    msg2:SetAutoStretchVertical(true)
    msg2:Dock(TOP)
    msg2:DockMargin(0, 0, 0, 15)
    
    local changelogHeader = vgui.Create("DPanel", content)
    changelogHeader:SetTall(30)
    changelogHeader:Dock(TOP)
    changelogHeader:DockMargin(0, 0, 0, 8)
    changelogHeader.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Theme.accent)
        draw.SimpleText("Update Changelog (v" .. WELCOME_VERSION .. ")", "NaiFont_Medium", 12, h/2, Theme.textBright, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end
    
    local changelog = vgui.Create("DPanel", content)
    changelog:SetTall(208)
    changelog:Dock(TOP)
    changelog:DockMargin(0, 0, 0, 10)
    changelog.Paint = function(self, w, h)
        draw.RoundedBox(6, 0, 0, w, h, Theme.bgDark)
        local changes = {
                "+ Code cleanup and minor optimizations for better maintainability",
                "+ Removed redundant comment patterns and verbose sections",
                "+ Consolidated helper function implementations for clarity",
                "+ Improved overall readability across addon modules"
            }
        for i, line in ipairs(changes) do
            local col = Theme.text
            if string.sub(line, 1, 1) == "*" then col = Theme.textDim end
            draw.SimpleText(line, "NaiFont_Small", 12, 10 + (i - 1) * 17, col, TEXT_ALIGN_LEFT)
        end
    end
    
    local bottomPanel = vgui.Create("DPanel", frame)
    bottomPanel:SetPos(15, frame:GetTall() - 55)
    bottomPanel:SetSize(590, 45)
    bottomPanel.Paint = function() end
    
    -- Don't show again checkbox
    local dontShowCheck = vgui.Create("DCheckBox", bottomPanel)
    dontShowCheck:SetPos(0, 12)
    dontShowCheck:SetSize(20, 20)
    dontShowCheck:SetValue(false)
    dontShowCheck.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Theme.bgLighter)
        if self:GetChecked() then
            draw.RoundedBox(3, 3, 3, w - 6, h - 6, Theme.accent)
            draw.SimpleText("v", "NaiFont_Normal", w/2, h/2, Theme.textBright, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        surface.SetDrawColor(Theme.border)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    
    local dontShowLabel = vgui.Create("DLabel", bottomPanel)
    dontShowLabel:SetPos(28, 12)
    dontShowLabel:SetText("Don't show this again")
    dontShowLabel:SetFont("NaiFont_Normal")
    dontShowLabel:SetTextColor(Theme.textDim)
    dontShowLabel:SizeToContents()
    dontShowLabel:SetMouseInputEnabled(true)
    dontShowLabel:SetCursor("hand")
    dontShowLabel.DoClick = function()
        dontShowCheck:Toggle()
    end
    
    -- OK button
    local okBtn = vgui.Create("DButton", bottomPanel)
    okBtn:SetPos(bottomPanel:GetWide() - 120, 5)
    okBtn:SetSize(120, 36)
    okBtn:SetText("Got it!")
    okBtn:SetFont("NaiFont_Medium")
    okBtn:SetTextColor(TransparentColor)
    okBtn.hoverAnim = 0
    okBtn.pressAnim = 0
    okBtn.Paint = function(self, w, h)
        AnimateButtonVisualState(self, 5, 5, 18, 12)

        local pushOffset = GetButtonPushOffset(self, 2)
        local bgColor = LerpColor(self.hoverAnim, Theme.success, Color(100, 200, 120))
        bgColor = LerpColor(self.pressAnim, bgColor, Color(60, 160, 80))
        draw.RoundedBox(6, 0, pushOffset, w, h, bgColor)
        draw.SimpleText(self:GetText(), "NaiFont_Medium", w / 2, (h / 2) + pushOffset, Theme.textBright, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    okBtn.DoClick = function()
        if dontShowCheck:GetChecked() then
            cookie.Set("nai_passengers_hide_welcome", "1")
        end
        frame:Close()
    end
end

-- Show welcome panel shortly after game loads
hook.Add("InitPostEntity", "NPCPassengersWelcome", function()
    timer.Simple(3, ShowWelcomePanel)
end)

--[[
    ========================================
    PASSENGER STATUS HUD
    ========================================
]]

local hudIcons = {}
local hudIconsLoaded = false

-- Try to load custom icons, fallback to built-in drawing
local function LoadHUDIcons()
    if hudIconsLoaded then return end
    hudIconsLoaded = true
    
    local iconNames = {"calm", "alert", "scared", "drowsy", "dead", "passenger"}
    for _, name in ipairs(iconNames) do
        local path = "nai_passengers/icon_" .. name .. ".png"
        local mat = Material(path, "smooth mips")
        if not mat:IsError() then
            hudIcons[name] = mat
        end
    end
end

-- Status colors
local StatusColors = {
    calm = Color(80, 200, 120),      -- Green
    alert = Color(255, 180, 50),     -- Yellow/Orange
    scared = Color(255, 80, 80),     -- Red
    drowsy = Color(100, 150, 255),   -- Blue
    dead = Color(60, 60, 70),        -- Dark Gray (Dead)
    default = Color(180, 180, 180),  -- Gray
}

-- Get passenger emotional state
local function GetPassengerStatus(npc)
    if not IsValid(npc) then return "default", 0 end
    
    local alertThreshold = GetConVar("nai_npc_hud_alert_threshold")
    local fearThreshold = GetConVar("nai_npc_hud_fear_threshold")
    local drowsyThreshold = GetConVar("nai_npc_hud_drowsy_threshold")
    
    local alertLevel = npc:GetNWFloat("NPCPassengerAlertLevel", 0)
    local fearLevel = npc:GetNWFloat("NPCPassengerFearLevel", 0)
    local isDrowsy = npc:GetNWBool("NPCPassengerIsDrowsy", false)
    local calmTime = npc:GetNWFloat("NPCPassengerCalmTime", 0)
    local drowsyTime = GetConVar("nai_npc_drowsy_time")
    
    -- Priority: Dead > Scared > Alert > Drowsy > Calm
    local at = alertThreshold and alertThreshold:GetFloat() or 0.3
    local ft = fearThreshold and fearThreshold:GetFloat() or 0.5
    local dt = drowsyThreshold and drowsyThreshold:GetFloat() or 0.7
    local drowsyTimeVal = drowsyTime and drowsyTime:GetFloat() or 60
    
    -- Check if dead
    if npc:Health() <= 0 or not npc:Alive() then
        return "dead", 1
    elseif fearLevel >= ft then
        return "scared", fearLevel
    elseif alertLevel >= at then
        return "alert", alertLevel
    elseif isDrowsy or (drowsyTimeVal > 0 and calmTime / drowsyTimeVal >= dt) then
        return "drowsy", calmTime / math.max(1, drowsyTimeVal)
    else
        return "calm", 0
    end
end

-- Get NPC display name
local function GetNPCDisplayName(npc)
    if not IsValid(npc) then return "Unknown" end
    
    -- Try to get targetname (map-placed NPCs)
    local targetName = npc:GetNWString("targetname", "")
    if targetName == "" and npc.GetInternalVariable then
        targetName = npc:GetInternalVariable("m_iName") or ""
    end
    if targetName and targetName ~= "" then return targetName end
    
    -- Use class-based names
    local class = npc:GetClass() or "unknown"
    local classNames = {
        ["npc_citizen"] = "Citizen",
        ["npc_alyx"] = "Alyx",
        ["npc_barney"] = "Barney",
        ["npc_monk"] = "Father Grigori",
        ["npc_eli"] = "Eli",
        ["npc_kleiner"] = "Dr. Kleiner",
        ["npc_mossman"] = "Dr. Mossman",
        ["npc_breen"] = "Dr. Breen",
        ["npc_vortigaunt"] = "Vortigaunt",
        ["npc_dog"] = "Dog",
    }
    
    if classNames[class] then return classNames[class] end
    
    -- Try model-based name
    local model = npc:GetModel() or ""
    if string.find(model, "female") then
        return "Citizen (F)"
    elseif string.find(model, "male") then
        return "Citizen (M)"
    elseif string.find(model, "medic") then
        return "Medic"
    elseif string.find(model, "rebel") then
        return "Rebel"
    end
    
    return "Passenger"
end

-- Draw status icon (fallback if no custom icon)
local function DrawStatusIcon(x, y, size, status, progress)
    local color = StatusColors[status] or StatusColors.default
    
    -- Shake effect for scared status
    local shakeX, shakeY = 0, 0
    if status == "scared" then
        local shakeIntensity = 2
        shakeX = math.sin(CurTime() * 30) * shakeIntensity
        shakeY = math.cos(CurTime() * 40) * shakeIntensity
    end
    
    -- Check for custom icon
    if hudIcons[status] then
        surface.SetMaterial(hudIcons[status])
        surface.SetDrawColor(255, 255, 255, 255)
        surface.DrawTexturedRect(x + shakeX, y + shakeY, size, size)
    else
        -- Fallback: Draw colored circle with symbol
        draw.RoundedBox(size / 2, x + shakeX, y + shakeY, size, size, color)
        
        local symbols = {
            calm = "*",
            alert = "!",
            scared = "!!",
            drowsy = "Z",
            dead = "X",
            default = "?"
        }
        
        local symbol = symbols[status] or "?"
        draw.SimpleText(symbol, "NaiFont_Medium", x + size / 2 + shakeX, y + size / 2 + shakeY, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
end

-- Main HUD drawing
local hudPassengers = {}
local lastHUDUpdate = 0
local smoothedIntensity = {}  -- Table to store smoothed intensity values per NPC
local smoothedHealth = {}     -- Table to store smoothed health values per NPC

-- Dead passenger ejection prompt
local ejectPromptData = {
    count = 0,
    showTime = 0,
    lookingAt = false,
    lastPress = 0,
    holdProgress = 0,
    holdStartTime = 0,
    isHolding = false,
    requiredHoldTime = 1.5  -- 1.5 seconds to eject
}

local clientCueData = {
    text = "",
    success = true,
    expireAt = 0
}

net.Receive("NPCPassengers_ClientCue", function()
    local success = net.ReadBool()
    local msg = net.ReadString()

    if GetConVarBoolSafe("nai_npc_client_cues", true) then
        surface.PlaySound(success and "buttons/button15.wav" or "buttons/button10.wav")
    end

    clientCueData.text = msg or ""
    clientCueData.success = success
    clientCueData.expireAt = CurTime() + 2.2
end)

net.Receive("NPCPassengers_EjectPrompt", function()
    ejectPromptData.count = net.ReadInt(8)
    ejectPromptData.lookingAt = net.ReadBool()
    ejectPromptData.showTime = CurTime()
end)

-- Detect R key HOLD to eject dead passengers
hook.Add("Think", "NPCPassengers_EjectKeyCheck", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then 
        ejectPromptData.isHolding = false
        ejectPromptData.holdProgress = 0
        return 
    end
    
    -- MUST be on foot to eject
    if ply:InVehicle() then 
        ejectPromptData.isHolding = false
        ejectPromptData.holdProgress = 0
        return 
    end
    
    -- Check if prompt is currently visible (within last 0.5 seconds)
    if CurTime() - ejectPromptData.showTime > 0.5 then 
        ejectPromptData.isHolding = false
        ejectPromptData.holdProgress = 0
        return 
    end
    if ejectPromptData.count <= 0 then 
        ejectPromptData.isHolding = false
        ejectPromptData.holdProgress = 0
        return 
    end
    
    -- MUST be alive to eject
    if not ply:Alive() then
        ejectPromptData.isHolding = false
        ejectPromptData.holdProgress = 0
        return
    end
    
    -- Check if R key is being held
    if input.IsKeyDown(KEY_R) then
        if not ejectPromptData.isHolding then
            -- Just started holding
            ejectPromptData.isHolding = true
            ejectPromptData.holdStartTime = CurTime()
            ejectPromptData.holdProgress = 0
        else
            -- Continue holding - update progress
            local holdTime = CurTime() - ejectPromptData.holdStartTime
            ejectPromptData.holdProgress = math.min(holdTime / ejectPromptData.requiredHoldTime, 1)
            
            -- If held long enough, eject!
            if ejectPromptData.holdProgress >= 1 then
                -- Send eject request to server
                net.Start("NPCPassengers_EjectDead")
                net.SendToServer()
                
                -- Clear prompt and reset
                ejectPromptData.count = 0
                ejectPromptData.showTime = 0
                ejectPromptData.isHolding = false
                ejectPromptData.holdProgress = 0
                
                -- Play satisfying sound
                surface.PlaySound("buttons/lever7.wav")
            end
        end
    else
        -- Key released - reset hold
        if ejectPromptData.isHolding then
            ejectPromptData.isHolding = false
            ejectPromptData.holdProgress = 0
        end
    end
end)

-- Draw ejection prompt
hook.Add("HUDPaint", "NPCPassengers_EjectPrompt", function()
    if CurTime() - ejectPromptData.showTime > 0.5 then return end
    if ejectPromptData.count <= 0 then return end
    
    local scrW, scrH = ScrW(), ScrH()
    local centerX = scrW / 2
    local centerY = scrH / 2 + 100
    
    -- Background box
    local textWidth = 350
    local textHeight = 80
    local boxX = centerX - textWidth / 2
    local boxY = centerY - textHeight / 2
    
    -- Pulsing glow effect
    local pulse = math.abs(math.sin(CurTime() * 3)) * 50 + 205
    
    -- Draw outer glow
    draw.RoundedBox(12, boxX - 4, boxY - 4, textWidth + 8, textHeight + 8, Color(200, 50, 50, pulse * 0.3))
    
    -- Draw main box
    draw.RoundedBox(10, boxX, boxY, textWidth, textHeight, Color(40, 25, 25, 240))
    
    -- Draw border
    draw.RoundedBox(10, boxX - 2, boxY - 2, textWidth + 4, textHeight + 4, Color(200, 50, 50, 0))
    surface.SetDrawColor(200, 50, 50, pulse)
    surface.DrawOutlinedRect(boxX - 1, boxY - 1, textWidth + 2, textHeight + 2, 2)
    
    -- Skull icon
    draw.SimpleText("[DEAD]", "NaiFont_Bold", centerX, boxY + 20, Color(255, 100, 100), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    
    -- Text
    local deadText = ejectPromptData.count .. " Dead Passenger" .. (ejectPromptData.count > 1 and "s" or "")
    draw.SimpleText(deadText, "NaiFont_Bold", centerX, boxY + 38, Color(255, 100, 100), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    
    -- Instruction with hold progress
    if ejectPromptData.isHolding and ejectPromptData.holdProgress > 0 then
        -- Show progress bar when holding
        local barWidth = 250
        local barHeight = 16
        local barX = centerX - barWidth / 2
        local barY = boxY + 54
        
        -- Progress bar background
        draw.RoundedBox(8, barX, barY, barWidth, barHeight, Color(20, 20, 25, 200))
        
        -- Progress bar fill
        local fillWidth = barWidth * ejectPromptData.holdProgress
        local fillColor = Color(
            math.Lerp(ejectPromptData.holdProgress, 255, 100),
            math.Lerp(ejectPromptData.holdProgress, 100, 255),
            100
        )
        draw.RoundedBox(8, barX, barY, fillWidth, barHeight, fillColor)
        
        -- Progress text
        local progressPercent = math.floor(ejectPromptData.holdProgress * 100)
        draw.SimpleText(progressPercent .. "%", "NaiFont_Small", centerX, barY + barHeight / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    else
        -- Show instruction when not holding
        local keyColor = ejectPromptData.lookingAt and Color(100, 255, 100) or Color(255, 200, 100)
        local instruction = "Hold [R] to Remove Bodies"
        draw.SimpleText(instruction, "NaiFont_Normal", centerX, boxY + 58, keyColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
end)

hook.Add("HUDPaint", "NPCPassengers_StatusHUD", function()
    -- Check if HUD is enabled
    local hudEnabled = GetConVar("nai_npc_hud_enabled")
    if not hudEnabled or not hudEnabled:GetBool() then return end
    
    -- Check if player should see HUD
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    
    local onlyInVehicle = GetConVar("nai_npc_hud_only_vehicle")
    if onlyInVehicle and onlyInVehicle:GetBool() then
        if not ply:InVehicle() then return end
    end
    
    -- Load icons
    LoadHUDIcons()
    
    -- Get settings
    local positionCV = GetConVar("nai_npc_hud_position")
    local scaleCV = GetConVar("nai_npc_hud_scale")
    local opacityCV = GetConVar("nai_npc_hud_opacity")
    local showCalmCV = GetConVar("nai_npc_hud_show_calm")
    
    local position = positionCV and positionCV:GetInt() or 1
    local scale = scaleCV and scaleCV:GetFloat() or 1
    local opacity = opacityCV and opacityCV:GetFloat() or 0.85
    local showCalm = showCalmCV and showCalmCV:GetBool() or true
    
    -- Update passenger list periodically
    if CurTime() - lastHUDUpdate > 0.25 then
        lastHUDUpdate = CurTime()
        hudPassengers = {}
        
        -- Clean up smoothed values for invalid/removed NPCs
        local validNPCs = {}
        local trackedPassengers = GetTrackedPassengerEntities()
        
        for _, ent in ipairs(trackedPassengers) do
            local status, intensity = GetPassengerStatus(ent)
            if showCalm or status ~= "calm" then
                local health = ent:Health()
                local maxHealth = ent:GetMaxHealth()
                table.insert(hudPassengers, {
                    npc = ent,
                    name = GetNPCDisplayName(ent),
                    status = status,
                    intensity = intensity,
                    health = health,
                    maxHealth = maxHealth,
                    healthPercent = maxHealth > 0 and (health / maxHealth) or 1,
                })
                validNPCs[ent:EntIndex()] = true
            end
        end
        
        -- Remove smoothed values for NPCs that no longer exist
        for npcID, _ in pairs(smoothedIntensity) do
            if not validNPCs[npcID] then
                smoothedIntensity[npcID] = nil
                smoothedHealth[npcID] = nil
            end
        end
    end
    
    -- No passengers to show
    if #hudPassengers == 0 then return end
    
    -- Calculate dimensions
    local baseWidth = 220
    local baseHeight = 58
    local padding = 8
    local iconSize = 28
    local barHeight = 8
    
    local panelWidth = baseWidth * scale
    local entryHeight = baseHeight * scale
    local totalHeight = (#hudPassengers * entryHeight) + (padding * 2 * scale) + (24 * scale)
    
    -- Position calculation
    local scrW, scrH = ScrW(), ScrH()
    local margin = 20
    local startX, startY
    
    if position == 0 then -- Top Left
        startX = margin
        startY = margin
    elseif position == 1 then -- Top Right
        startX = scrW - panelWidth - margin
        startY = margin
    elseif position == 2 then -- Bottom Left
        startX = margin
        startY = scrH - totalHeight - margin
    else -- Bottom Right
        startX = scrW - panelWidth - margin
        startY = scrH - totalHeight - margin
    end
    
    -- Draw background panel
    local bgColor = Color(25, 25, 30, 255 * opacity)
    local headerColor = Color(40, 40, 50, 255 * opacity)
    local borderColor = Color(70, 130, 180, 200 * opacity)
    
    -- Draw rounded border first (larger box with border color)
    draw.RoundedBox(8 * scale, startX - 2, startY - 2, panelWidth + 4, totalHeight + 4, borderColor)
    
    -- Main background on top
    draw.RoundedBox(8 * scale, startX, startY, panelWidth, totalHeight, bgColor)
    
    -- Header
    draw.RoundedBoxEx(8 * scale, startX, startY, panelWidth, 24 * scale, headerColor, true, true, false, false)
    
    -- Header text
    draw.SimpleText("Passengers", "NaiFont_Bold", startX + padding * scale, startY + 12 * scale, Color(220, 220, 230), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    draw.SimpleText(tostring(#hudPassengers), "NaiFont_Small", startX + panelWidth - padding * scale, startY + 12 * scale, Color(150, 150, 165), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
    
    -- Draw each passenger
    local entryY = startY + 24 * scale + padding * scale
    
    for i, pdata in ipairs(hudPassengers) do
        if not IsValid(pdata.npc) then continue end
        
        local entryX = startX + padding * scale
        local entryW = panelWidth - (padding * 2 * scale)
        
        -- Entry background (subtle)
        local entryBgColor = Color(35, 35, 42, 200 * opacity)
        draw.RoundedBox(4 * scale, entryX, entryY, entryW, entryHeight - 4 * scale, entryBgColor)
        
        -- Status icon
        local statusColor = StatusColors[pdata.status] or StatusColors.default
        DrawStatusIcon(entryX + 4 * scale, entryY + 4 * scale, iconSize * scale, pdata.status, pdata.intensity)
        
        -- Name
        local textX = entryX + iconSize * scale + 10 * scale
        draw.SimpleText(pdata.name, "NaiFont_Normal", textX, entryY + 6 * scale, Color(220, 220, 230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        
        -- Status text (right side, same line as name)
        local statusText = string.upper(pdata.status)
        draw.SimpleText(statusText, "NaiFont_Small", entryX + entryW - 4 * scale, entryY + 8 * scale, statusColor, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
        
        -- Intensity bar (below name) - SMOOTH INTERPOLATION
        local barX = textX
        local barY = entryY + 22 * scale
        local barW = entryW - (iconSize * scale + 14 * scale)
        local barH = barHeight * scale
        
        -- Smoothly interpolate intensity
        local npcID = pdata.npc:EntIndex()
        smoothedIntensity[npcID] = smoothedIntensity[npcID] or pdata.intensity
        local targetIntensity = pdata.intensity
        local lerpSpeed = FrameTime() * 3  -- Adjust for smoothness (higher = faster)
        smoothedIntensity[npcID] = Lerp(lerpSpeed, smoothedIntensity[npcID], targetIntensity)
        
        -- Bar background
        draw.RoundedBox(barH / 2, barX, barY, barW, barH, Color(20, 20, 25, 200))
        
        -- Bar fill (using smoothed value)
        local fillW = math.Clamp(smoothedIntensity[npcID], 0, 1) * barW
        if fillW > 2 then
            draw.RoundedBox(barH / 2, barX, barY, fillW, barH, statusColor)
        end
        
        -- Health Bar (below intensity bar) - SMOOTH INTERPOLATION
        local healthBarY = entryY + 34 * scale
        local healthBarW = barW
        local healthPercent = pdata.healthPercent or 1
        
        -- Smoothly interpolate health
        smoothedHealth[npcID] = smoothedHealth[npcID] or healthPercent
        local targetHealth = healthPercent
        local healthLerpSpeed = FrameTime() * 2  -- Slower for health (more dramatic)
        smoothedHealth[npcID] = Lerp(healthLerpSpeed, smoothedHealth[npcID], targetHealth)
        
        local smoothHealth = smoothedHealth[npcID]
        
        -- Determine health bar color (using smoothed value)
        local healthColor
        if smoothHealth > 0.75 then
            healthColor = Color(50, 200, 50)  -- Green (healthy)
        elseif smoothHealth > 0.4 then
            healthColor = Color(220, 180, 50)  -- Yellow (injured)
        else
            healthColor = Color(220, 50, 50)  -- Red (critical)
        end
        
        -- Health bar background
        draw.RoundedBox(barH / 2, barX, healthBarY, healthBarW, barH, Color(20, 20, 25, 200))
        
        -- Health bar fill (using smoothed value)
        local healthFillW = math.Clamp(smoothHealth, 0, 1) * healthBarW
        if healthFillW > 2 then
            draw.RoundedBox(barH / 2, barX, healthBarY, healthFillW, barH, healthColor)
            
            -- Healing indicator (pulsing glow when health is between 40-99%)
            if smoothHealth > 0.4 and smoothHealth < 0.99 then
                local pulse = math.abs(math.sin(CurTime() * 3)) * 100
                draw.RoundedBox(barH / 2, barX, healthBarY, healthFillW, barH, Color(100, 255, 100, pulse))
            end
        end
        
        -- Health text (HP) - centered on health bar
        local healthText = string.format("%d/%d", pdata.health or 0, pdata.maxHealth or 100)
        draw.SimpleText(healthText, "DermaDefaultBold", barX + healthBarW - 2 * scale, healthBarY + 1 * scale, Color(255, 255, 255, 220), TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
        
        entryY = entryY + entryHeight
    end
end)

hook.Add("HUDPaint", "NPCPassengers_ClientHints", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local showHints = GetConVarBoolSafe("nai_npc_hud_hints", true)
    local showTargetDebug = GetConVarBoolSafe("nai_npc_hud_target_debug", false)
    if not showHints and not showTargetDebug then return end

    local scrW, scrH = ScrW(), ScrH()
    local centerX = scrW * 0.5
    local y = scrH - 120

    if showHints and clientCueData.expireAt > CurTime() and clientCueData.text ~= "" then
        local col = clientCueData.success and Color(120, 240, 120) or Color(255, 140, 140)
        draw.SimpleText(clientCueData.text, "NaiFont_Normal", centerX, y, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        y = y - 22
    end

    if showTargetDebug then
        local tr = ply:GetEyeTrace()
        local ent = tr and tr.Entity
        if IsValid(ent) and ent:IsNPC() then
            local status = "none"
            if ent:GetNWBool("IsNPCPassenger", false) then
                local emotion = "calm"
                if ent:GetNWBool("NPCPassengerIsDrowsy", false) then
                    emotion = "drowsy"
                elseif ent:GetNWFloat("NPCPassengerFearLevel", 0) > 0.5 then
                    emotion = "scared"
                elseif ent:GetNWFloat("NPCPassengerAlertLevel", 0) > 0.3 then
                    emotion = "alert"
                end
                status = "passenger:" .. emotion
            end

            local veh = ent:GetParent()
            local vehText = IsValid(veh) and (veh:GetClass() or "unknown") or "none"
            draw.SimpleText("target npc " .. ent:GetClass() .. " | " .. status .. " | seat " .. vehText, "NaiFont_Small", centerX, y, Color(160, 210, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end
end)

-- NPC Driver Debug HUD
hook.Add("HUDPaint", "NPCPassengers_DriverDebug", function()
    if not GetConVar("nai_npc_driver_debug"):GetBool() then return end
    if not GetConVar("nai_npc_driver_enabled"):GetBool() then return end
    
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    
    -- Draw debug info for nearby NPCs that are drivers
    for _, npc in ipairs(ents.FindInSphere(ply:GetPos(), 2000)) do
        if not IsValid(npc) or not npc:IsNPC() then continue end
        
        -- Check if NPC has a vehicle parent (indicating it might be a driver)
        local parent = npc:GetParent()
        if not IsValid(parent) or not parent:IsVehicle() then continue end
        
        local vehicle = parent
        local vehPos = vehicle:GetPos()
        local screenPos = vehPos:ToScreen()
        
        if not screenPos.visible then continue end
        
        -- Draw vehicle info
        local vehVel = vehicle:GetVelocity()
        local speed = math.Round(vehVel:Length())
        
        draw.SimpleText("NPC Driver", "DermaDefault", screenPos.x, screenPos.y - 40, Color(100, 200, 255), TEXT_ALIGN_CENTER)
        draw.SimpleText("Speed: " .. speed .. " u/s", "DermaDefault", screenPos.x, screenPos.y - 25, Color(255, 255, 255), TEXT_ALIGN_CENTER)
        draw.SimpleText("NPC: " .. npc:GetClass(), "DermaDefault", screenPos.x, screenPos.y - 10, Color(200, 200, 200), TEXT_ALIGN_CENTER)
    end
end)
